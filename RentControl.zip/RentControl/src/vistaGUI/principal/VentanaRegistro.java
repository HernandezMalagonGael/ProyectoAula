
package vistaGUI.principal;
import javax.swing.JOptionPane;

public class VentanaRegistro extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaRegistro.class.getName());

    public VentanaRegistro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtCorreo = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtContrasena = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        cmbTipo = new javax.swing.JComboBox<>();
        btnContinuar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(30, 34, 45));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RENTCONTROL. CDMX, MÉXICO. 2026");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(304, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(280, 280, 280))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 548, 918, 50);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CORREO");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(450, 90, 60, 20);

        txtCorreo.setBackground(new java.awt.Color(253, 232, 201));
        txtCorreo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCorreo.setForeground(new java.awt.Color(30, 34, 45));
        txtCorreo.addActionListener(this::txtCorreoActionPerformed);
        jPanel1.add(txtCorreo);
        txtCorreo.setBounds(350, 120, 250, 26);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("CONTRASEÑA");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(430, 160, 100, 20);

        txtContrasena.setBackground(new java.awt.Color(253, 232, 201));
        txtContrasena.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtContrasena.setForeground(new java.awt.Color(30, 34, 45));
        jPanel1.add(txtContrasena);
        txtContrasena.setBounds(350, 190, 250, 26);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("NOMBRE COMPLETO");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(410, 230, 138, 20);

        txtNombre.setBackground(new java.awt.Color(253, 232, 201));
        txtNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNombre.setForeground(new java.awt.Color(30, 34, 45));
        jPanel1.add(txtNombre);
        txtNombre.setBounds(350, 260, 250, 26);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("FECHA DE NACIMIENTO");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(400, 310, 160, 20);

        txtFecha.setBackground(new java.awt.Color(253, 232, 201));
        txtFecha.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtFecha.setForeground(new java.awt.Color(30, 34, 45));
        txtFecha.setText("    DD/MM/AAAA");
        txtFecha.addActionListener(this::txtFechaActionPerformed);
        jPanel1.add(txtFecha);
        txtFecha.setBounds(350, 340, 250, 26);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("TIPO DE USUARIO: ");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(410, 390, 130, 20);

        cmbTipo.setBackground(new java.awt.Color(253, 232, 201));
        cmbTipo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbTipo.setForeground(new java.awt.Color(30, 34, 45));
        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione", "Arrendador", "Arrendatario", " " }));
        jPanel1.add(cmbTipo);
        cmbTipo.setBounds(350, 420, 250, 26);

        btnContinuar.setBackground(new java.awt.Color(253, 232, 201));
        btnContinuar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnContinuar.setForeground(new java.awt.Color(30, 34, 45));
        btnContinuar.setText("CONTINUAR");
        btnContinuar.addActionListener(this::btnContinuarActionPerformed);
        jPanel1.add(btnContinuar);
        btnContinuar.setBounds(410, 470, 148, 37);

        jButton1.setBackground(new java.awt.Color(30, 34, 45));
        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(253, 232, 201));
        jButton1.setText("<- REGRESAR ");
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel1.add(jButton1);
        jButton1.setBounds(25, 14, 130, 27);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("BIENVENIDO A RENTCONTROL");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(220, 30, 521, 48);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 918, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 588, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCorreoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCorreoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCorreoActionPerformed

    private void txtFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaActionPerformed

    private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuarActionPerformed

        String correo = txtCorreo.getText().trim();
    String contrasena = new String(txtContrasena.getPassword()).trim();
    String nombre = txtNombre.getText().trim();
    String fechaTexto = txtFecha.getText().trim();
    String tipo = cmbTipo.getSelectedItem().toString();

    if (correo.isEmpty() || contrasena.isEmpty() || nombre.isEmpty() || 
        fechaTexto.isEmpty() || tipo.equals("Seleccione")) {
        JOptionPane.showMessageDialog(this, "Por favor llena todos los campos");
        return;
    }

    try {
        java.time.LocalDate fecha = java.time.LocalDate.parse(fechaTexto,
            java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        int tipoInt = tipo.equals("Arrendador") ? 2 : 3;

        controlador.UsuarioControlador uc = new controlador.UsuarioControlador();
        boolean exito = uc.registrarUsuario(nombre, correo, contrasena, fecha, tipoInt);

        if (exito) {
            JOptionPane.showMessageDialog(this, "Registro exitoso");
            new VentanaInicioSesion().setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar, intenta de nuevo");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Fecha inválida. Usa el formato DD/MM/AAAA");
    }
    }//GEN-LAST:event_btnContinuarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
            // TODO add your handling code here:
        new VentanaPrincipal().setVisible(true);
        this.dispose();    
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new VentanaRegistro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnContinuar;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField txtContrasena;
    private javax.swing.JTextField txtCorreo;
    private javax.swing.JTextField txtFecha;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}

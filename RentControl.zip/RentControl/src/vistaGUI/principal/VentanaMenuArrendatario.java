
package vistaGUI.principal;
 
import controlador.InmuebleControlador;
import controlador.PagoControlador;
import vistaGUI.inmueble.InmuebleListaGUI;
import vistaGUI.pago.PagoPrincipalGUI;
import vistaGUI.reporte.ReportePrincipalGUI;
import vistaGUI.cuenta.CuentaLecturaGUI;
 
public class VentanaMenuArrendatario extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaMenuArrendatario.class.getName());
 
    private java.awt.CardLayout cardLayoutContenido;
    private javax.swing.JPanel panelContenido;
 
    public static final String VISTA_INICIO = "INICIO";
    public static final String VISTA_INMUEBLES = "INMUEBLES";
    public static final String VISTA_PAGOS = "PAGOS";
    public static final String VISTA_REPORTES = "REPORTES";
    public static final String VISTA_CUENTA = "CUENTA";
 
    public VentanaMenuArrendatario() {
        initComponents();
        construirContenido();
    }
 
    private void construirContenido() {
        cardLayoutContenido = new java.awt.CardLayout();
        panelContenido = new javax.swing.JPanel(cardLayoutContenido);
 
        jPanel1.remove(jPanel2);
 
        javax.swing.GroupLayout nuevoLayout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(nuevoLayout);
        nuevoLayout.setHorizontalGroup(
            nuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(nuevoLayout.createSequentialGroup()
                .addGroup(nuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(nuevoLayout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addComponent(jLabel7))
                    .addGroup(nuevoLayout.createSequentialGroup()
                        .addGap(226, 226, 226)
                        .addComponent(imgtario, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(nuevoLayout.createSequentialGroup()
                        .addGap(246, 246, 246)
                        .addComponent(rentario)))
                .addContainerGap(253, Short.MAX_VALUE))
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        nuevoLayout.setVerticalGroup(
            nuevoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(nuevoLayout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(imgtario, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(rentario)
                .addGap(0, 0, 0)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1.setMinimumSize(new java.awt.Dimension(818, 588));
        jPanel1.setMaximumSize(new java.awt.Dimension(818, 588));
        jPanel1.setPreferredSize(new java.awt.Dimension(818, 588));
 
        panelContenido.add(jPanel1, VISTA_INICIO);
 
        InmuebleControlador inmuebleControlador = new InmuebleControlador();
        PagoControlador pagoControlador = new PagoControlador();
 
        InmuebleListaGUI panelInmuebles = new InmuebleListaGUI(inmuebleControlador);
        PagoPrincipalGUI panelPagos = new PagoPrincipalGUI(inmuebleControlador, pagoControlador);
        ReportePrincipalGUI panelReportes = new ReportePrincipalGUI();
        CuentaLecturaGUI panelCuenta = new CuentaLecturaGUI();
 
        panelContenido.add(panelInmuebles, VISTA_INMUEBLES);
        panelContenido.add(panelPagos, VISTA_PAGOS);
        panelContenido.add(panelReportes, VISTA_REPORTES);
        panelContenido.add(panelCuenta, VISTA_CUENTA);
 
        getContentPane().removeAll();
        getContentPane().setLayout(new java.awt.BorderLayout());
        getContentPane().add(jPanel2, java.awt.BorderLayout.WEST);
        getContentPane().add(panelContenido, java.awt.BorderLayout.CENTER);
 
        pack();
        setResizable(false);
 
        cardLayoutContenido.show(panelContenido, VISTA_INICIO);
        getContentPane().revalidate();
        getContentPane().repaint();
    }
 
    public void mostrarVista(String nombreVista) {
        if (cardLayoutContenido != null && panelContenido != null) {
            cardLayoutContenido.show(panelContenido, nombreVista);
        }
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        footer = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        imgtario = new javax.swing.JLabel();
        rentario = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        casa = new javax.swing.JLabel();
        inmueble = new javax.swing.JLabel();
        reporte = new javax.swing.JLabel();
        pago = new javax.swing.JLabel();
        cuenta = new javax.swing.JLabel();
        sesion = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(30, 34, 45));
        jPanel1.setMaximumSize(null);
        jPanel1.setName(""); // NOI18N

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(30, 34, 45));
        jLabel2.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(303, 303, 303))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("HOLA ARRENDATARIO");

        imgtario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/rent.png"))); // NOI18N
        imgtario.setText("jLabel1");

        rentario.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        rentario.setForeground(new java.awt.Color(255, 255, 255));
        rentario.setText("RENTCONTROL");

        jPanel2.setBackground(new java.awt.Color(30, 34, 45));

        casa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/casa_menu.png"))); // NOI18N
        casa.setPreferredSize(new java.awt.Dimension(65, 65));
        casa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                casaMouseClicked(evt);
            }
        });

        inmueble.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/inmuebles_menu.png"))); // NOI18N
        inmueble.setPreferredSize(new java.awt.Dimension(65, 65));
        inmueble.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inmuebleMouseClicked(evt);
            }
        });

        reporte.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/documento_menu.png"))); // NOI18N
        reporte.setPreferredSize(new java.awt.Dimension(65, 65));
        reporte.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reporteMouseClicked(evt);
            }
        });

        pago.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/pagos_menu.png"))); // NOI18N
        pago.setPreferredSize(new java.awt.Dimension(65, 65));
        pago.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pagoMouseClicked(evt);
            }
        });

        cuenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/usuario_menu.png"))); // NOI18N
        cuenta.setPreferredSize(new java.awt.Dimension(65, 65));
        cuenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cuentaMouseClicked(evt);
            }
        });

        sesion.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        sesion.setForeground(new java.awt.Color(253, 232, 201));
        sesion.setText("<html>Cerrar<br>sesión</html>");
        sesion.setMaximumSize(new java.awt.Dimension(65, 65));
        sesion.setMinimumSize(new java.awt.Dimension(65, 65));
        sesion.setPreferredSize(new java.awt.Dimension(65, 65));
        sesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sesionMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(casa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(inmueble, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cuenta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(reporte, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pago, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sesion, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(casa, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(inmueble, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(reporte, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pago, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(sesion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addComponent(jLabel7))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(226, 226, 226)
                        .addComponent(imgtario, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(246, 246, 246)
                        .addComponent(rentario)))
                .addContainerGap(253, Short.MAX_VALUE))
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(imgtario, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(rentario))
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void inmuebleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inmuebleMouseClicked
        mostrarVista(VISTA_INMUEBLES);
    }//GEN-LAST:event_inmuebleMouseClicked

    private void reporteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reporteMouseClicked
        mostrarVista(VISTA_REPORTES);
    }//GEN-LAST:event_reporteMouseClicked

    private void pagoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pagoMouseClicked
        mostrarVista(VISTA_PAGOS);
    }//GEN-LAST:event_pagoMouseClicked

    private void cuentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cuentaMouseClicked
        mostrarVista(VISTA_CUENTA);
    }//GEN-LAST:event_cuentaMouseClicked

    private void sesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sesionMouseClicked
        utilidades.Sesion.cerrarSesion();
        new VentanaPrincipal().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_sesionMouseClicked

    private void casaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_casaMouseClicked
        mostrarVista(VISTA_INICIO);
    }//GEN-LAST:event_casaMouseClicked

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
 
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new VentanaMenuArrendador().setVisible(true));
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel casa;
    private javax.swing.JLabel cuenta;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel imgtario;
    private javax.swing.JLabel inmueble;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel pago;
    private javax.swing.JLabel rentario;
    private javax.swing.JLabel reporte;
    private javax.swing.JLabel sesion;
    // End of variables declaration//GEN-END:variables
}

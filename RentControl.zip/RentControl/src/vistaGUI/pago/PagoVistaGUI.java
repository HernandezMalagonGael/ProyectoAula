package vistaGUI.pago;
 
import controlador.PagoControlador;
import modelo.Pago;
import utilidades.Sesion;
import javax.swing.JOptionPane;
 
public class PagoVistaGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private final PagoControlador pagoControlador;
    private final Pago pago;
    private final Runnable onVolver;
    
    public PagoVistaGUI(PagoControlador pagoControlador, Pago pago, Runnable onVolver) {
        this.pagoControlador = pagoControlador;
        this.pago     = pago;
        this.onVolver = onVolver;
 
        initComponents();
        cargarDatos();
        activarDocImg();
 
        if (Sesion.getTipoUsuarioActivo() == 2) {
            activarEdicionDobleClick();
            BtnAceptar.setText("Guardar y volver");
        } else {
            BtnAceptar.setText("Volver");
        }
        inicializado = true;
    }
 
    private void cargarDatos() {
        nombre.setText("Inquilino ID: " + pago.getId_usuario());
        monto.setText("$" + pago.getMonto());
 
        if (pago.getFecha() != null) {
            java.time.format.DateTimeFormatter fmt = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
            fecha.setText(pago.getFecha().format(fmt));
        } else {
            fecha.setText("Sin fecha");
        }
 
        periodo_tiempo.setText(pago.getPeriodo_tiempo() != null ? pago.getPeriodo_tiempo() : "—");
 
        if (pago.getComprobante() != null && !pago.getComprobante().isBlank()) {
            jLabel3.setToolTipText("Doble clic: ver comprobante  |  Triple clic: cambiar (solo arrendador)");
        } else {
            jLabel3.setToolTipText("Sin comprobante adjunto");
        }
    }
    
    private void activarDocImg() {
        jLabel3.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    abrirComprobante();
                } else if (e.getClickCount() == 3) {
                    if (Sesion.getTipoUsuarioActivo() == 2) {
                        subirComprobante();
                    } else {
                        JOptionPane.showMessageDialog(PagoVistaGUI.this,
                            "Solo el arrendador puede modificar el comprobante.",
                            "Sin permiso", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });
    }
    
    private void abrirComprobante() {
        if (pago.getComprobante() == null || pago.getComprobante().isBlank()) {
            JOptionPane.showMessageDialog(this,
                "No hay comprobante adjunto para este pago.",
                "Sin comprobante", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        java.io.File archivo = new java.io.File(pago.getComprobante());
        if (!archivo.exists()) {
            JOptionPane.showMessageDialog(this,
                "El archivo no se encontró en: " + pago.getComprobante(),
                "Archivo no encontrado", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            java.awt.Desktop.getDesktop().open(archivo);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "No se pudo abrir el archivo: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
 
    private void subirComprobante() {
        javax.swing.JFileChooser chooser = new javax.swing.JFileChooser();
        chooser.setDialogTitle("Selecciona el comprobante de pago");
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Comprobante (PDF, PNG, JPG)", "pdf", "png", "jpg", "jpeg"));
 
        if (chooser.showOpenDialog(this) == javax.swing.JFileChooser.APPROVE_OPTION) {
            String ruta = chooser.getSelectedFile().getAbsolutePath();
            pago.setComprobante(ruta);
            boolean exito = pagoControlador.actualizarPago(pago);
            if (exito) {
                cargarDatos();
                JOptionPane.showMessageDialog(this,
                    "Comprobante guardado. Doble clic en el ícono para consultarlo.",
                    "Guardado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Error al guardar el comprobante.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void activarEdicionDobleClick() {
        java.awt.event.MouseAdapter adapter = new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    javax.swing.JLabel lbl = (javax.swing.JLabel) e.getSource();
                    javax.swing.JPanel panel = null;
                    if      (lbl == monto)        panel = monto_pagar;
                    else if (lbl == fecha)         panel = pane1;
                    else if (lbl == periodo_tiempo) panel = pane2;
                    if (panel == null) return;
 
                    String textoOriginal = lbl.getText();
                    String valor = textoOriginal;
                    if (valor.startsWith("$"))        valor = valor.substring(1).trim();
                    else if (valor.contains(": "))    valor = valor.substring(valor.indexOf(": ") + 2).trim();
                    if (valor.equals("—") || valor.equalsIgnoreCase("Sin fecha")) valor = "";
 
                    panel.setLayout(new java.awt.BorderLayout());
                    javax.swing.JTextField tf = new javax.swing.JTextField(valor);
                    tf.setFont(lbl.getFont());
                    tf.setBackground(new java.awt.Color(35, 40, 50));
                    tf.setForeground(new java.awt.Color(253, 230, 201));
                    tf.setCaretColor(new java.awt.Color(253, 230, 201));
                    tf.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(253, 230, 201), 1));
 
                    final javax.swing.JPanel p = panel;
                    tf.addActionListener(ev -> finalizarEdicion(p, tf, lbl));
                    tf.addFocusListener(new java.awt.event.FocusAdapter() {
                        @Override public void focusLost(java.awt.event.FocusEvent ev) {
                            finalizarEdicion(p, tf, lbl);
                        }
                    });
                    panel.remove(lbl);
                    panel.add(tf, java.awt.BorderLayout.CENTER);
                    tf.requestFocus();
                    panel.revalidate();
                    panel.repaint();
                }
            }
        };
        monto.addMouseListener(adapter);
        fecha.addMouseListener(adapter);
        periodo_tiempo.addMouseListener(adapter);
    }
 
    private void finalizarEdicion(javax.swing.JPanel panel, javax.swing.JTextField tf, javax.swing.JLabel lbl) {
        if (tf.getParent() == null) return;
        String nuevoValor = tf.getText().trim();
        if (!nuevoValor.isBlank()) {
            try {
                if (lbl == monto) {
                    double v = Double.parseDouble(nuevoValor);
                    pago.setMonto(v);
                    lbl.setText("$" + v);
                } else if (lbl == fecha) {
                    java.time.format.DateTimeFormatter fmt = java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    java.time.LocalDate d = java.time.LocalDate.parse(nuevoValor, fmt);
                    pago.setFecha(d);
                    lbl.setText(d.format(fmt));
                } else if (lbl == periodo_tiempo) {
                    pago.setPeriodo_tiempo(nuevoValor);
                    lbl.setText(nuevoValor);
                }
                pagoControlador.actualizarPago(pago);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingresa un monto numérico válido.",
                    "Error de formato", JOptionPane.ERROR_MESSAGE);
            } catch (java.time.format.DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this, "Formato de fecha: DD/MM/AAAA",
                    "Error de formato", JOptionPane.ERROR_MESSAGE);
            }
        }
        panel.remove(tf);
        panel.add(lbl, java.awt.BorderLayout.CENTER);
        panel.revalidate();
        panel.repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        pagos = new javax.swing.JLabel();
        nombre_inquilino = new javax.swing.JPanel();
        nombre = new javax.swing.JLabel();
        monto_pagar = new javax.swing.JPanel();
        monto = new javax.swing.JLabel();
        pane1 = new javax.swing.JPanel();
        fecha = new javax.swing.JLabel();
        pane2 = new javax.swing.JPanel();
        periodo_tiempo = new javax.swing.JLabel();
        BtnAceptar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(326, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(296, 296, 296))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pagos.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        pagos.setForeground(new java.awt.Color(255, 255, 255));
        pagos.setText("Vista Pago");

        nombre_inquilino.setBackground(new java.awt.Color(253, 232, 201));
        nombre_inquilino.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nombre.setBackground(new java.awt.Color(30, 34, 45));
        nombre.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        nombre.setForeground(new java.awt.Color(30, 34, 45));
        nombre.setText("Nombre del inquilino");
        nombre_inquilino.add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 310, -1));

        monto_pagar.setBackground(new java.awt.Color(253, 232, 201));
        monto_pagar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        monto.setBackground(new java.awt.Color(30, 34, 45));
        monto.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        monto.setForeground(new java.awt.Color(30, 34, 45));
        monto.setText("Monto pagado");
        monto_pagar.add(monto, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 320, -1));

        pane1.setBackground(new java.awt.Color(253, 232, 201));
        pane1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fecha.setBackground(new java.awt.Color(30, 34, 45));
        fecha.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        fecha.setForeground(new java.awt.Color(30, 34, 45));
        fecha.setText("Fecha del pago");
        pane1.add(fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 310, -1));

        pane2.setBackground(new java.awt.Color(253, 232, 201));
        pane2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        periodo_tiempo.setBackground(new java.awt.Color(30, 34, 45));
        periodo_tiempo.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        periodo_tiempo.setForeground(new java.awt.Color(30, 34, 45));
        periodo_tiempo.setText("Periodo de tiempo");
        pane2.add(periodo_tiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 310, -1));

        BtnAceptar.setBackground(new java.awt.Color(253, 232, 201));
        BtnAceptar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BtnAceptar.setForeground(new java.awt.Color(30, 34, 45));
        BtnAceptar.setText("Aceptar");
        BtnAceptar.setBorder(null);
        BtnAceptar.addActionListener(this::BtnAceptarActionPerformed);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_doc.png"))); // NOI18N
        jLabel3.setMaximumSize(null);
        jLabel3.setMinimumSize(null);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(346, 346, 346)
                        .addComponent(pagos))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(monto_pagar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(nombre_inquilino, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(pane1, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(58, 58, 58)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(138, 138, 138)
                                .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(pagos)
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(nombre_inquilino, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(monto_pagar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pane2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pane1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 97, Short.MAX_VALUE)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents
 
    private void BtnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAceptarActionPerformed
        if (onVolver != null) onVolver.run();
    }//GEN-LAST:event_BtnAceptarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAceptar;
    private javax.swing.JLabel fecha;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel monto;
    private javax.swing.JPanel monto_pagar;
    private javax.swing.JLabel nombre;
    private javax.swing.JPanel nombre_inquilino;
    private javax.swing.JLabel pagos;
    private javax.swing.JPanel pane1;
    private javax.swing.JPanel pane2;
    private javax.swing.JLabel periodo_tiempo;
    // End of variables declaration//GEN-END:variables
}

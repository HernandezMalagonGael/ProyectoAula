package vistaGUI.pago;
 
import controlador.PagoControlador;
import modelo.Inmueble;
import modelo.Pago;
import utilidades.Sesion;
import java.util.List;
import java.util.function.Consumer;
 
public class PagoListaGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private final PagoControlador pagoControlador;
    private final Inmueble inmueble;
    private final Runnable onVolver;
    private final Consumer<Pago> onVerPago;
    
    public PagoListaGUI(PagoControlador pagoControlador,
                        Inmueble inmueble,
                        Runnable onVolver,
                        Consumer<Pago> onVerPago) {
        this.pagoControlador = pagoControlador;
        this.inmueble  = inmueble;
        this.onVolver  = onVolver;
        this.onVerPago = onVerPago;
        initComponents();
 
        jButton1.setVisible(Sesion.getTipoUsuarioActivo() == 2);
 
        cargarPagos();
        inicializado = true;
    }
    
    private void cargarPagos() {
        List<Pago> lista = pagoControlador.consultarPagosPorInmueble(inmueble.getId_inmueble());
 
        javax.swing.JPanel grid = new javax.swing.JPanel();
        grid.setBackground(new java.awt.Color(30, 34, 45));
 
        if (lista.isEmpty()) {
            grid.setLayout(new java.awt.BorderLayout());
            javax.swing.JLabel sin = new javax.swing.JLabel(
                "<html><center>No hay pagos registrados<br>para este inmueble.</center></html>",
                javax.swing.SwingConstants.CENTER);
            sin.setForeground(java.awt.Color.WHITE);
            sin.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14));
            grid.add(sin, java.awt.BorderLayout.CENTER);
 
            jScrollPane1.setViewportView(grid);
        } else {
            int total = lista.size(), sobra = total % 3;
            int filas;
            grid.setLayout(new java.awt.GridLayout(0, 3, 8, 8));
            if (sobra == 1 && total > 1) {
                for (int i = 0; i < total - 1; i++) grid.add(crearTarjeta(lista.get(i)));
                grid.add(crearRelleno());
                grid.add(crearTarjeta(lista.get(total - 1)));
                grid.add(crearRelleno());
                filas = (total + 1) / 3;
            } else if (sobra == 2) {
                for (Pago p : lista) grid.add(crearTarjeta(p));
                grid.add(crearRelleno());
                filas = (total + 1) / 3;
            } else {
                for (Pago p : lista) grid.add(crearTarjeta(p));
                filas = total / 3;
            }
 
            // Tamaño fijo del grid (3 columnas x N filas de tarjetas 155x75 con gap 8px),
            // envuelto en un panel con FlowLayout para que GridLayout NO estire
            // las tarjetas para llenar la altura completa del JScrollPane.
            int anchoGrid = (155 * 3) + (8 * 2);
            int altoGrid  = (75 * filas) + (8 * Math.max(0, filas - 1));
            grid.setPreferredSize(new java.awt.Dimension(anchoGrid, altoGrid));
 
            javax.swing.JPanel contenedor = new javax.swing.JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEADING, 0, 0));
            contenedor.setBackground(new java.awt.Color(30, 34, 45));
            contenedor.add(grid);
 
            jScrollPane1.setViewportView(contenedor);
        }
 
        jScrollPane1.setBorder(null);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        jScrollPane1.getViewport().setBackground(new java.awt.Color(30, 34, 45));
        jScrollPane1.revalidate();
        jScrollPane1.repaint();
    }
    
    private javax.swing.JButton crearTarjeta(Pago pago) {
        String fecha = pago.getFecha_creacion() != null
            ? pago.getFecha_creacion().toLocalDate().toString()
            : (pago.getFecha() != null ? pago.getFecha().toString() : "Sin fecha");
        String periodo = pago.getPeriodo_tiempo() != null ? pago.getPeriodo_tiempo() : "";
 
        String texto = "<html><center>Pago<br>"
            + "<small>" + fecha + "</small><br>"
            + "<small>" + periodo + "</small>"
            + "</center></html>";
 
        javax.swing.JButton btn = new javax.swing.JButton(texto);
        btn.setBackground(new java.awt.Color(253, 232, 201));
        btn.setForeground(new java.awt.Color(30, 34, 45));
        btn.setPreferredSize(new java.awt.Dimension(155, 75));
        btn.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 10));
        btn.setFocusPainted(false);
        btn.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        btn.addActionListener(e -> { if (onVerPago != null) onVerPago.accept(pago); });
        return btn;
    }
 
    private javax.swing.JPanel crearRelleno() {
        javax.swing.JPanel r = new javax.swing.JPanel();
        r.setBackground(new java.awt.Color(30, 34, 45));
        r.setOpaque(true);
        return r;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelPagos = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jButton1 = new javax.swing.JButton();
        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        historial_pagos = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 599));

        panelPagos.setBackground(new java.awt.Color(30, 34, 45));

        jScrollPane1.setBackground(new java.awt.Color(30, 34, 45));

        javax.swing.GroupLayout panelPagosLayout = new javax.swing.GroupLayout(panelPagos);
        panelPagos.setLayout(panelPagosLayout);
        panelPagosLayout.setHorizontalGroup(
            panelPagosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 645, Short.MAX_VALUE)
        );
        panelPagosLayout.setVerticalGroup(
            panelPagosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 344, Short.MAX_VALUE)
        );

        jButton1.setBackground(new java.awt.Color(253, 232, 201));
        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(30, 34, 45));
        jButton1.setText("Registrar pago");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(307, 307, 307))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        historial_pagos.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        historial_pagos.setForeground(new java.awt.Color(255, 255, 255));
        historial_pagos.setText("Historial de pagos");

        jButton3.setBackground(new java.awt.Color(30, 34, 45));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(253, 232, 201));
        jButton3.setText("<- REGRESAR ");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addGap(125, 125, 125)
                .addComponent(historial_pagos)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(panelPagos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 59, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(300, 300, 300))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(historial_pagos))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)))
                .addGap(18, 18, 18)
                .addComponent(panelPagos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        javax.swing.JPanel contenedorPadre = (javax.swing.JPanel) getParent();
        java.awt.CardLayout cl = (java.awt.CardLayout) contenedorPadre.getLayout();
 
        while (contenedorPadre.getComponentCount() > 2) contenedorPadre.remove(2);
 
        PagoRegistroGUI registro = new PagoRegistroGUI(
            pagoControlador,
            inmueble.getId_inmueble(),
            () -> {
                while (contenedorPadre.getComponentCount() > 2) contenedorPadre.remove(2);
                cl.show(contenedorPadre, "PAGOS");
                cargarPagos(); // recargar la lista con el nuevo pago
                contenedorPadre.revalidate();
                contenedorPadre.repaint();
            },
            () -> {
                while (contenedorPadre.getComponentCount() > 2) contenedorPadre.remove(2);
                cl.show(contenedorPadre, "PAGOS");
                contenedorPadre.revalidate();
                contenedorPadre.repaint();
            }
        );
        contenedorPadre.add(registro, "REGISTRO_PAGO");
        cl.show(contenedorPadre, "REGISTRO_PAGO");
        contenedorPadre.revalidate();
        contenedorPadre.repaint();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (onVolver != null) onVolver.run();
    }//GEN-LAST:event_jButton3ActionPerformed

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel footer;
    private javax.swing.JLabel historial_pagos;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panelPagos;
    // End of variables declaration//GEN-END:variables
}

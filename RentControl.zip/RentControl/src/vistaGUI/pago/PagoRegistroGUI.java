package vistaGUI.pago;
 
import controlador.PagoControlador;
import utilidades.Sesion;
import javax.swing.JOptionPane;
 
public class PagoRegistroGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private final PagoControlador pagoControlador;
    private final int idInmueble;
    private final Runnable onExito;
    private final Runnable onCancelar;
    private String rutaComprobanteSeleccionada = null;
    
    public PagoRegistroGUI(PagoControlador pagoControlador,
                            int idInmueble,
                            Runnable onExito,
                            Runnable onCancelar) {
        this.pagoControlador = pagoControlador;
        this.idInmueble      = idInmueble;
        this.onExito         = onExito;
        this.onCancelar      = onCancelar;
        initComponents();
        limpiarPlaceholders();
        activarSelectorComprobante();
        
        fecha.setText(java.time.LocalDate.now().toString());
        inicializado = true;
    }
    
    private void limpiarPlaceholders() {
        agregarFocus(monto,         "Monto Pagado");
        agregarFocus(periodo_tiempo,"Periodo");
    }
 
    private void agregarFocus(javax.swing.JTextField tf, String placeholder) {
        tf.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusGained(java.awt.event.FocusEvent e) {
                if (tf.getText().equals(placeholder)) tf.setText("");
            }
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                if (tf.getText().isBlank()) tf.setText(placeholder);
            }
        });
    }
 
    private boolean campoVacio(javax.swing.JTextField tf, String placeholder) {
        return tf.getText().isBlank() || tf.getText().equals(placeholder);
    }
 
    private void limpiarFormulario() {
        monto.setText("Monto Pagado");
        periodo_tiempo.setText("Periodo");
        fecha.setText(java.time.LocalDate.now().toString());
        doc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_doc.png")));
        rutaComprobanteSeleccionada = null;
    }
    
    private void activarSelectorComprobante() {
        doc.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        doc.setToolTipText("Clic para seleccionar comprobante (PDF, PNG, JPG)");
        doc.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                javax.swing.JFileChooser chooser = new javax.swing.JFileChooser();
                chooser.setDialogTitle("Selecciona el comprobante de pago");
                chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                    "Comprobante (PDF, PNG, JPG)", "pdf", "png", "jpg", "jpeg"));
 
                if (chooser.showOpenDialog(PagoRegistroGUI.this) == javax.swing.JFileChooser.APPROVE_OPTION) {
                    rutaComprobanteSeleccionada = chooser.getSelectedFile().getAbsolutePath();
                    
                    String lower = rutaComprobanteSeleccionada.toLowerCase();
                    if (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg")) {
                        javax.swing.ImageIcon icono = new javax.swing.ImageIcon(rutaComprobanteSeleccionada);
                        int ancho = doc.getWidth() > 0 ? doc.getWidth() : 80;
                        int alto  = doc.getHeight() > 0 ? doc.getHeight() : 100;
                        java.awt.Image escalada = icono.getImage().getScaledInstance(ancho, alto, java.awt.Image.SCALE_SMOOTH);
                        doc.setIcon(new javax.swing.ImageIcon(escalada));
                        doc.setText("");
                    } else {
                       
                        doc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_doc.png")));
                        doc.setToolTipText("Comprobante: " + chooser.getSelectedFile().getName());
                    }
                }
            }
        });
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        periodo_tiempo = new javax.swing.JTextField();
        fecha = new javax.swing.JTextField();
        pagos = new javax.swing.JLabel();
        BtnAceptar = new javax.swing.JButton();
        doc = new javax.swing.JLabel();
        nombre_inquilino = new javax.swing.JTextField();
        monto = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(305, 305, 305))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        periodo_tiempo.setBackground(new java.awt.Color(253, 232, 201));
        periodo_tiempo.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        periodo_tiempo.setForeground(new java.awt.Color(30, 34, 45));
        periodo_tiempo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        periodo_tiempo.setText("Periodo");
        periodo_tiempo.setPreferredSize(new java.awt.Dimension(163, 28));

        fecha.setBackground(new java.awt.Color(253, 232, 201));
        fecha.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        fecha.setForeground(new java.awt.Color(30, 34, 45));
        fecha.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        fecha.setText("Fecha del pago");
        fecha.setPreferredSize(new java.awt.Dimension(163, 28));
        fecha.addActionListener(this::fechaActionPerformed);

        pagos.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        pagos.setForeground(new java.awt.Color(255, 255, 255));
        pagos.setText("Registrar pago");

        BtnAceptar.setBackground(new java.awt.Color(253, 232, 201));
        BtnAceptar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BtnAceptar.setForeground(new java.awt.Color(30, 34, 45));
        BtnAceptar.setText("Aceptar");
        BtnAceptar.setBorder(null);
        BtnAceptar.addActionListener(this::BtnAceptarActionPerformed);

        doc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_doc.png"))); // NOI18N
        doc.setMaximumSize(null);
        doc.setMinimumSize(null);

        nombre_inquilino.setBackground(new java.awt.Color(253, 232, 201));
        nombre_inquilino.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        nombre_inquilino.setForeground(new java.awt.Color(30, 34, 45));
        nombre_inquilino.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nombre_inquilino.setText("Nombre del inquilino");
        nombre_inquilino.addActionListener(this::nombre_inquilinoActionPerformed);

        monto.setBackground(new java.awt.Color(253, 232, 201));
        monto.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        monto.setForeground(new java.awt.Color(30, 34, 45));
        monto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        monto.setText("Monto Pagado");
        monto.setPreferredSize(new java.awt.Dimension(163, 28));

        jButton3.setBackground(new java.awt.Color(30, 34, 45));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(253, 232, 201));
        jButton3.setText("<- REGRESAR ");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 190, Short.MAX_VALUE)
                .addComponent(pagos, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(277, 277, 277))
            .addComponent(footer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(periodo_tiempo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nombre_inquilino, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(monto, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(117, 117, 117)
                        .addComponent(doc, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(pagos))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(nombre_inquilino, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(monto, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(periodo_tiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(doc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(77, 77, 77)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void BtnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAceptarActionPerformed
        if (campoVacio(monto, "Monto Pagado")) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa el monto pagado.",
                "Campo requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (campoVacio(periodo_tiempo, "Periodo")) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa el periodo (ej: Junio 2026).",
                "Campo requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (rutaComprobanteSeleccionada == null) {
            JOptionPane.showMessageDialog(this,
                "Por favor adjunta el comprobante de pago.\nHaz clic en el ícono del documento.",
                "Comprobante requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
 
        double montoValor;
        try {
            montoValor = Double.parseDouble(monto.getText().trim());
            if (montoValor <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El monto debe ser un número mayor a 0.",
                "Monto inválido", JOptionPane.WARNING_MESSAGE);
            return;
        }
 
        java.time.LocalDate fechaValor;
        try {
            fechaValor = java.time.LocalDate.parse(fecha.getText().trim());
        } catch (java.time.format.DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                "Formato de fecha inválido. Usa AAAA-MM-DD (ej: 2026-06-10).",
                "Fecha inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }
 
        int idUsuario = Sesion.getIdUsuarioActivo();
        boolean exito = pagoControlador.registrarPago(
            idUsuario,
            idInmueble,
            montoValor,
            fechaValor,
            periodo_tiempo.getText().trim(),
            rutaComprobanteSeleccionada
        );
 
        if (exito) {
            JOptionPane.showMessageDialog(this, "Pago registrado exitosamente.",
                "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiarFormulario();
            if (onExito != null) onExito.run();
        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar el pago. Intenta de nuevo.",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BtnAceptarActionPerformed
    
    private void fechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fechaActionPerformed

    private void nombre_inquilinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombre_inquilinoActionPerformed
        
    }//GEN-LAST:event_nombre_inquilinoActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (onCancelar != null) onCancelar.run();
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAceptar;
    private javax.swing.JLabel doc;
    private javax.swing.JTextField fecha;
    private javax.swing.JPanel footer;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField monto;
    private javax.swing.JTextField nombre_inquilino;
    private javax.swing.JLabel pagos;
    private javax.swing.JTextField periodo_tiempo;
    // End of variables declaration//GEN-END:variables
}

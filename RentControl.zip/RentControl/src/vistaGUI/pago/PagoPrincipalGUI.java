package vistaGUI.pago;
 
import controlador.InmuebleControlador;
import controlador.PagoControlador;
import modelo.Inmueble;
import modelo.Pago;
import utilidades.Sesion;
import java.util.List;
import java.awt.*;
import javax.swing.*;
 
public class PagoPrincipalGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private final InmuebleControlador inmuebleControlador;
    private final PagoControlador pagoControlador;
    private javax.swing.JPanel panelVistaActual;
 
    
    private final JPanel gridInmuebles;
 
    public PagoPrincipalGUI(InmuebleControlador inmuebleControlador,
                             PagoControlador pagoControlador) {
        this.inmuebleControlador = inmuebleControlador;
        this.pagoControlador     = pagoControlador;
        initComponents();
        this.gridInmuebles = panelInmuebles; 
        
        cargarInmuebles();
        revalidate();
        inicializado = true;
    }
 
    private void cargarInmuebles() {
        gridInmuebles.removeAll();
        gridInmuebles.setPreferredSize(null);
        int id   = Sesion.getIdUsuarioActivo();
        int tipo = Sesion.getTipoUsuarioActivo();
 
        List<Inmueble> lista = tipo == 2
            ? inmuebleControlador.consultarInmueblesPorUsuario(id)
            : inmuebleControlador.consultarInmueblesEnlazados(id);
 
        if (lista.isEmpty()) {
            gridInmuebles.setLayout(new BorderLayout());
            JLabel sin = new JLabel(
                "<html><center>No tienes inmuebles registrados o enlazados.</center></html>",
                SwingConstants.CENTER);
            sin.setForeground(Color.WHITE);
            sin.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            gridInmuebles.add(sin, BorderLayout.CENTER);
        } else {
            gridInmuebles.setLayout(new GridLayout(0, 3, 8, 8));
            int total = lista.size(), sobra = total % 3;
            if (sobra == 1 && total > 1) {
                for (int i = 0; i < total - 1; i++) gridInmuebles.add(crearTarjetaInmueble(lista.get(i)));
                gridInmuebles.add(crearRelleno());
                gridInmuebles.add(crearTarjetaInmueble(lista.get(total - 1)));
                gridInmuebles.add(crearRelleno());
            } else if (sobra == 2) {
                for (Inmueble inm : lista) gridInmuebles.add(crearTarjetaInmueble(inm));
                gridInmuebles.add(crearRelleno());
            } else {
                for (Inmueble inm : lista) gridInmuebles.add(crearTarjetaInmueble(inm));
            }
        }
        gridInmuebles.revalidate();
        gridInmuebles.repaint();
    }
    
    private JButton crearTarjetaInmueble(Inmueble inmueble) {
        String texto = "<html><center>"
            + inmueble.getCalle() + " #" + inmueble.getNumero() + "<br>"
            + "<small>" + inmueble.getColonia() + "</small>"
            + "</center></html>";
        JButton btn = new JButton(texto);
        btn.setBackground(new Color(253, 232, 201));
        btn.setForeground(new Color(30, 34, 45));
        btn.setPreferredSize(new Dimension(155, 55));
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> navegarAPagos(inmueble));
        return btn;
    }
    
    
    private JPanel crearRelleno() {
        JPanel r = new JPanel();
        r.setBackground(new Color(30, 34, 45));
        return r;
    }
    
    private PagoListaGUI panelListaPagosActual;
 
    private void mostrarEnPanelInmuebles(javax.swing.JComponent vista) {
        Historial.setVisible(false);
 
        java.awt.CardLayout cl = new java.awt.CardLayout();
        panelVistaActual = new JPanel(cl);
        panelVistaActual.add(vista, "PAGOS");
 
        panelInmuebles.removeAll();
        panelInmuebles.setLayout(new BorderLayout());
        panelInmuebles.setPreferredSize(new java.awt.Dimension(818, 588));
        panelInmuebles.add(panelVistaActual, BorderLayout.CENTER);
        panelInmuebles.revalidate();
        panelInmuebles.repaint();
    }
 
    private void navegarAPagos(Inmueble inmueble) {
        panelListaPagosActual = new PagoListaGUI(
            pagoControlador,
            inmueble,
            this::volverAInmuebles,
            pago -> navegarAVistaPago(pago)
        );
        mostrarEnPanelInmuebles(panelListaPagosActual);
    }
 
    private void navegarAVistaPago(Pago pago) {
        PagoVistaGUI vista = new PagoVistaGUI(
            pagoControlador,
            pago,
            this::volverAPagos
        );
        mostrarEnPanelInmuebles(vista);
    }
    
    private void volverAInmuebles() {
        panelVistaActual = null;
        panelListaPagosActual = null;
        Historial.setVisible(true);
        cargarInmuebles();
        revalidate(); repaint();
    }
 
    private void volverAPagos() {
        if (panelListaPagosActual != null) {
            mostrarEnPanelInmuebles(panelListaPagosActual);
        } else {
            volverAInmuebles();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Historial = new javax.swing.JLabel();
        panelInmuebles = new javax.swing.JPanel();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setMinimumSize(null);
        setPreferredSize(new java.awt.Dimension(918, 588));

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addGap(363, 363, 363)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        Historial.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        Historial.setForeground(new java.awt.Color(255, 255, 255));
        Historial.setText("Inmuebles");

        panelInmuebles.setBackground(new java.awt.Color(30, 34, 45));

        javax.swing.GroupLayout panelInmueblesLayout = new javax.swing.GroupLayout(panelInmuebles);
        panelInmuebles.setLayout(panelInmueblesLayout);
        panelInmueblesLayout.setHorizontalGroup(
            panelInmueblesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 604, Short.MAX_VALUE)
        );
        panelInmueblesLayout.setVerticalGroup(
            panelInmueblesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 391, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Historial, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(323, 323, 323))
            .addGroup(layout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addComponent(panelInmuebles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(150, Short.MAX_VALUE))
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(Historial)
                .addGap(18, 18, 18)
                .addComponent(panelInmuebles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Historial;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel panelInmuebles;
    // End of variables declaration//GEN-END:variables
}

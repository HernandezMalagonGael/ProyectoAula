package vistaGUI.cuenta;
 
import controlador.UsuarioControlador;
import modelo.Usuario;
import utilidades.Sesion;
import javax.swing.JOptionPane;
 
public class CuentaLecturaGUI extends javax.swing.JPanel {
    
    private boolean inicializado = true;
    private final UsuarioControlador usuarioControlador;
    private Usuario usuarioActivo;
    
    
    public CuentaLecturaGUI() {
        usuarioControlador = new UsuarioControlador();
        initComponents();
        cargarDatosUsuario();
        activarEdicionDobleClick();
        inicializado = true;
    }
 
    
    
    private void cargarDatosUsuario() {
        int idUsuario = Sesion.getIdUsuarioActivo();
        usuarioActivo = usuarioControlador.buscarUsuarioPorId(idUsuario);
        if (usuarioActivo == null) return;
 
        rol.setText("Rol: " + (usuarioActivo.getId_tipo_usuario() == 2 ? "Arrendador" : "Arrendatario"));
        nombre.setText("Nombre: " + usuarioActivo.getNombre());
        correo.setText("Correo: " + usuarioActivo.getCorreo());
        fecha_nac.setText("Nacimiento: " + usuarioActivo.getFecha_nacimiento());
        contraseña.setText("Contraseña: ********");
        if (usuarioActivo.getFecha_registro() != null) {
            registro.setText("Registro: " + usuarioActivo.getFecha_registro().toLocalDate());
        }
        revalidate();
        repaint();
    }
    
    
    private void activarEdicionDobleClick() {
        java.awt.event.MouseAdapter adapter = new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    javax.swing.JLabel lbl = (javax.swing.JLabel) e.getSource();
                    javax.swing.JPanel panel = panelDe(lbl);
                    if (panel == null) return;
 
                    
                    String textoCompleto = lbl.getText();
                    String valor = "";
                    
                    if (lbl == contraseña) {
                        valor = "";
                    } else if (textoCompleto.contains(": ")) {
                        valor = textoCompleto.substring(textoCompleto.indexOf(": ") + 2).trim();
                    } else {
                        valor = textoCompleto;
                    }
 
                    panel.setLayout(new java.awt.BorderLayout());
 
                    
                    javax.swing.JTextField tf;
                    if (lbl == contraseña) {
                        javax.swing.JPasswordField pf = new javax.swing.JPasswordField(valor);
                        pf.setEchoChar('●');
                        tf = pf;
                    } else {
                        tf = new javax.swing.JTextField(valor);
                    }
 
                    tf.setFont(lbl.getFont());
                    tf.setBackground(new java.awt.Color(35, 40, 50));
                    tf.setForeground(new java.awt.Color(253, 230, 201));
                    tf.setCaretColor(new java.awt.Color(253, 230, 201));
                    tf.setBorder(javax.swing.BorderFactory.createLineBorder(
                        new java.awt.Color(253, 230, 201), 1));
 
                    final javax.swing.JPanel p = panel;
                    final javax.swing.JTextField campo = tf;
                    tf.addActionListener(ev -> finalizarEdicion(p, campo, lbl));
                    tf.addFocusListener(new java.awt.event.FocusAdapter() {
                        @Override public void focusLost(java.awt.event.FocusEvent ev) {
                            finalizarEdicion(p, campo, lbl);
                        }
                    });
 
                    panel.remove(lbl);
                    panel.add(tf, java.awt.BorderLayout.CENTER);
                    tf.requestFocus();
                    panel.revalidate();
                    panel.repaint();
                }
            }
        };
 
        
        nombre.addMouseListener(adapter);
        correo.addMouseListener(adapter);
        fecha_nac.addMouseListener(adapter);
        contraseña.addMouseListener(adapter);
 
        
        nombre.setToolTipText("Doble clic para editar");
        correo.setToolTipText("Doble clic para editar");
        fecha_nac.setToolTipText("Doble clic para editar (formato: AAAA-MM-DD)");
        contraseña.setToolTipText("Doble clic para cambiar contraseña");
        
        rol.setToolTipText("El rol no se puede modificar");
        registro.setToolTipText("La fecha de registro no se puede modificar");
    }
    
    
    private javax.swing.JPanel panelDe(javax.swing.JLabel lbl) {
        if (lbl == nombre)     return rolPnael;
        if (lbl == correo)     return nombrePanel;
        if (lbl == fecha_nac)  return fechanacPanel;
        if (lbl == contraseña) return correoPanel;
        return null;
    }
    
    
    private void finalizarEdicion(javax.swing.JPanel panel,
                                   javax.swing.JTextField tf,
                                   javax.swing.JLabel lbl) {
        if (tf.getParent() == null) return;
 
        String nuevoValor = (tf instanceof javax.swing.JPasswordField)
            ? new String(((javax.swing.JPasswordField) tf).getPassword()).trim()
            : tf.getText().trim();
 
        if (!nuevoValor.isBlank()) {
            boolean valido = validarYAplicar(lbl, nuevoValor);
            if (valido) {
                boolean exito = usuarioControlador.actualizarUsuario(usuarioActivo);
                if (exito) {
                    
                    if (lbl == nombre) Sesion.setNombreUsuarioActivo(nuevoValor);
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Error al guardar en la base de datos.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                    
                    cargarDatosUsuario();
                }
            }
        }
 
        
        panel.remove(tf);
        panel.add(lbl, java.awt.BorderLayout.CENTER);
        panel.revalidate();
        panel.repaint();
    }
    
    
    
    private boolean validarYAplicar(javax.swing.JLabel lbl, String valor) {
        if (lbl == nombre) {
            if (valor.length() < 3 || valor.length() > 100) {
                JOptionPane.showMessageDialog(this,
                    "El nombre debe tener entre 3 y 100 caracteres.",
                    "Nombre inválido", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if (!valor.matches("[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ ]+")) {
                JOptionPane.showMessageDialog(this,
                    "El nombre solo puede contener letras y espacios.",
                    "Nombre inválido", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            usuarioActivo.setNombre(valor);
            nombre.setText("Nombre: " + valor);
            return true;
        }
 
        if (lbl == correo) {
            if (!valor.matches("^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-zA-Z]{2,}$")) {
                JOptionPane.showMessageDialog(this,
                    "El correo no tiene un formato válido (ej: usuario@correo.com).",
                    "Correo inválido", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if (valor.length() > 150) {
                JOptionPane.showMessageDialog(this,
                    "El correo no puede superar 150 caracteres.",
                    "Correo inválido", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            usuarioActivo.setCorreo(valor);
            correo.setText("Correo: " + valor);
            return true;
        }
 
        if (lbl == fecha_nac) {
            try {
                java.time.LocalDate fecha = java.time.LocalDate.parse(valor);
                
                java.time.LocalDate hoy = java.time.LocalDate.now();
                java.time.LocalDate limite = hoy.minusYears(120);
                if (fecha.isAfter(hoy)) {
                    JOptionPane.showMessageDialog(this,
                        "La fecha de nacimiento no puede ser futura.",
                        "Fecha inválida", JOptionPane.WARNING_MESSAGE);
                    return false;
                }
                if (fecha.isBefore(limite)) {
                    JOptionPane.showMessageDialog(this,
                        "La fecha de nacimiento no es válida.",
                        "Fecha inválida", JOptionPane.WARNING_MESSAGE);
                    return false;
                }
                
                if (fecha.isAfter(hoy.minusYears(18))) {
                    JOptionPane.showMessageDialog(this,
                        "Debes tener al menos 18 años.",
                        "Edad inválida", JOptionPane.WARNING_MESSAGE);
                    return false;
                }
                usuarioActivo.setFecha_nacimiento(fecha);
                fecha_nac.setText("Nacimiento: " + fecha);
                return true;
            } catch (java.time.format.DateTimeParseException e) {
                JOptionPane.showMessageDialog(this,
                    "Formato de fecha incorrecto. Usa: AAAA-MM-DD (ej: 1995-06-15).",
                    "Fecha inválida", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }
 
        if (lbl == contraseña) {
            if (valor.length() < 6) {
                JOptionPane.showMessageDialog(this,
                    "La contraseña debe tener al menos 6 caracteres.",
                    "Contraseña inválida", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            if (valor.length() > 255) {
                JOptionPane.showMessageDialog(this,
                    "La contraseña no puede superar 255 caracteres.",
                    "Contraseña inválida", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            usuarioActivo.setContrasena(valor);
            contraseña.setText("Contraseña: ********");
            return true;
        }
 
        return false;
    }
     
    
    
    
    
    
 
 
 
 




    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cuenta = new javax.swing.JLabel();
        rolPnael = new javax.swing.JPanel();
        nombre = new javax.swing.JLabel();
        nombrePanel = new javax.swing.JPanel();
        correo = new javax.swing.JLabel();
        correoPanel = new javax.swing.JPanel();
        contraseña = new javax.swing.JLabel();
        fechanacPanel = new javax.swing.JPanel();
        fecha_nac = new javax.swing.JLabel();
        registroPanel = new javax.swing.JPanel();
        registro = new javax.swing.JLabel();
        contraseñaPanel = new javax.swing.JPanel();
        rol = new javax.swing.JLabel();
        usuario_img = new javax.swing.JLabel();
        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setMinimumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        cuenta.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        cuenta.setForeground(new java.awt.Color(255, 255, 255));
        cuenta.setText("Cuenta");

        rolPnael.setBackground(new java.awt.Color(253, 232, 201));
        rolPnael.setForeground(new java.awt.Color(30, 34, 45));
        rolPnael.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nombre.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        nombre.setForeground(new java.awt.Color(30, 34, 45));
        nombre.setText("Nombre:");
        rolPnael.add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 430, -1));

        nombrePanel.setBackground(new java.awt.Color(253, 232, 201));
        nombrePanel.setForeground(new java.awt.Color(30, 34, 45));
        nombrePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        correo.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        correo.setForeground(new java.awt.Color(30, 34, 45));
        correo.setText("Correo:");
        nombrePanel.add(correo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 450, -1));

        correoPanel.setBackground(new java.awt.Color(253, 232, 201));
        correoPanel.setForeground(new java.awt.Color(30, 34, 45));
        correoPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        contraseña.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        contraseña.setForeground(new java.awt.Color(30, 34, 45));
        contraseña.setText("Contraseña:");
        correoPanel.add(contraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 450, -1));

        fechanacPanel.setBackground(new java.awt.Color(253, 232, 201));
        fechanacPanel.setForeground(new java.awt.Color(30, 34, 45));
        fechanacPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fecha_nac.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        fecha_nac.setForeground(new java.awt.Color(30, 34, 45));
        fecha_nac.setText("Fecha de nacimiento:");
        fechanacPanel.add(fecha_nac, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 440, 20));

        registroPanel.setBackground(new java.awt.Color(253, 232, 201));
        registroPanel.setForeground(new java.awt.Color(30, 34, 45));
        registroPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        registro.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        registro.setForeground(new java.awt.Color(30, 34, 45));
        registro.setText("Registro");
        registro.setMaximumSize(new java.awt.Dimension(80, 22));
        registro.setMinimumSize(new java.awt.Dimension(80, 22));
        registro.setPreferredSize(new java.awt.Dimension(80, 22));
        registroPanel.add(registro, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 10, 210, -1));

        contraseñaPanel.setBackground(new java.awt.Color(253, 232, 201));
        contraseñaPanel.setForeground(new java.awt.Color(30, 34, 45));
        contraseñaPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rol.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        rol.setForeground(new java.awt.Color(30, 34, 45));
        rol.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        rol.setText("Rol:");
        contraseñaPanel.add(rol, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 200, 20));

        usuario_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_user.png"))); // NOI18N

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(310, 310, 310))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(usuario_img)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(contraseñaPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(registroPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(cuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(150, 150, 150))
                    .addComponent(fechanacPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(correoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nombrePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rolPnael, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(63, 63, 63))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(cuenta)
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(rolPnael, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(nombrePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(correoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(fechanacPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(contraseñaPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(registroPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 95, Short.MAX_VALUE)
                        .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(usuario_img)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    
    
    
    
    

    
    
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel contraseña;
    private javax.swing.JPanel contraseñaPanel;
    private javax.swing.JLabel correo;
    private javax.swing.JPanel correoPanel;
    private javax.swing.JLabel cuenta;
    private javax.swing.JLabel fecha_nac;
    private javax.swing.JPanel fechanacPanel;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel nombre;
    private javax.swing.JPanel nombrePanel;
    private javax.swing.JLabel registro;
    private javax.swing.JPanel registroPanel;
    private javax.swing.JLabel rol;
    private javax.swing.JPanel rolPnael;
    private javax.swing.JLabel usuario_img;
    // End of variables declaration//GEN-END:variables
}

package vistaGUI.reporte;
 
import controlador.ReporteControlador;
import utilidades.Sesion;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ItemEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
 
public class ReporteRegistroGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private ReporteControlador reporteControlador;
    private Runnable onExito;
    private Runnable onCancelar;
    private String rutaImagenSeleccionada = null;
    private int idInmueble; // recibido desde ReporteListaGUI
 
    private JComboBox<String> comboZona;
    private JComboBox<String> comboTipo;
    private JTextField txtFecha;
    private JTextArea txtDescripcion;
 
    private final Map<String, String[]> mapaProblemas = new HashMap<>();
    
    public ReporteRegistroGUI(ReporteControlador reporteControlador, int idInmueble, Runnable onExito, Runnable onCancelar) {
        this.reporteControlador = reporteControlador;
        this.idInmueble         = idInmueble;
        this.onExito = onExito;
        this.onCancelar = onCancelar;
 
        inicializarDiccionarioProblemas(); 
        initComponents();
        transformarInterfaz();
        configurarEventos();
        activarSelectorImagen();
        inicializado = true;
    }

    
    private void inicializarDiccionarioProblemas() {
        mapaProblemas.put("Baño", new String[]{
            "Plomería/agua",
            "Humedad / Filtraciones",
            "Eléctrico",
            "Sanitarios",
            "Acabados"
        });
        mapaProblemas.put("Cocina", new String[]{
            "Plomería / Agua",
            "Gas",
            "Eléctrico",
            "Ventilación",
            "Acabados"
        });
        mapaProblemas.put("Habitaciones", new String[]{
            "Eléctrico",
            "Humedad / Filtraciones",
            "Ventanas / Puertas",
            "Acabados",
            "Ventilación / Clima"
        });
        mapaProblemas.put("Sala/Comedor", new String[]{
            "Eléctrico",
            "Humedad / Filtraciones",
            "Ventanas / Puertas",
            "Acabados",
            "Aislamiento"
        });
        mapaProblemas.put("Área de lavado", new String[]{
            "Plomería / Agua",
            "Eléctrico",
            "Humedad",
            "Instalaciones"
        });
        mapaProblemas.put("Área común", new String[]{
            "Iluminación",
            "Estructura",
            "Seguridad",
            "Limpieza / Plagas"
        });
        mapaProblemas.put("Fachada/Exterior", new String[]{
            "Estructura",
            "Humedad",
            "Puertas / Accesos",
            "Pintura / Acabados"
        });
    }
 
    private void transformarInterfaz() {
        Color colorFondoTextos = new Color(253, 232, 201);
        Color colorTexto = new Color(30, 34, 45);
        Font fuenteCampos = new Font("Segoe UI", Font.PLAIN, 12);
 
        zona_reporte.setLayout(new BorderLayout());
        zona_reporte.removeAll();
        comboZona = new JComboBox<>(mapaProblemas.keySet().toArray(new String[0]));
        comboZona.setBackground(colorFondoTextos);
        comboZona.setForeground(colorTexto);
        comboZona.setFont(fuenteCampos);
        comboZona.setBorder(BorderFactory.createTitledBorder(null, "Zona del reporte", 0, 0, fuenteCampos, colorTexto));
        zona_reporte.add(comboZona, BorderLayout.CENTER);
        
        tipo_reporte.setLayout(new BorderLayout());
        tipo_reporte.removeAll();
        comboTipo = new JComboBox<>();
        comboTipo.setBackground(colorFondoTextos);
        comboTipo.setForeground(colorTexto);
        comboTipo.setFont(fuenteCampos);
        comboTipo.setBorder(BorderFactory.createTitledBorder(null, "Tipo de reporte", 0, 0, fuenteCampos, colorTexto));
        tipo_reporte.add(comboTipo, BorderLayout.CENTER);
 
        fecha_reporte.setLayout(new BorderLayout());
        fecha_reporte.removeAll();
        txtFecha = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        txtFecha.setBackground(colorFondoTextos);
        txtFecha.setForeground(colorTexto);
        txtFecha.setFont(fuenteCampos);
        txtFecha.setBorder(BorderFactory.createTitledBorder(null, "Fecha del reporte", 0, 0, fuenteCampos, colorTexto));
        fecha_reporte.add(txtFecha, BorderLayout.CENTER);
 
        descripcion_reporte1.setLayout(new BorderLayout());
        descripcion_reporte1.removeAll();
        txtDescripcion = new JTextArea();
        txtDescripcion.setBackground(colorFondoTextos);
        txtDescripcion.setForeground(colorTexto);
        txtDescripcion.setFont(fuenteCampos);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        JScrollPane scrollArea = new JScrollPane(txtDescripcion);
        scrollArea.setBorder(BorderFactory.createTitledBorder(null, "Descripción del reporte", 0, 0, fuenteCampos, colorTexto));
        descripcion_reporte1.add(scrollArea, BorderLayout.CENTER);
 
        zona_reporte.revalidate();
        zona_reporte.repaint();
        tipo_reporte.revalidate();
        tipo_reporte.repaint();
        fecha_reporte.revalidate();
        fecha_reporte.repaint();
        descripcion_reporte1.revalidate();
        descripcion_reporte1.repaint();
 
        this.revalidate();
        this.repaint();
    }
 
    
    
    
    private void configurarEventos() {
        comboZona.addItemListener((ItemEvent e) -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                actualizarComboTipos((String) comboZona.getSelectedItem());
            }
        });
 
        if (comboZona.getSelectedItem() != null) {
            actualizarComboTipos((String) comboZona.getSelectedItem());
        }
    }
    
   
    
    private void actualizarComboTipos(String zonaSeleccionada) {
        comboTipo.removeAllItems();
        String[] tipos = mapaProblemas.get(zonaSeleccionada);
        if (tipos != null) {
            for (String t : tipos) {
                comboTipo.addItem(t);
            }
        }
    }
 
    private void activarSelectorImagen() {
        img_img.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        img_img.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                    "Imágenes", "png", "jpg", "jpeg"));
                if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                    rutaImagenSeleccionada = chooser.getSelectedFile().getAbsolutePath();
                    ImageIcon icono = new ImageIcon(rutaImagenSeleccionada);
                    java.awt.Image escalada = icono.getImage().getScaledInstance(
                        img_img.getWidth(), img_img.getHeight(), java.awt.Image.SCALE_SMOOTH);
                    img_img.setIcon(new ImageIcon(escalada));
                    img_img.setText("");
                }
            }
        });
    }
    
    private void ejecutarGuardadoReporte() {
        String zonaSeleccionada = (String) comboZona.getSelectedItem();
        String tipoSeleccionado = (String) comboTipo.getSelectedItem();
        String fechaTexto = txtFecha.getText().trim();
        String descripcionTexto = txtDescripcion.getText().trim();
 
        if (fechaTexto.isEmpty() || descripcionTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Completa todos los campos de texto.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (rutaImagenSeleccionada == null) {
            JOptionPane.showMessageDialog(this,
                "Por favor, adjunta una imagen como evidencia.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
 
        int idInquilino = Sesion.getIdUsuarioActivo();
        int idLugarFicticio = 1;
        int idCategoriaFicticia = 1;
 
        String descripcionCompleta = "[Zona: " + zonaSeleccionada
            + " - Tipo: " + tipoSeleccionado + "] " + descripcionTexto;
 
        boolean exito = reporteControlador.registrarReporte(
            idInmueble,
            idInquilino,
            idLugarFicticio,
            idCategoriaFicticia,
            descripcionCompleta,
            rutaImagenSeleccionada
        );
 
        if (exito) {
            JOptionPane.showMessageDialog(this,
                "¡Reporte guardado con éxito!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            if (onExito != null) {
                onExito.run(); 
            }
        } else {
            JOptionPane.showMessageDialog(this,
                "Error al guardar el reporte.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        img_img = new javax.swing.JLabel();
        reporte = new javax.swing.JLabel();
        zona_reporte = new javax.swing.JPanel();
        zona = new javax.swing.JLabel();
        zonaElegir = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        fecha_reporte = new javax.swing.JPanel();
        fecha = new javax.swing.JLabel();
        tipo_reporte = new javax.swing.JPanel();
        tipo = new javax.swing.JLabel();
        tipoElegir = new javax.swing.JScrollPane();
        jList2 = new javax.swing.JList<>();
        actualizar = new javax.swing.JButton();
        descripcion_reporte1 = new javax.swing.JPanel();
        descripcion = new javax.swing.JLabel();
        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        img_img.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_img.png"))); // NOI18N

        reporte.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        reporte.setForeground(new java.awt.Color(255, 255, 255));
        reporte.setText("Registrar Reporte");

        zona_reporte.setBackground(new java.awt.Color(253, 232, 201));

        zona.setBackground(new java.awt.Color(30, 34, 45));
        zona.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        zona.setText("Zona del reporte");

        jList1.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        zonaElegir.setViewportView(jList1);

        javax.swing.GroupLayout zona_reporteLayout = new javax.swing.GroupLayout(zona_reporte);
        zona_reporte.setLayout(zona_reporteLayout);
        zona_reporteLayout.setHorizontalGroup(
            zona_reporteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(zona_reporteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(zona)
                .addGap(47, 47, 47)
                .addComponent(zonaElegir)
                .addContainerGap())
        );
        zona_reporteLayout.setVerticalGroup(
            zona_reporteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(zona_reporteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(zona_reporteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(zonaElegir, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(zona_reporteLayout.createSequentialGroup()
                        .addComponent(zona)
                        .addGap(0, 36, Short.MAX_VALUE)))
                .addContainerGap())
        );

        fecha_reporte.setBackground(new java.awt.Color(253, 232, 201));

        fecha.setBackground(new java.awt.Color(30, 34, 45));
        fecha.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        fecha.setText("Fecha del reporte");

        javax.swing.GroupLayout fecha_reporteLayout = new javax.swing.GroupLayout(fecha_reporte);
        fecha_reporte.setLayout(fecha_reporteLayout);
        fecha_reporteLayout.setHorizontalGroup(
            fecha_reporteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fecha_reporteLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        fecha_reporteLayout.setVerticalGroup(
            fecha_reporteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fecha_reporteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(fecha, javax.swing.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addContainerGap())
        );

        tipo_reporte.setBackground(new java.awt.Color(253, 232, 201));

        tipo.setBackground(new java.awt.Color(30, 34, 45));
        tipo.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        tipo.setText("Tipo de reporte");

        jList2.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jList2.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        tipoElegir.setViewportView(jList2);

        javax.swing.GroupLayout tipo_reporteLayout = new javax.swing.GroupLayout(tipo_reporte);
        tipo_reporte.setLayout(tipo_reporteLayout);
        tipo_reporteLayout.setHorizontalGroup(
            tipo_reporteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tipo_reporteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tipo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tipoElegir, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        tipo_reporteLayout.setVerticalGroup(
            tipo_reporteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tipo_reporteLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(tipo)
                .addContainerGap(38, Short.MAX_VALUE))
            .addGroup(tipo_reporteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tipoElegir, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        actualizar.setBackground(new java.awt.Color(253, 232, 201));
        actualizar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        actualizar.setForeground(new java.awt.Color(30, 34, 45));
        actualizar.setText("Guardar");
        actualizar.addActionListener(this::actualizarActionPerformed);

        descripcion_reporte1.setBackground(new java.awt.Color(253, 232, 201));

        descripcion.setBackground(new java.awt.Color(30, 34, 45));
        descripcion.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        descripcion.setText("Descripción del reporte");

        javax.swing.GroupLayout descripcion_reporte1Layout = new javax.swing.GroupLayout(descripcion_reporte1);
        descripcion_reporte1.setLayout(descripcion_reporte1Layout);
        descripcion_reporte1Layout.setHorizontalGroup(
            descripcion_reporte1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(descripcion_reporte1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        descripcion_reporte1Layout.setVerticalGroup(
            descripcion_reporte1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(descripcion_reporte1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(descripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addGap(363, 363, 363)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jButton3.setBackground(new java.awt.Color(30, 34, 45));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(253, 232, 201));
        jButton3.setText("<- REGRESAR ");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(416, 416, 416)
                        .addComponent(fecha_reporte, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(img_img)
                        .addGap(113, 113, 113)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(descripcion_reporte1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tipo_reporte, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(zona_reporte, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(81, 81, 81))
            .addGroup(layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(actualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(reporte)
                .addGap(296, 296, 296))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(reporte)
                        .addGap(41, 41, 41)
                        .addComponent(zona_reporte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tipo_reporte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(descripcion_reporte1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(img_img)
                        .addGap(1, 1, 1)))
                .addComponent(fecha_reporte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(actualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualizarActionPerformed
        ejecutarGuardadoReporte();
    }//GEN-LAST:event_actualizarActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (onCancelar != null) onCancelar.run();
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualizar;
    private javax.swing.JLabel descripcion;
    private javax.swing.JPanel descripcion_reporte1;
    private javax.swing.JLabel fecha;
    private javax.swing.JPanel fecha_reporte;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel img_img;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<String> jList1;
    private javax.swing.JList<String> jList2;
    private javax.swing.JLabel reporte;
    private javax.swing.JLabel tipo;
    private javax.swing.JScrollPane tipoElegir;
    private javax.swing.JPanel tipo_reporte;
    private javax.swing.JLabel zona;
    private javax.swing.JScrollPane zonaElegir;
    private javax.swing.JPanel zona_reporte;
    // End of variables declaration//GEN-END:variables
}

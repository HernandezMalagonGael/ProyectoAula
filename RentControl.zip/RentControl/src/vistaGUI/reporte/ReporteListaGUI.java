package vistaGUI.reporte;
 
import controlador.ReporteControlador;
import modelo.Inmueble;
import modelo.Reporte;
import utilidades.Sesion;
import java.util.List;
 
public class ReporteListaGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private final ReporteControlador reporteControlador;
    private final Inmueble inmueble;        
    private final Runnable onVolver;        
    private java.awt.CardLayout cardLayout;
    
    public ReporteListaGUI(ReporteControlador reporteControlador, Inmueble inmueble, Runnable onVolver) {
        this.reporteControlador = reporteControlador;
        this.inmueble           = inmueble;
        this.onVolver           = onVolver;
 
        initComponents();
 
        reporte_boton.setVisible(Sesion.getTipoUsuarioActivo() == 3);
 
        removeAll();
        cardLayout = new java.awt.CardLayout();
        setLayout(cardLayout);
        add(jPanel1, "LISTA");
 
        cargarReportes();
        revalidate();
        inicializado = true;
    }
    
    
    
    
    
    private void cargarReportes() {
        panelReportes1.removeAll();
        panelReportes1.setLayout(new java.awt.BorderLayout());
 
        List<Reporte> lista = reporteControlador.consultarReportesPorInmueble(inmueble.getId_inmueble());
 
        javax.swing.JPanel grid = new javax.swing.JPanel(new java.awt.GridLayout(0, 3, 6, 6));
        grid.setBackground(new java.awt.Color(30, 34, 45));
 
        if (lista.isEmpty()) {
            javax.swing.JLabel sinReportes = new javax.swing.JLabel(
                "No hay reportes para este inmueble.", javax.swing.SwingConstants.CENTER);
            sinReportes.setForeground(java.awt.Color.WHITE);
            grid.add(sinReportes);
        } else {
            int total = lista.size();
            int sobra = total % 3;
 
            if (sobra == 1 && total > 1) {
                for (int i = 0; i < total - 1; i++) grid.add(crearTarjetaReporte(lista.get(i)));
                grid.add(crearRelleno());
                grid.add(crearTarjetaReporte(lista.get(total - 1)));
                grid.add(crearRelleno());
            } else if (sobra == 2) {
                for (Reporte r : lista) grid.add(crearTarjetaReporte(r));
                grid.add(crearRelleno());
            } else {
                for (Reporte r : lista) grid.add(crearTarjetaReporte(r));
            }
        }
 
        javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(grid);
        scroll.setBackground(new java.awt.Color(30, 34, 45));
        scroll.setBorder(null);
        scroll.getViewport().setBackground(new java.awt.Color(30, 34, 45));
        scroll.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
 
        panelReportes1.add(scroll, java.awt.BorderLayout.CENTER);
        panelReportes1.revalidate();
        panelReportes1.repaint();
    }
 
    
    
    
    private javax.swing.JButton crearTarjetaReporte(Reporte reporte) {
        String texto = "<html><center>"
            + "<b>Reporte #" + reporte.getId_reporte_mantenimiento() + "</b><br>"
            + "<small>" + reporte.getEstado_mantenimiento() + "</small>"
            + "</center></html>";
 
        javax.swing.JButton btn = new javax.swing.JButton(texto);
        btn.setBackground(new java.awt.Color(253, 232, 201));
        btn.setForeground(new java.awt.Color(30, 34, 45));
        btn.setPreferredSize(new java.awt.Dimension(130, 60));
        btn.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 10));
        btn.setFocusPainted(false);
        btn.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        btn.addActionListener(e -> navegarAVista(reporte));
        return btn;
    }
 
    private javax.swing.JPanel crearRelleno() {
        javax.swing.JPanel r = new javax.swing.JPanel();
        r.setBackground(new java.awt.Color(30, 34, 45));
        r.setOpaque(true);
        return r;
    }
 
    private void navegarAVista(Reporte reporte) {
        while (getComponentCount() > 1) remove(1);
        ReporteVistaGUI vista = new ReporteVistaGUI(
            reporteControlador,
            reporte,
            Sesion.getTipoUsuarioActivo(),
            () -> volverALista()
        );
        add(vista, "VISTA");
        cardLayout.show(this, "VISTA");
        revalidate();
        repaint();
    }
 
    private void volverALista() {
        while (getComponentCount() > 1) remove(1);
        cardLayout.show(this, "LISTA");
        cargarReportes();
        revalidate();
        repaint();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        reporte_mantenimiento = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        panelReportes1 = new javax.swing.JPanel();
        reporte_boton = new javax.swing.JButton();
        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(30, 34, 45));
        jPanel1.setMaximumSize(null);
        jPanel1.setPreferredSize(new java.awt.Dimension(818, 588));

        reporte_mantenimiento.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        reporte_mantenimiento.setForeground(new java.awt.Color(255, 255, 255));
        reporte_mantenimiento.setText("Reporte de mantenimiento");

        jButton3.setBackground(new java.awt.Color(30, 34, 45));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(253, 232, 201));
        jButton3.setText("<- REGRESAR ");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        panelReportes1.setBackground(new java.awt.Color(30, 34, 45));

        javax.swing.GroupLayout panelReportes1Layout = new javax.swing.GroupLayout(panelReportes1);
        panelReportes1.setLayout(panelReportes1Layout);
        panelReportes1Layout.setHorizontalGroup(
            panelReportes1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 655, Short.MAX_VALUE)
        );
        panelReportes1Layout.setVerticalGroup(
            panelReportes1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 294, Short.MAX_VALUE)
        );

        reporte_boton.setBackground(new java.awt.Color(253, 232, 201));
        reporte_boton.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        reporte_boton.setForeground(new java.awt.Color(30, 34, 45));
        reporte_boton.setText("Agregar reporte");
        reporte_boton.addActionListener(this::reporte_botonActionPerformed);

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(305, 305, 305))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 143, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(reporte_mantenimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(201, 201, 201))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(panelReportes1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(114, 114, 114))))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(reporte_boton, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(368, 368, 368))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton3)
                .addGap(15, 15, 15)
                .addComponent(reporte_mantenimiento)
                .addGap(36, 36, 36)
                .addComponent(panelReportes1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addComponent(reporte_boton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 918, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 582, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents
    
    
    private void reporte_botonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reporte_botonActionPerformed
        while (getComponentCount() > 1) remove(1);
        ReporteRegistroGUI registro = new ReporteRegistroGUI(
            reporteControlador,
            inmueble.getId_inmueble(),
            () -> volverALista(),
            () -> volverALista()
        );
        add(registro, "REGISTRO");
        cardLayout.show(this, "REGISTRO");
        revalidate();
        repaint();
    }//GEN-LAST:event_reporte_botonActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (onVolver != null) onVolver.run();
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel footer;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel panelReportes1;
    private javax.swing.JButton reporte_boton;
    private javax.swing.JLabel reporte_mantenimiento;
    // End of variables declaration//GEN-END:variables
}

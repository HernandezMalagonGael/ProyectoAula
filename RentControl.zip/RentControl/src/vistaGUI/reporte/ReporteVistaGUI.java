package vistaGUI.reporte;
 
import controlador.ReporteControlador;
import modelo.Reporte;
import java.awt.Color;
import javax.swing.JOptionPane;
 
public class ReporteVistaGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private ReporteControlador reporteControlador;
    private Reporte reporte;
    private int rolUsuario;
    private final Runnable onVolver;
    
    
    public ReporteVistaGUI(ReporteControlador reporteControlador, Reporte reporte, int rolUsuario, Runnable onVolver) {
        this.onVolver = onVolver;
        this.reporteControlador = reporteControlador;
        this.reporte = reporte;
        this.rolUsuario = rolUsuario;
 
        initComponents();
        mostrarDatosReporte();
        configurarPermisos();
        actualizarBarraEstado();
        inicializado = true;
    }
 
    private void mostrarDatosReporte() {
        if (reporte != null) {
            nombre_reporte.setText("Reporte #" + reporte.getId_reporte_mantenimiento());
            fecha.setText("Fecha: " + (reporte.getFecha_reporte() != null
                ? reporte.getFecha_reporte().toString() : "No disponible"));
            tipo.setText("Categoría Problema ID: " + reporte.getId_categoria_problema());
            descripcion.setText("<html><body style='width: 250px;'>Descripción: "
                + reporte.getDescripcion() + "</body></html>");
        }
    }
 
    private void configurarPermisos() {
        actualizar.setVisible(rolUsuario == 2);
    }
 
    
    private void actualizarBarraEstado() {
        if (reporte == null || reporte.getEstado_mantenimiento() == null) return;
 
        String est = reporte.getEstado_mantenimiento().toLowerCase().trim();
 
        switch (est) {
            case "pendiente", "solicitado" -> {
                estado.setText("● SOLICITADO  ○ En Revisión  ○ Completado");
                estadopanel.setBackground(new Color(230, 80, 80));
                estado.setForeground(Color.WHITE);
            }
            case "revision", "en revision", "en_proceso" -> {
                estado.setText("○ Solicitado  ● EN REVISIÓN  ○ Completado");
                estadopanel.setBackground(new Color(240, 170, 60));
                estado.setForeground(Color.WHITE);
            }
            case "completado", "finalizado" -> {
                estado.setText("○ Solicitado  ○ En Revisión  ● COMPLETADO");
                estadopanel.setBackground(new Color(80, 180, 100));
                estado.setForeground(Color.WHITE);
            }
            default -> {
                estado.setText("Estado: " + est.toUpperCase());
                estadopanel.setBackground(new Color(253, 232, 201));
                estado.setForeground(new Color(30, 34, 45));
            }
        }
    }
 
    private void actualizarActionPerformed(java.awt.event.ActionEvent evt) {
        if (reporte == null) return;
 
        String[] opciones = {"Solicitado", "En Revision", "Completado"};
        String seleccion = (String) JOptionPane.showInputDialog(
            this,
            "Selecciona el nuevo estado del reporte:",
            "Actualizar estado",
            JOptionPane.PLAIN_MESSAGE,
            null,
            opciones,
            reporte.getEstado_mantenimiento()
        );
 
        if (seleccion == null) return;
 
        String estadoBD = switch (seleccion) {
            case "Solicitado" -> "pendiente";
            case "En Revision" -> "en_proceso";
            case "Completado" -> "completado";
            default -> seleccion;
        };
        reporte.setEstado_mantenimiento(estadoBD);
        boolean exito = reporteControlador.actualizarReporte(reporte);
 
        if (exito) {
            actualizarBarraEstado(); 
            JOptionPane.showMessageDialog(this,
                "Estado actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                "Error al actualizar el estado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nombre_reporte = new javax.swing.JLabel();
        tipo_reporte = new javax.swing.JPanel();
        tipo = new javax.swing.JLabel();
        fecha_reporte = new javax.swing.JPanel();
        fecha = new javax.swing.JLabel();
        descripcion_reporte = new javax.swing.JPanel();
        descripcion = new javax.swing.JLabel();
        estadopanel = new javax.swing.JPanel();
        estado = new javax.swing.JLabel();
        actualizar = new javax.swing.JButton();
        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        nombre_reporte.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        nombre_reporte.setForeground(new java.awt.Color(255, 255, 255));
        nombre_reporte.setText("Nombre del reporte");

        tipo_reporte.setBackground(new java.awt.Color(253, 232, 201));
        tipo_reporte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tipo.setBackground(new java.awt.Color(30, 34, 45));
        tipo.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tipo.setForeground(new java.awt.Color(30, 34, 45));
        tipo.setText("Tipo de reporte");
        tipo_reporte.add(tipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        fecha_reporte.setBackground(new java.awt.Color(253, 232, 201));
        fecha_reporte.setPreferredSize(new java.awt.Dimension(100, 45));
        fecha_reporte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fecha.setBackground(new java.awt.Color(30, 34, 45));
        fecha.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        fecha.setForeground(new java.awt.Color(30, 34, 45));
        fecha.setText("Fecha del reporte");
        fecha_reporte.add(fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        descripcion_reporte.setBackground(new java.awt.Color(253, 232, 201));
        descripcion_reporte.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        descripcion.setBackground(new java.awt.Color(30, 34, 45));
        descripcion.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        descripcion.setForeground(new java.awt.Color(30, 34, 45));
        descripcion.setText("Descripción del reporte");
        descripcion_reporte.add(descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        estadopanel.setBackground(new java.awt.Color(253, 232, 201));
        estadopanel.setForeground(new java.awt.Color(30, 34, 45));
        estadopanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        estado.setBackground(new java.awt.Color(30, 34, 45));
        estado.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        estado.setForeground(new java.awt.Color(30, 34, 45));
        estado.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        estado.setText("Solicitado");
        estadopanel.add(estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 420, 60));

        actualizar.setBackground(new java.awt.Color(253, 232, 201));
        actualizar.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        actualizar.setForeground(new java.awt.Color(30, 34, 45));
        actualizar.setText("Actualizar");
        actualizar.addActionListener(this::actualizarActionPerformed);

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(314, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(308, 308, 308))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_img.png"))); // NOI18N

        jButton3.setBackground(new java.awt.Color(30, 34, 45));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(253, 232, 201));
        jButton3.setText("<- REGRESAR ");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(actualizar))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(fecha_reporte, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tipo_reporte, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(estadopanel, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(17, 17, 17)
                            .addComponent(nombre_reporte)))
                    .addComponent(descripcion_reporte, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(62, 62, 62))
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(nombre_reporte)
                        .addGap(34, 34, 34)
                        .addComponent(fecha_reporte, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tipo_reporte, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(descripcion_reporte, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(estadopanel, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addGap(31, 31, 31)
                        .addComponent(actualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (onVolver != null) onVolver.run();
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualizar;
    private javax.swing.JLabel descripcion;
    private javax.swing.JPanel descripcion_reporte;
    private javax.swing.JLabel estado;
    private javax.swing.JPanel estadopanel;
    private javax.swing.JLabel fecha;
    private javax.swing.JPanel fecha_reporte;
    private javax.swing.JPanel footer;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel nombre_reporte;
    private javax.swing.JLabel tipo;
    private javax.swing.JPanel tipo_reporte;
    // End of variables declaration//GEN-END:variables
}

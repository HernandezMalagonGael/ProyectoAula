package vistaGUI.reporte;
 
import controlador.InmuebleControlador;
import controlador.ReporteControlador;
import modelo.Inmueble;
import utilidades.Sesion;
import java.util.List;
 
public class ReportePrincipalGUI extends javax.swing.JPanel {
 
    private boolean inicializado = false;
    private final InmuebleControlador inmuebleControlador;
    private final ReporteControlador reporteControlador;
    private ReporteListaGUI panelListaActual;
    private java.awt.LayoutManager layoutOriginal;
 
    public ReportePrincipalGUI() {
        this.inmuebleControlador = new InmuebleControlador();
        this.reporteControlador  = new ReporteControlador();
 
        initComponents();
 
        cargarInmuebles();
        revalidate();
        inicializado = true;
    }
 
    private void cargarInmuebles() {
        panelInmuebles.removeAll();
        panelInmuebles.setLayout(new java.awt.BorderLayout());
        panelInmuebles.setPreferredSize(null);
 
        int idUsuario   = Sesion.getIdUsuarioActivo();
        int tipoUsuario = Sesion.getTipoUsuarioActivo();
 
        
        List<Inmueble> lista = (tipoUsuario == 2)
            ? inmuebleControlador.consultarInmueblesPorUsuario(idUsuario)
            : inmuebleControlador.consultarInmueblesEnlazados(idUsuario);
 
        javax.swing.JPanel grid = new javax.swing.JPanel(new java.awt.GridLayout(0, 3, 6, 6));
        grid.setBackground(new java.awt.Color(30, 34, 45));
 
        if (lista.isEmpty()) {
            javax.swing.JLabel sinInmuebles = new javax.swing.JLabel(
                "No tienes inmuebles registrados.", javax.swing.SwingConstants.CENTER);
            sinInmuebles.setForeground(java.awt.Color.WHITE);
            grid.add(sinInmuebles);
        } else {
            int total = lista.size();
            int sobra = total % 3;
 
            if (sobra == 1 && total > 1) {
                for (int i = 0; i < total - 1; i++) grid.add(crearTarjeta(lista.get(i)));
                grid.add(crearRelleno());
                grid.add(crearTarjeta(lista.get(total - 1)));
                grid.add(crearRelleno());
            } else if (sobra == 2) {
                for (Inmueble inm : lista) grid.add(crearTarjeta(inm));
                grid.add(crearRelleno());
            } else {
                for (Inmueble inm : lista) grid.add(crearTarjeta(inm));
            }
        }
 
        javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(grid);
        scroll.setBackground(new java.awt.Color(30, 34, 45));
        scroll.setBorder(null);
        scroll.getViewport().setBackground(new java.awt.Color(30, 34, 45));
        scroll.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
 
        panelInmuebles.add(scroll, java.awt.BorderLayout.CENTER);
        panelInmuebles.revalidate();
        panelInmuebles.repaint();
    }
 
    private javax.swing.JButton crearTarjeta(Inmueble inm) {
        String texto = "<html><center>"
            + "<b>" + inm.getCalle() + " " + inm.getNumero() + "</b><br>"
            + "<small>" + inm.getColonia() + "</small>"
            + "</center></html>";
 
        javax.swing.JButton btn = new javax.swing.JButton(texto);
        btn.setBackground(new java.awt.Color(253, 232, 201));
        btn.setForeground(new java.awt.Color(30, 34, 45));
        btn.setPreferredSize(new java.awt.Dimension(160, 80));
        btn.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 11));
        btn.setFocusPainted(false);
        btn.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
 
        btn.addActionListener(e -> navegarAReportesDeInmueble(inm));
        return btn;
    }
 
    private javax.swing.JPanel crearRelleno() {
        javax.swing.JPanel r = new javax.swing.JPanel();
        r.setBackground(new java.awt.Color(30, 34, 45));
        r.setOpaque(true);
        return r;
    }
 
    private void navegarAReportesDeInmueble(Inmueble inmueble) {
        panelListaActual = new ReporteListaGUI(
            reporteControlador,
            inmueble,
            () -> volverAPrincipal()
        );
 
        if (layoutOriginal == null) {
            layoutOriginal = this.getLayout();
        }
 
        this.removeAll();
        this.setLayout(new java.awt.BorderLayout());
        this.add(panelListaActual, java.awt.BorderLayout.CENTER);
        this.revalidate();
        this.repaint();
    }
 
    private void volverAPrincipal() {
        panelListaActual = null;
 
        this.removeAll();
        if (layoutOriginal != null) {
            this.setLayout(layoutOriginal);
        }
        this.add(Historial);
        this.add(panelInmuebles);
        this.add(footer);
        Historial.setVisible(true);
 
        cargarInmuebles();
        revalidate();
        repaint();
    }
 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Historial = new javax.swing.JLabel();
        panelInmuebles = new javax.swing.JPanel();
        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setMinimumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        Historial.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        Historial.setForeground(new java.awt.Color(255, 255, 255));
        Historial.setText("Inmuebles");

        panelInmuebles.setBackground(new java.awt.Color(30, 34, 45));

        javax.swing.GroupLayout panelInmueblesLayout = new javax.swing.GroupLayout(panelInmuebles);
        panelInmuebles.setLayout(panelInmueblesLayout);
        panelInmueblesLayout.setHorizontalGroup(
            panelInmueblesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 620, Short.MAX_VALUE)
        );
        panelInmueblesLayout.setVerticalGroup(
            panelInmueblesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 299, Short.MAX_VALUE)
        );

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addGap(363, 363, 363)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(343, 343, 343)
                        .addComponent(Historial, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(148, 148, 148)
                        .addComponent(panelInmuebles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(150, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(Historial)
                .addGap(58, 58, 58)
                .addComponent(panelInmuebles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 105, Short.MAX_VALUE)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Historial;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel panelInmuebles;
    // End of variables declaration//GEN-END:variables
}

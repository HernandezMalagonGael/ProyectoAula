package vistaGUI.inmueble;
 
import controlador.InmuebleControlador;
import utilidades.Sesion;
import javax.swing.JOptionPane;
 
public class InmuebleRegistroGUI extends javax.swing.JPanel {
 
    private boolean inicializado = true;
    private final InmuebleControlador inmuebleControlador;
    private final Runnable onExito;
    private final Runnable onCancelar;
    private String rutaImagenSeleccionada = null;
    
    public InmuebleRegistroGUI(InmuebleControlador inmuebleControlador, Runnable onExito, Runnable onCancelar) {
        this.inmuebleControlador = inmuebleControlador;
        this.onExito = onExito;
        this.onCancelar = onCancelar;
        
        initComponents();
        inicializado = true; 
        
        limpiarPlaceholders();
        activarSelectorImagen();
    }
    
    private void limpiarPlaceholders() {
        agregarFocus(costo_renta, "Costo de renta");
        agregarFocus(calle, "Calle");
        agregarFocus(numero, "Número");
        agregarFocus(colonia, "Colonia");
        agregarFocus(codigo_postal, "Codigo postal");
        agregarFocus(ciudad, "Ciudad");
        agregarFocus(estado, "Estado");
    }
    
    
    
    private void agregarFocus(javax.swing.JTextField tf, String placeholder) {
        tf.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusGained(java.awt.event.FocusEvent e) {
                if (tf.getText().equals(placeholder)) tf.setText("");
            }
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                if (tf.getText().isBlank()) tf.setText(placeholder);
            }
        });
    }
    
    
    
    private boolean campoVacio(javax.swing.JTextField tf, String placeholder) {
        return tf.getText().isBlank() || tf.getText().equals(placeholder);
    }
    
    private void limpiarFormulario() {
        costo_renta.setText("Costo de renta");
        calle.setText("Calle");
        numero.setText("Número");
        colonia.setText("Colonia");
        codigo_postal.setText("Codigo postal");
        ciudad.setText("Ciudad");
        estado.setText("Estado");
        jLabel1.setIcon(null);
        jLabel1.setText("INGRESAR IMAGEN");
        rutaImagenSeleccionada = null;
    }

    private void activarSelectorImagen() {
    jLabel1.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
    jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent e) {
            javax.swing.JFileChooser chooser = new javax.swing.JFileChooser();
            chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Imágenes (PNG, JPG)", "png", "jpg", "jpeg"));
            
            if (chooser.showOpenDialog(null) == javax.swing.JFileChooser.APPROVE_OPTION) {
                rutaImagenSeleccionada = chooser.getSelectedFile().getAbsolutePath();

                javax.swing.ImageIcon icono = new javax.swing.ImageIcon(rutaImagenSeleccionada);

                int ancho = jLabel1.getWidth() > 0 ? jLabel1.getWidth() : 160;
                int alto = jLabel1.getHeight() > 0 ? jLabel1.getHeight() : 120;

                java.awt.Image escalada = icono.getImage().getScaledInstance(ancho, alto, java.awt.Image.SCALE_SMOOTH);
                
                jLabel1.setIcon(new javax.swing.ImageIcon(escalada));
                jLabel1.setText("");
            }
        }
    });
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Pagos = new javax.swing.JLabel();
        costo_renta = new javax.swing.JTextField();
        calle = new javax.swing.JTextField();
        numero = new javax.swing.JTextField();
        colonia = new javax.swing.JTextField();
        codigo_postal = new javax.swing.JTextField();
        ciudad = new javax.swing.JTextField();
        estado = new javax.swing.JTextField();
        BtnAceptar = new javax.swing.JButton();
        footer1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        Pagos.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        Pagos.setForeground(new java.awt.Color(255, 255, 255));
        Pagos.setText("Registro Inmueble");

        costo_renta.setBackground(new java.awt.Color(253, 232, 201));
        costo_renta.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        costo_renta.setForeground(new java.awt.Color(30, 34, 45));
        costo_renta.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        costo_renta.setText("Costo de renta");
        costo_renta.setPreferredSize(new java.awt.Dimension(97, 28));
        costo_renta.addActionListener(this::costo_rentaActionPerformed);
        costo_renta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                costo_rentaKeyTyped(evt);
            }
        });

        calle.setBackground(new java.awt.Color(253, 232, 201));
        calle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        calle.setForeground(new java.awt.Color(30, 34, 45));
        calle.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        calle.setText("Calle");
        calle.setPreferredSize(new java.awt.Dimension(38, 30));
        calle.addActionListener(this::calleActionPerformed);
        calle.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                calleKeyTyped(evt);
            }
        });

        numero.setBackground(new java.awt.Color(253, 232, 201));
        numero.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        numero.setForeground(new java.awt.Color(30, 34, 45));
        numero.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        numero.setText("Número");
        numero.setPreferredSize(new java.awt.Dimension(38, 30));
        numero.addActionListener(this::numeroActionPerformed);
        numero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                numeroKeyTyped(evt);
            }
        });

        colonia.setBackground(new java.awt.Color(253, 232, 201));
        colonia.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        colonia.setForeground(new java.awt.Color(30, 34, 45));
        colonia.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        colonia.setText("Colonia");
        colonia.setPreferredSize(new java.awt.Dimension(38, 30));
        colonia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                coloniaKeyTyped(evt);
            }
        });

        codigo_postal.setBackground(new java.awt.Color(253, 232, 201));
        codigo_postal.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        codigo_postal.setForeground(new java.awt.Color(30, 34, 45));
        codigo_postal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        codigo_postal.setText("Codigo postal");
        codigo_postal.setPreferredSize(new java.awt.Dimension(38, 30));
        codigo_postal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                codigo_postalKeyTyped(evt);
            }
        });

        ciudad.setBackground(new java.awt.Color(253, 232, 201));
        ciudad.setForeground(new java.awt.Color(30, 34, 45));
        ciudad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ciudad.setText("Ciudad");
        ciudad.setPreferredSize(new java.awt.Dimension(38, 30));
        ciudad.addActionListener(this::ciudadActionPerformed);
        ciudad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ciudadKeyTyped(evt);
            }
        });

        estado.setBackground(new java.awt.Color(253, 232, 201));
        estado.setForeground(new java.awt.Color(30, 34, 45));
        estado.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        estado.setText("Estado");
        estado.setPreferredSize(new java.awt.Dimension(38, 30));
        estado.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                estadoKeyTyped(evt);
            }
        });

        BtnAceptar.setBackground(new java.awt.Color(253, 232, 201));
        BtnAceptar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BtnAceptar.setForeground(new java.awt.Color(30, 34, 45));
        BtnAceptar.setText("Aceptar");
        BtnAceptar.setBorder(null);
        BtnAceptar.addActionListener(this::BtnAceptarActionPerformed);

        footer1.setBackground(new java.awt.Color(253, 232, 201));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(30, 34, 45));
        jLabel2.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footer1Layout = new javax.swing.GroupLayout(footer1);
        footer1.setLayout(footer1Layout);
        footer1Layout.setHorizontalGroup(
            footer1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footer1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(301, 301, 301))
        );
        footer1Layout.setVerticalGroup(
            footer1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footer1Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_img.png"))); // NOI18N

        jButton1.setBackground(new java.awt.Color(30, 34, 45));
        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(253, 232, 201));
        jButton1.setText("<- REGRESAR ");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(115, 115, 115)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(calle, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(numero, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(costo_renta, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(estado, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(colonia, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(codigo_postal, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(133, 133, 133))
            .addComponent(footer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(297, 297, 297)
                        .addComponent(Pagos))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addGap(10, 10, 10)
                .addComponent(Pagos)
                .addGap(81, 81, 81)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(costo_renta, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(calle, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(numero, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(colonia, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(codigo_postal, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(estado, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addComponent(footer1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents
    
    private void BtnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAceptarActionPerformed
        String textoCalle = calle.getText().trim();
        String textoNumero = numero.getText().trim();
        String textoColonia = colonia.getText().trim();
        String textoCodigoPostal = codigo_postal.getText().trim();
        String textoCiudad = ciudad.getText().trim();
        String textoEstado = estado.getText().trim();
        String textoCosto = costo_renta.getText().trim();

        if (campoVacio(calle, "Calle") || campoVacio(numero, "Número") ||
            campoVacio(colonia, "Colonia") || campoVacio(codigo_postal, "Codigo postal") ||
            campoVacio(ciudad, "Ciudad") || campoVacio(estado, "Estado") ||
            campoVacio(costo_renta, "Costo de renta")) {
 
            JOptionPane.showMessageDialog(this,
                "Por favor completa todos los campos.",
                "Campos incompletos",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!textoCodigoPostal.matches("^[0-9]{5}$")) {
            JOptionPane.showMessageDialog(this,
                "El código postal debe tener exactamente 5 dígitos numéricos.",
                "Código postal inválido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        double costoRenta;
        try {
            costoRenta = Double.parseDouble(textoCosto);
            if (costoRenta <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                "El costo de renta debe ser un número mayor a 0.",
                "Costo inválido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (rutaImagenSeleccionada == null) {
            JOptionPane.showMessageDialog(this,
                "Por favor selecciona una imagen del inmueble.",
                "Imagen requerida",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        int idArrendador = Sesion.getIdUsuarioActivo();

        boolean exito = inmuebleControlador.registrarInmueble(
            idArrendador,
            textoCalle,
            textoNumero,
            textoColonia,
            textoCodigoPostal,
            textoCiudad,
            textoEstado,
            costoRenta,
            rutaImagenSeleccionada
        );
        
        
        if (exito) {
            JOptionPane.showMessageDialog(this,
                "Inmueble registrado exitosamente.",
                "Éxito",
                JOptionPane.INFORMATION_MESSAGE);
            limpiarFormulario();
            onExito.run(); // vuelve a la lista y recarga
        } else {
            JOptionPane.showMessageDialog(this,
                "Error al registrar el inmueble. Verifica que tu usuario esté activo.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        
        
    }//GEN-LAST:event_BtnAceptarActionPerformed

    private void costo_rentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_costo_rentaActionPerformed
        
    }//GEN-LAST:event_costo_rentaActionPerformed

    private void numeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numeroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numeroActionPerformed

    private void ciudadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ciudadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ciudadActionPerformed

    private void calleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_calleActionPerformed

    private void costo_rentaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_costo_rentaKeyTyped
        char c = evt.getKeyChar();

        if (!Character.isDigit(c) || costo_renta.getText().length() >= 6) {
            evt.consume();
        }
    }//GEN-LAST:event_costo_rentaKeyTyped

    private void numeroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numeroKeyTyped
        char c = evt.getKeyChar();

        if (!Character.isDigit(c) || numero.getText().length() >= 5) {
            evt.consume();
        }
    }//GEN-LAST:event_numeroKeyTyped

    private void codigo_postalKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigo_postalKeyTyped
        char c = evt.getKeyChar();

        if (!Character.isDigit(c) || codigo_postal.getText().length() >= 5) {
            evt.consume();
        }
    }//GEN-LAST:event_codigo_postalKeyTyped

    private void coloniaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_coloniaKeyTyped
         if (colonia.getText().length() >= 20) {
        evt.consume();
        }
    }//GEN-LAST:event_coloniaKeyTyped

    private void calleKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_calleKeyTyped
         if (calle.getText().length() >= 30) {
        evt.consume();
        }
    }//GEN-LAST:event_calleKeyTyped

    private void ciudadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ciudadKeyTyped
        if (ciudad.getText().length() >= 20) {
        evt.consume();
        }
    }//GEN-LAST:event_ciudadKeyTyped

    private void estadoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_estadoKeyTyped
        if (estado.getText().length() >= 20) {
        evt.consume();
        }
    }//GEN-LAST:event_estadoKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (onCancelar != null) onCancelar.run();
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAceptar;
    private javax.swing.JLabel Pagos;
    private javax.swing.JTextField calle;
    private javax.swing.JTextField ciudad;
    private javax.swing.JTextField codigo_postal;
    private javax.swing.JTextField colonia;
    private javax.swing.JTextField costo_renta;
    private javax.swing.JTextField estado;
    private javax.swing.JPanel footer1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField numero;
    // End of variables declaration//GEN-END:variables
}

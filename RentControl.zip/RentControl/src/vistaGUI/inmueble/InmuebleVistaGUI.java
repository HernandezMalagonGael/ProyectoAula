package vistaGUI.inmueble;
 
import controlador.InmuebleControlador;
import modelo.Inmueble;
 
public class InmuebleVistaGUI extends javax.swing.JPanel {
 
    
    private boolean inicializado = true;
    private final InmuebleControlador inmuebleControlador;
    private final Inmueble inmueble;
    private final Runnable onVolver;

    public InmuebleVistaGUI(InmuebleControlador inmuebleControlador, Inmueble inmueble, Runnable onVolver) {
        this.inmuebleControlador = inmuebleControlador;
        this.inmueble = inmueble;
        this.onVolver = onVolver;
 
        initComponents();
        inicializado = true;
        cargarDatos();
 
        if (utilidades.Sesion.getTipoUsuarioActivo() == 2) {
            activarEdicionDobleClick();
            activarSelectorImagenDobleClick();
            System.out.println("Modo edición activado para el Arrendador.");
        } else {
            System.out.println("Modo lectura estricto activado para el Arrendatario.");
        }
    }
    
    private void cargarDatos() {
        int tipoUsuario = utilidades.Sesion.getTipoUsuarioActivo();
 
        costo_renta.setText("Costo de renta: $" + inmueble.getCosto_renta());
        calle.setText("Calle: " + inmueble.getCalle());
        numero.setText("Número: " + inmueble.getNumero());
        colonia.setText("Colonia: " + inmueble.getColonia());
        codigo_postal.setText("CP: " + inmueble.getCodigo_postal());
        ciudad.setText("Ciudad: " + inmueble.getCiudad());
        estado.setText("Estado: " + inmueble.getEstado()); 
        codigo_vinculacion.setText("Código vinculación: " + inmueble.getCodigo_vinculacion());
 
        if (tipoUsuario == 2) { 
            if ("ocupado".equalsIgnoreCase(inmueble.getEstado_inmueble())) {
                String inquilinoVinculado = inmuebleControlador.obtenerNombreInquilino(inmueble.getId_inmueble());
                nombre.setText("Inquilino: " + inquilinoVinculado);
            } else {
                nombre.setText("Inquilino: No enlazado");
            }
 
        }
 
        actualizarContenedorImagen();
    }
 
    private void actualizarContenedorImagen() {
        java.awt.Dimension tamanoFijo = new java.awt.Dimension(154, 185);
        imagen.setPreferredSize(tamanoFijo);
        imagen.setMinimumSize(tamanoFijo);
        imagen.setMaximumSize(tamanoFijo);
        
        imagen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imagen.setVerticalAlignment(javax.swing.SwingConstants.CENTER);
 
        if (inmueble.getImagen_inmueble() != null && !inmueble.getImagen_inmueble().isBlank()) {
            try {
                javax.swing.ImageIcon iconOriginal = new javax.swing.ImageIcon(inmueble.getImagen_inmueble());
                
                int ancho = 154;
                int alto = 185;
                
                java.awt.Image imgEscalada = iconOriginal.getImage().getScaledInstance(ancho, alto, java.awt.Image.SCALE_SMOOTH);
                imagen.setIcon(new javax.swing.ImageIcon(imgEscalada));
                imagen.setText("");
            } catch (Exception e) {
                imagen.setIcon(null);
                imagen.setText("Error al cargar");
            }
        } else {
            imagen.setIcon(null);
            imagen.setText("SIN IMAGEN");
        }
        
        imagen.revalidate();
        imagen.repaint();
    }

    private void activarEdicionDobleClick() {
        java.awt.event.MouseAdapter mouseAdapter = new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    javax.swing.JLabel labelActual = (javax.swing.JLabel) e.getSource();
                    javax.swing.JPanel panelPadre = (javax.swing.JPanel) labelActual.getParent();
                    
                    String textoOriginal = labelActual.getText();
                    String valorLimpio = textoOriginal;
                    
                    
                    if (textoOriginal.contains(": $")) {
                        valorLimpio = textoOriginal.substring(textoOriginal.indexOf("$") + 1).trim();
                    } else if (textoOriginal.contains(": ")) {
                        valorLimpio = textoOriginal.substring(textoOriginal.indexOf(":") + 1).trim();
                    }
                    
                    
                    panelPadre.setLayout(new java.awt.BorderLayout());
                    
                    javax.swing.JTextField textField = new javax.swing.JTextField(valorLimpio);
                    textField.setFont(labelActual.getFont());
                    textField.setBackground(new java.awt.Color(35, 40, 50)); 
                    textField.setForeground(new java.awt.Color(253, 230, 201)); 
                    textField.setCaretColor(new java.awt.Color(253, 230, 201));
                    textField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(253, 230, 201), 1));
                    
                    
                    textField.addActionListener(evt -> finalizarEdicion(panelPadre, textField, labelActual, true));
                    
                    
                    textField.addFocusListener(new java.awt.event.FocusAdapter() {
                        @Override
                        public void focusLost(java.awt.event.FocusEvent evt) {
                            finalizarEdicion(panelPadre, textField, labelActual, true);
                        }
                    });
                    
                    panelPadre.remove(labelActual);
                    panelPadre.add(textField, java.awt.BorderLayout.CENTER);
                    
                    textField.requestFocus();
                    panelPadre.revalidate();
                    panelPadre.repaint();
                    
                }
            }
        };
        
        
        
        nombre.addMouseListener(mouseAdapter);
        codigo_vinculacion.addMouseListener(mouseAdapter);
        
        costo_renta.addMouseListener(mouseAdapter);
        calle.addMouseListener(mouseAdapter);
        numero.addMouseListener(mouseAdapter);
        colonia.addMouseListener(mouseAdapter);
        codigo_postal.addMouseListener(mouseAdapter);
        ciudad.addMouseListener(mouseAdapter);
        estado.addMouseListener(mouseAdapter);
        
        costo_renta.setToolTipText("Doble clic para editar");
        calle.setToolTipText("Doble clic para editar");
        numero.setToolTipText("Doble clic para editar");
        colonia.setToolTipText("Doble clic para editar");
        codigo_postal.setToolTipText("Doble clic para editar");
        ciudad.setToolTipText("Doble clic para editar");
        estado.setToolTipText("Doble clic para editar");
 
        nombre.setToolTipText("No se puede modificar");
        codigo_vinculacion.setToolTipText("El codigo no se puede modificar");
    }
 
    private void finalizarEdicion(javax.swing.JPanel panelPadre, javax.swing.JTextField textField, javax.swing.JLabel labelActual, boolean guardar) {
        if (textField.getParent() == null) return; 
        
        String nuevoValor = textField.getText().trim();
        
        if (guardar && !nuevoValor.isBlank()) {
            try {
                if (labelActual == costo_renta) {
                    inmueble.setCosto_renta(Double.parseDouble(nuevoValor));
                    labelActual.setText("Costo de renta: $" + nuevoValor);
                } else if (labelActual == calle) {
                    inmueble.setCalle(nuevoValor);
                    labelActual.setText("Calle: " + nuevoValor);
                } else if (labelActual == numero) {
                    inmueble.setNumero(nuevoValor);
                    labelActual.setText("Número: " + nuevoValor);
                } else if (labelActual == colonia) {
                    inmueble.setColonia(nuevoValor);
                    labelActual.setText("Colonia: " + nuevoValor);
                } else if (labelActual == codigo_postal) {
                    inmueble.setCodigo_postal(nuevoValor);
                    labelActual.setText("CP: " + nuevoValor);
                } else if (labelActual == ciudad) {
                    inmueble.setCiudad(nuevoValor);
                    labelActual.setText("Ciudad: " + nuevoValor);
                } else if (labelActual == estado) {
                    inmueble.setEstado(nuevoValor);
                    labelActual.setText("Estado: " + nuevoValor);
                }
                
                
                inmuebleControlador.actualizarInmueble(inmueble);
                
            } catch (NumberFormatException ex) {
                javax.swing.JOptionPane.showMessageDialog(this, "Formato numérico incorrecto.", "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
            }
        }
        
        panelPadre.remove(textField);
        panelPadre.add(labelActual, java.awt.BorderLayout.CENTER);
        panelPadre.revalidate();
        panelPadre.repaint();
    }

    private void activarSelectorImagenDobleClick() {
        imagen.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        imagen.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    javax.swing.JFileChooser fileChooser = new javax.swing.JFileChooser();
                    fileChooser.setDialogTitle("Cambiar imagen del inmueble");
                    fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Imágenes (JPG, PNG)", "jpg", "jpeg", "png"));
                    
                    if (fileChooser.showOpenDialog(InmuebleVistaGUI.this) == javax.swing.JFileChooser.APPROVE_OPTION) {
                        String ruta = fileChooser.getSelectedFile().getAbsolutePath();
                        inmueble.setImagen_inmueble(ruta);
                        
                        if (inmuebleControlador.actualizarInmueble(inmueble)) {
                            actualizarContenedorImagen();
                            javax.swing.JOptionPane.showMessageDialog(InmuebleVistaGUI.this, "Imagen guardada y actualizada con éxito.", "Sincronizado", javax.swing.JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            }
        });
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        codigo_vinculacion = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        codigo_postal = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        ciudad = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        estado = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        colonia = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        numero = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        calle = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        costo_renta = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        nombre = new javax.swing.JLabel();
        BtnAceptar = new javax.swing.JButton();
        imagen = new javax.swing.JLabel();
        Pagos = new javax.swing.JLabel();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setMinimumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addGap(363, 363, 363)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel11.setBackground(new java.awt.Color(253, 232, 201));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        codigo_vinculacion.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        codigo_vinculacion.setForeground(new java.awt.Color(30, 34, 45));
        codigo_vinculacion.setText("Código de Vinculación");
        jPanel11.add(codigo_vinculacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, 250, -1));

        jPanel10.setBackground(new java.awt.Color(253, 232, 201));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        codigo_postal.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        codigo_postal.setForeground(new java.awt.Color(30, 34, 45));
        codigo_postal.setText("Codigo postal");
        jPanel10.add(codigo_postal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, -1));

        jPanel9.setBackground(new java.awt.Color(253, 232, 201));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ciudad.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        ciudad.setForeground(new java.awt.Color(30, 34, 45));
        ciudad.setText("Ciudad");
        jPanel9.add(ciudad, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 100, -1));

        jPanel8.setBackground(new java.awt.Color(253, 232, 201));
        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        estado.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        estado.setForeground(new java.awt.Color(30, 34, 45));
        estado.setText("Estado");
        jPanel8.add(estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, -1));

        jPanel7.setBackground(new java.awt.Color(253, 232, 201));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        colonia.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        colonia.setForeground(new java.awt.Color(30, 34, 45));
        colonia.setText("Colonia");
        jPanel7.add(colonia, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, -1));

        jPanel6.setBackground(new java.awt.Color(253, 232, 201));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        numero.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        numero.setForeground(new java.awt.Color(30, 34, 45));
        numero.setText("Número");
        jPanel6.add(numero, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, -1));

        jPanel5.setBackground(new java.awt.Color(253, 232, 201));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        calle.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        calle.setForeground(new java.awt.Color(30, 34, 45));
        calle.setText("Calle");
        jPanel5.add(calle, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 110, -1));

        jPanel4.setBackground(new java.awt.Color(253, 232, 201));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        costo_renta.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        costo_renta.setForeground(new java.awt.Color(30, 34, 45));
        costo_renta.setText("Costo de renta");
        jPanel4.add(costo_renta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 260, -1));

        jPanel3.setBackground(new java.awt.Color(253, 232, 201));
        jPanel3.setPreferredSize(new java.awt.Dimension(280, 45));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nombre.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        nombre.setForeground(new java.awt.Color(30, 34, 45));
        nombre.setText("Nombre del Arrendatario");
        jPanel3.add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 260, -1));

        BtnAceptar.setBackground(new java.awt.Color(253, 232, 201));
        BtnAceptar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BtnAceptar.setForeground(new java.awt.Color(30, 34, 45));
        BtnAceptar.setText("Aceptar");
        BtnAceptar.setBorder(null);
        BtnAceptar.addActionListener(this::BtnAceptarActionPerformed);

        imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/icon_img.png"))); // NOI18N

        Pagos.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        Pagos.setForeground(new java.awt.Color(255, 255, 255));
        Pagos.setText("Vista Inmueble");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 153, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(imagen)
                        .addGap(110, 110, 110))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(196, 196, 196))))
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Pagos)
                .addGap(322, 322, 322))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(Pagos)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(imagen)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(BtnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void BtnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAceptarActionPerformed
        if (onVolver != null) {
            onVolver.run();
        }
    }//GEN-LAST:event_BtnAceptarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAceptar;
    private javax.swing.JLabel Pagos;
    private javax.swing.JLabel calle;
    private javax.swing.JLabel ciudad;
    private javax.swing.JLabel codigo_postal;
    private javax.swing.JLabel codigo_vinculacion;
    private javax.swing.JLabel colonia;
    private javax.swing.JLabel costo_renta;
    private javax.swing.JLabel estado;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel imagen;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JLabel nombre;
    private javax.swing.JLabel numero;
    // End of variables declaration//GEN-END:variables
}

package vistaGUI.inmueble;

import controlador.InmuebleControlador;
import utilidades.Sesion;

public class InmuebleEnlaceGUI extends javax.swing.JPanel {
    
    private InmuebleControlador inmuebleControlador;
    private java.util.function.Consumer<modelo.Inmueble> onExito;
    private Runnable onCancelar;
    private boolean inicializado = true;

    
    public InmuebleEnlaceGUI(InmuebleControlador controlador,
                              java.util.function.Consumer<modelo.Inmueble> onExito,
                              Runnable onCancelar) {
        this.inmuebleControlador = controlador;
        this.onExito   = onExito;
        this.onCancelar = onCancelar;
        initComponents();          
        inicializado = true;
        codigo_acceso.setText("");
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Historial = new javax.swing.JLabel();
        BtnAgregarInmueble = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        codigo_acceso = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addGap(367, 367, 367)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(footerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Historial.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        Historial.setForeground(new java.awt.Color(255, 255, 255));
        Historial.setText("Inmuebles");

        BtnAgregarInmueble.setBackground(new java.awt.Color(253, 232, 201));
        BtnAgregarInmueble.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BtnAgregarInmueble.setForeground(new java.awt.Color(30, 34, 45));
        BtnAgregarInmueble.setText("Enlazar inmueble");
        BtnAgregarInmueble.setBorder(null);
        BtnAgregarInmueble.addActionListener(this::BtnAgregarInmuebleActionPerformed);

        jPanel2.setBackground(new java.awt.Color(253, 232, 201));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Código de enlace:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(253, 232, 201));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("  ______________________________");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 170, 30));

        codigo_acceso.setBackground(new java.awt.Color(253, 232, 201));
        codigo_acceso.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        codigo_acceso.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        codigo_acceso.setText(" ");
        codigo_acceso.setBorder(null);
        codigo_acceso.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        codigo_acceso.setDragEnabled(true);
        codigo_acceso.setOpaque(true);
        codigo_acceso.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                codigo_accesoKeyTyped(evt);
            }
        });
        jPanel3.add(codigo_acceso, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 12, 170, 20));

        jButton3.setBackground(new java.awt.Color(30, 34, 45));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(253, 232, 201));
        jButton3.setText("<- REGRESAR ");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(123, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(86, 86, 86)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(229, 229, 229))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)
                        .addGap(219, 219, 219)
                        .addComponent(Historial, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(363, 363, 363)
                        .addComponent(BtnAgregarInmueble, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(footer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(Historial))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)))
                .addGap(168, 168, 168)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                .addComponent(BtnAgregarInmueble, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(120, 120, 120)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void BtnAgregarInmuebleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAgregarInmuebleActionPerformed
        String codigo = codigo_acceso.getText().trim();
 
        if (codigo.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this,
                "Por favor, ingresa el código de vinculación.",
                "Campo vacío", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
 
        int idUsuario = Sesion.getIdUsuarioActivo();
        boolean exito = inmuebleControlador.enlazarInmueble(idUsuario, codigo);
 
        if (exito) {
            
            modelo.Inmueble inmuebleEnlazado = inmuebleControlador.buscarPorCodigoVinculacion(codigo);
            javax.swing.JOptionPane.showMessageDialog(this,
                "¡Inmueble enlazado correctamente!",
                "Éxito", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            if (onExito != null && inmuebleEnlazado != null) {
                inmuebleEnlazado.setEstado_inmueble("rentado");
                onExito.accept(inmuebleEnlazado);
            } else if (onCancelar != null) {
                onCancelar.run(); // fallback: vuelve a la lista
            }
        } else {
            javax.swing.JOptionPane.showMessageDialog(this,
                "No se pudo realizar el enlace. Verifica que el código de 6 dígitos sea correcto\ny que el inmueble se encuentre en estado 'disponible'.",
                "Error de Vinculación", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BtnAgregarInmuebleActionPerformed

    private void codigo_accesoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codigo_accesoKeyTyped
        char c = evt.getKeyChar();

        if (!Character.isDigit(c) || codigo_acceso.getText().length() >= 6) {
            evt.consume();
        }
    }//GEN-LAST:event_codigo_accesoKeyTyped

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        if (onCancelar != null) onCancelar.run();
    }//GEN-LAST:event_jButton3ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAgregarInmueble;
    private javax.swing.JLabel Historial;
    private javax.swing.JTextField codigo_acceso;
    private javax.swing.JPanel footer;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}

package vistaGUI.inmueble;
 
 
import controlador.InmuebleControlador;
import modelo.Inmueble;
import utilidades.Sesion;
import java.util.List;
 
public class InmuebleListaGUI extends javax.swing.JPanel {
 
    private boolean inicializado = true;
    private InmuebleControlador inmuebleControlador;
    private javax.swing.JPanel panelVistaActual;
    private static final int LIMITE_INMUEBLES = 10;
    
    
    
    public InmuebleListaGUI(InmuebleControlador inmuebleControlador) {
        this.inmuebleControlador = inmuebleControlador;
        initComponents();
        inicializado = true;
 
        if (Sesion.getTipoUsuarioActivo() == 3) {
            BtnAgregarInmueble.setText("Enlazar inmueble");
        }
 
        cargarInmuebles();
        revalidate();
    }

    private void cargarInmuebles() {
        panelInmuebles.removeAll();
        panelInmuebles.setLayout(new java.awt.BorderLayout());
        panelInmuebles.setPreferredSize(null);
 
        int idUsuario   = Sesion.getIdUsuarioActivo();
        int tipoUsuario = Sesion.getTipoUsuarioActivo();
 
        List<Inmueble> lista = tipoUsuario == 2
            ? inmuebleControlador.consultarInmueblesPorUsuario(idUsuario)
            : inmuebleControlador.consultarInmueblesEnlazados(idUsuario);
 
        if (lista.isEmpty()) {
            javax.swing.JLabel txt = new javax.swing.JLabel(
                "<html><center>No tienes inmuebles registrados o enlazados.<br>" +
                "Usa el botón inferior para agregar uno.</center></html>",
                javax.swing.SwingConstants.CENTER);
            txt.setForeground(java.awt.Color.WHITE);
            txt.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 14));
            panelInmuebles.add(txt, java.awt.BorderLayout.CENTER);
        } else {
            javax.swing.JPanel grid = new javax.swing.JPanel(
                new java.awt.GridLayout(0, 3, 6, 6));
            grid.setBackground(new java.awt.Color(30, 34, 45));
 
            int total = lista.size();
            int sobra = total % 3;
 
            if (sobra == 1 && total > 1) {
                for (int i = 0; i < total - 1; i++) grid.add(crearTarjeta(lista.get(i)));
                grid.add(crearRelleno());
                grid.add(crearTarjeta(lista.get(total - 1)));
                grid.add(crearRelleno());
            } else if (sobra == 2) {
                for (Inmueble inm : lista) grid.add(crearTarjeta(inm));
                grid.add(crearRelleno());
            } else {
                for (Inmueble inm : lista) grid.add(crearTarjeta(inm));
            }
 
            javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(grid);
            scroll.setBorder(null);
            scroll.setHorizontalScrollBarPolicy(
                javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            scroll.getViewport().setBackground(new java.awt.Color(30, 34, 45));
            panelInmuebles.add(scroll, java.awt.BorderLayout.CENTER);
        }
 
        panelInmuebles.revalidate();
        panelInmuebles.repaint();
    }
    
    private javax.swing.JButton crearTarjeta(Inmueble inmueble) {
        String texto = "<html><center>"
            + inmueble.getCalle() + " #" + inmueble.getNumero() + "<br>"
            + "<small>" + inmueble.getColonia() + "</small>"
            + "</center></html>";
 
        javax.swing.JButton btn = new javax.swing.JButton(texto);
        btn.setBackground(new java.awt.Color(253, 232, 201));
        btn.setForeground(new java.awt.Color(30, 34, 45));
        btn.setPreferredSize(new java.awt.Dimension(155, 55));
        btn.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 11));
        btn.setFocusPainted(false);
        btn.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        btn.addActionListener(e -> navegarAVista(inmueble));
        return btn;
    }
    
    private javax.swing.JPanel crearRelleno() {
        javax.swing.JPanel relleno = new javax.swing.JPanel();
        relleno.setBackground(new java.awt.Color(30, 34, 45));
        relleno.setOpaque(true);
        return relleno;
    }

    private void mostrarVistaSecundaria(javax.swing.JComponent vista) {
        Historial.setVisible(false);
        BtnAgregarInmueble.setVisible(false);
 
        panelVistaActual = new javax.swing.JPanel(new java.awt.BorderLayout());
        panelVistaActual.add(vista, java.awt.BorderLayout.CENTER);
 
        panelInmuebles.removeAll();
        panelInmuebles.setLayout(new java.awt.BorderLayout());
        panelInmuebles.setPreferredSize(new java.awt.Dimension(818, 588));
        panelInmuebles.add(panelVistaActual, java.awt.BorderLayout.CENTER);
        panelInmuebles.revalidate();
        panelInmuebles.repaint();
    }
 
    private void navegarAVista(Inmueble inmueble) {
        InmuebleVistaGUI vista = new InmuebleVistaGUI(
            inmuebleControlador, inmueble, this::volverALista);
        mostrarVistaSecundaria(vista);
    }

    private void navegarARegistro() {
        InmuebleRegistroGUI registro = new InmuebleRegistroGUI(
            inmuebleControlador, this::volverALista, this::volverALista);
        mostrarVistaSecundaria(registro);
    }
    
    private void volverALista() {
        panelVistaActual = null;
        Historial.setVisible(true);
        BtnAgregarInmueble.setVisible(true);
        cargarInmuebles();
        revalidate(); repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        footer = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Historial = new javax.swing.JLabel();
        panelInmuebles = new javax.swing.JPanel();
        BtnAgregarInmueble = new javax.swing.JButton();

        setBackground(new java.awt.Color(30, 34, 45));
        setMaximumSize(null);
        setMinimumSize(null);
        setPreferredSize(new java.awt.Dimension(818, 588));

        footer.setBackground(new java.awt.Color(253, 232, 201));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(30, 34, 45));
        jLabel1.setText("RentControl. CDMX, México. 2026");

        javax.swing.GroupLayout footerLayout = new javax.swing.GroupLayout(footer);
        footer.setLayout(footerLayout);
        footerLayout.setHorizontalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(325, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(297, 297, 297))
        );
        footerLayout.setVerticalGroup(
            footerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, footerLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        Historial.setFont(new java.awt.Font("Segoe UI", 0, 40)); // NOI18N
        Historial.setForeground(new java.awt.Color(255, 255, 255));
        Historial.setText("Inmuebles");

        panelInmuebles.setBackground(new java.awt.Color(30, 34, 45));

        javax.swing.GroupLayout panelInmueblesLayout = new javax.swing.GroupLayout(panelInmuebles);
        panelInmuebles.setLayout(panelInmueblesLayout);
        panelInmueblesLayout.setHorizontalGroup(
            panelInmueblesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 665, Short.MAX_VALUE)
        );
        panelInmueblesLayout.setVerticalGroup(
            panelInmueblesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 316, Short.MAX_VALUE)
        );

        BtnAgregarInmueble.setBackground(new java.awt.Color(253, 232, 201));
        BtnAgregarInmueble.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BtnAgregarInmueble.setForeground(new java.awt.Color(30, 34, 45));
        BtnAgregarInmueble.setText("Agregar inmueble");
        BtnAgregarInmueble.setBorder(null);
        BtnAgregarInmueble.addActionListener(this::BtnAgregarInmuebleActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(footer, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(148, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(Historial, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(324, 324, 324))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(BtnAgregarInmueble, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(354, 354, 354))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(panelInmuebles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(105, 105, 105))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(Historial)
                .addGap(28, 28, 28)
                .addComponent(panelInmuebles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 49, Short.MAX_VALUE)
                .addComponent(BtnAgregarInmueble, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(footer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void BtnAgregarInmuebleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAgregarInmuebleActionPerformed
        int tipoUsuario = utilidades.Sesion.getTipoUsuarioActivo();
        int idUsuario   = utilidades.Sesion.getIdUsuarioActivo();
 
        if (tipoUsuario == 2) {
            
            int cantidad = inmuebleControlador.contarInmueblesPorUsuario(idUsuario);
            if (cantidad >= LIMITE_INMUEBLES) {
                javax.swing.JOptionPane.showMessageDialog(this,
                    "Has alcanzado el límite de " + LIMITE_INMUEBLES + " inmuebles.",
                    "Límite alcanzado", javax.swing.JOptionPane.WARNING_MESSAGE);
                return;
            }
            navegarARegistro();
        } else if (tipoUsuario == 3) {
            
            InmuebleEnlaceGUI enlace = new InmuebleEnlaceGUI(
                inmuebleControlador,
                inm -> navegarAVista(inm),
                this::volverALista);
            mostrarVistaSecundaria(enlace);
        }
    }//GEN-LAST:event_BtnAgregarInmuebleActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAgregarInmueble;
    private javax.swing.JLabel Historial;
    private javax.swing.JPanel footer;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel panelInmuebles;
    // End of variables declaration//GEN-END:variables
}

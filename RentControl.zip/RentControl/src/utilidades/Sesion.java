package utilidades;

public class Sesion {

    private static int idUsuarioActivo;
    private static int tipoUsuarioActivo;
    private static String nombreUsuarioActivo;

    public static int getIdUsuarioActivo() {
        return idUsuarioActivo;
    }

    public static void setIdUsuarioActivo(int id) {
        idUsuarioActivo = id;
    }

    public static int getTipoUsuarioActivo() {
        return tipoUsuarioActivo;
    }

    public static void setTipoUsuarioActivo(int tipo) {
        tipoUsuarioActivo = tipo;
    }

    public static String getNombreUsuarioActivo() {
        return nombreUsuarioActivo;
    }

    public static void setNombreUsuarioActivo(String nombre) {
        nombreUsuarioActivo = nombre;
    }

    // Limpia al cerrar sesión
    public static void cerrarSesion() {
        idUsuarioActivo = 0;
        tipoUsuarioActivo = 0;
        nombreUsuarioActivo = null;
    }
}

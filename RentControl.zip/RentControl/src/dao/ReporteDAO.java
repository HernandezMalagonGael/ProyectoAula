package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Reporte;
import utilidades.Conexion;

public class ReporteDAO {

    // Crete
    public boolean registrarReporte(Reporte reporte) {
        String sql = "INSERT INTO ereporte_mantenimiento (id_inmueble, id_usuario, id_lugar, id_categoria_problema, descripcion, estado_mantenimiento, imagen_mantenimiento) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, reporte.getId_inmueble());
            ps.setInt(2, reporte.getId_usuario());
            ps.setInt(3, reporte.getId_lugar());
            ps.setInt(4, reporte.getId_categoria_problema());
            ps.setString(5, reporte.getDescripcion());
            ps.setString(6, reporte.getEstado_mantenimiento());
            ps.setString(7, reporte.getImagen_mantenimiento());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar reporte: " + e.getMessage());
            return false;
        }
    }

    // Read
    public List<Reporte> consultarReportes() {
        List<Reporte> listaReportes = new ArrayList<>();
        String sql = "SELECT * FROM ereporte_mantenimiento";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Reporte reporte = mapearReporte(rs);
                listaReportes.add(reporte);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar reportes: " + e.getMessage());
        }
        return listaReportes;
    }
    
    public List<Reporte> consultarReportesPorUsuario(int idUsuario) {
    List<Reporte> lista = new ArrayList<>();

    String sql = "SELECT * FROM ereporte_mantenimiento WHERE id_usuario = ?";

    try (Connection con = Conexion.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setInt(1, idUsuario);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapearReporte(rs));
            }
        }

    } catch (SQLException e) {
        System.err.println("Error al consultar reportes por usuario: " + e.getMessage());
    }

    return lista;
}

    public List<Reporte> consultarReportesPorInmueble(int idInmueble) {
        List<Reporte> lista = new ArrayList<>();
        String sql = "SELECT * FROM ereporte_mantenimiento WHERE id_inmueble = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idInmueble);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearReporte(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar reportes por inmueble: " + e.getMessage());
        }
        return lista;
    }

    // Busqueda por id
    public Reporte buscarReportePorId(int idReporte) {
        String sql = "SELECT * FROM ereporte_mantenimiento WHERE id_reporte_mantenimiento = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idReporte);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearReporte(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar reporte por ID: " + e.getMessage());
        }
        return null;
    }

    // Update
    public boolean actualizarReporte(Reporte reporte) {
        String sql = "UPDATE ereporte_mantenimiento SET id_lugar = ?, id_categoria_problema = ?, descripcion = ?, estado_mantenimiento = ?, imagen_mantenimiento = ? WHERE id_reporte_mantenimiento = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, reporte.getId_lugar());
            ps.setInt(2, reporte.getId_categoria_problema());
            ps.setString(3, reporte.getDescripcion());
            ps.setString(4, reporte.getEstado_mantenimiento());
            ps.setString(5, reporte.getImagen_mantenimiento());
            ps.setInt(6, reporte.getId_reporte_mantenimiento());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar reporte: " + e.getMessage());
            return false;
        }
    }

    // Delete
    public boolean eliminarReporte(int idReporte) {
        String sql = "DELETE FROM ereporte_mantenimiento WHERE id_reporte_mantenimiento = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idReporte);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar reporte: " + e.getMessage());
            return false;
        }
    }

    // Método auxiliar para no repetir el mapeo en consultar y buscar
    private Reporte mapearReporte(ResultSet rs) throws SQLException {
        Reporte reporte = new Reporte();

        reporte.setId_reporte_mantenimiento(rs.getInt("id_reporte_mantenimiento"));
        reporte.setId_inmueble(rs.getInt("id_inmueble"));
        reporte.setId_usuario(rs.getInt("id_usuario"));
        reporte.setId_lugar(rs.getInt("id_lugar"));
        reporte.setId_categoria_problema(rs.getInt("id_categoria_problema"));
        reporte.setDescripcion(rs.getString("descripcion"));
        reporte.setEstado_mantenimiento(rs.getString("estado_mantenimiento"));
        reporte.setImagen_mantenimiento(rs.getString("imagen_mantenimiento"));

        if (rs.getTimestamp("fecha_reporte") != null) {
            reporte.setFecha_reporte(rs.getTimestamp("fecha_reporte").toLocalDateTime());
        }
        if (rs.getTimestamp("fecha_actualizacion") != null) {
            reporte.setFecha_actualizacion(rs.getTimestamp("fecha_actualizacion").toLocalDateTime());
        }

        return reporte;
    }
}
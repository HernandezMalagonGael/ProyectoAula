package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Inmueble;
import utilidades.Conexion;
import utilidades.Conexion;

public class InmuebleDAO {

    // Create
    public boolean registrarInmueble(Inmueble inmueble) {
        String sql = "INSERT INTO minmueble (id_usuario, costo_renta, codigo_vinculacion, numero, calle, colonia, ciudad, estado, codigo_postal, estado_inmueble, imagen_inmueble) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, inmueble.getId_usuario());
            ps.setDouble(2, inmueble.getCosto_renta());
            ps.setString(3, inmueble.getCodigo_vinculacion());
            ps.setString(4, inmueble.getNumero());
            ps.setString(5, inmueble.getCalle());
            ps.setString(6, inmueble.getColonia());
            ps.setString(7, inmueble.getCiudad());
            ps.setString(8, inmueble.getEstado());
            ps.setString(9, inmueble.getCodigo_postal());
            ps.setString(10, inmueble.getEstado_inmueble());
            ps.setString(11, inmueble.getImagen_inmueble());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar inmueble: " + e.getMessage());
            return false;
        }
    }

    // Read
    public List<Inmueble> consultarInmuebles() {
        List<Inmueble> listaInmuebles = new ArrayList<>();
        String sql = "SELECT * FROM minmueble";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                listaInmuebles.add(mapearInmueble(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar inmuebles: " + e.getMessage());
        }
        return listaInmuebles;
    }

    // Busqueda por id
    public Inmueble buscarInmueblePorId(int idInmueble) {
        String sql = "SELECT * FROM minmueble WHERE id_inmueble = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idInmueble);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearInmueble(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar inmueble por ID: " + e.getMessage());
        }
        return null;
    }

    // Update
    public boolean actualizarInmueble(Inmueble inmueble) {
        String sql = "UPDATE minmueble SET calle = ?, numero = ?, colonia = ?, codigo_postal = ?, ciudad = ?, estado = ?, costo_renta = ?, estado_inmueble = ?, imagen_inmueble = ? WHERE id_inmueble = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, inmueble.getCalle());
            ps.setString(2, inmueble.getNumero());
            ps.setString(3, inmueble.getColonia());
            ps.setString(4, inmueble.getCodigo_postal());
            ps.setString(5, inmueble.getCiudad());
            ps.setString(6, inmueble.getEstado());
            ps.setDouble(7, inmueble.getCosto_renta());
            ps.setString(8, inmueble.getEstado_inmueble());
            ps.setString(9, inmueble.getImagen_inmueble());
            ps.setInt(10, inmueble.getId_inmueble());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar inmueble: " + e.getMessage());
            return false;
        }
    }

    // Delete — baja lógica
    public boolean eliminarInmueble(int idInmueble) {
        String sql = "UPDATE minmueble SET estado_inmueble = 'inactivo' WHERE id_inmueble = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idInmueble);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar (baja lógica) inmueble: " + e.getMessage());
            return false;
        }
    }

    // Método auxiliar para no repetir el mapeo en consultar y buscar
    private Inmueble mapearInmueble(ResultSet rs) throws SQLException {
        Inmueble inmueble = new Inmueble();

        inmueble.setId_inmueble(rs.getInt("id_inmueble"));
        inmueble.setId_usuario(rs.getInt("id_usuario"));
        inmueble.setCosto_renta(rs.getDouble("costo_renta"));
        inmueble.setCodigo_vinculacion(rs.getString("codigo_vinculacion"));
        inmueble.setNumero(rs.getString("numero"));
        inmueble.setCalle(rs.getString("calle"));
        inmueble.setColonia(rs.getString("colonia"));
        inmueble.setCiudad(rs.getString("ciudad"));
        inmueble.setEstado(rs.getString("estado"));
        inmueble.setCodigo_postal(rs.getString("codigo_postal"));
        inmueble.setEstado_inmueble(rs.getString("estado_inmueble"));
        inmueble.setImagen_inmueble(rs.getString("imagen_inmueble"));

        if (rs.getTimestamp("fecha_registro") != null) {
            inmueble.setFecha_registro(rs.getTimestamp("fecha_registro").toLocalDateTime());
        }

        return inmueble;
    }
    
    // Consultar inmuebles de un arrendador específico
    public List<Inmueble> consultarInmueblesPorUsuario(int idUsuario) {
        List<Inmueble> lista = new ArrayList<>();
        String sql = "SELECT * FROM minmueble WHERE id_usuario = ?";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, idUsuario);
 
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearInmueble(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar inmuebles por usuario: " + e.getMessage());
        }
        return lista;
    }
 
    // Consultar inmuebles a los que está enlazado un arrendatario
    public List<Inmueble> consultarInmueblesEnlazados(int idUsuario) {
        List<Inmueble> lista = new ArrayList<>();
        String sql = "SELECT m.* FROM minmueble m "
                   + "INNER JOIN dacceso_inmueble d ON m.id_inmueble = d.id_inmueble "
                   + "WHERE d.id_usuario = ? AND d.vigente = 1";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, idUsuario);
 
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearInmueble(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar inmuebles enlazados: " + e.getMessage());
        }
        return lista;
    }
 
    // Contar cuántos inmuebles tiene un arrendador
    public int contarInmueblesPorUsuario(int idUsuario) {
        String sql = "SELECT COUNT(*) FROM minmueble WHERE id_usuario = ?";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, idUsuario);
 
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al contar inmuebles: " + e.getMessage());
        }
        return 0;
    }
    
    

    // Buscar inmueble por código de vinculación (usado tras el enlace para navegar a Vista)
    public Inmueble buscarPorCodigoVinculacion(String codigo) {
        String sql = "SELECT * FROM minmueble WHERE codigo_vinculacion = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapearInmueble(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar por código de vinculación: " + e.getMessage());
        }
        return null;
    }

    
    
        // --- METODO PARA ENLAZAR INMUEBLE (ARRENDATARIO) ---
    public boolean enlazarInmueblePorCodigo(int idUsuarioArrendatario, String codigoVinculacion) {
        
        String sqlBuscar = "SELECT id_inmueble, estado_inmueble FROM minmueble WHERE codigo_vinculacion = ?";
        
        String sqlInsertarEnlace = "INSERT INTO dacceso_inmueble (id_usuario, id_inmueble, codigo_acceso, vigente) VALUES (?, ?, ?, 1)";
        
        String sqlActualizarEstado = "UPDATE minmueble SET estado_inmueble = 'rentado' WHERE id_inmueble = ?";

        try (Connection con = utilidades.Conexion.getConexion()) {
            
            con.setAutoCommit(false);

            try (PreparedStatement psBuscar = con.prepareStatement(sqlBuscar)) {
                psBuscar.setString(1, codigoVinculacion);
                try (ResultSet rs = psBuscar.executeQuery()) {
                    if (rs.next()) {
                        int idInmueble = rs.getInt("id_inmueble");
                        String estado = rs.getString("estado_inmueble");

                        
                        if ("rentado".equalsIgnoreCase(estado)) {
                            System.err.println("El inmueble asociado al código ya se encuentra ocupado.");
                            return false;
                        }

                        
                        try (PreparedStatement psInsertar = con.prepareStatement(sqlInsertarEnlace)) {
                            psInsertar.setInt(1, idUsuarioArrendatario);
                            psInsertar.setInt(2, idInmueble);
                            psInsertar.setString(3, codigoVinculacion);
                            psInsertar.executeUpdate();
                        }

                        
                        try (PreparedStatement psActualizar = con.prepareStatement(sqlActualizarEstado)) {
                            psActualizar.setInt(1, idInmueble);
                            psActualizar.executeUpdate();
                        }

                        
                        con.commit();
                        return true;
                    } else {
                        System.err.println("Código de vinculación no encontrado.");
                    }
                }
            } catch (SQLException e) {
                con.rollback();
                System.err.println("Error en la transacción de enlace, se ejecutó rollback: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Error de conexión al enlazar inmueble: " + e.getMessage());
        }
        return false;
    }
    
    
    
    
    
    // --- MÉTODO PARA OBTENER EL NOMBRE DEL ARRENDATARIO VINCULADO ---
    public String obtenerNombreArrendatarioVinculado(int idInmueble) {
        String sql = "SELECT u.nombre FROM musuario u " + "INNER JOIN dacceso_inmueble d ON u.id_usuario = d.id_usuario " + "WHERE d.id_inmueble = ? AND d.vigente = 1";
        try (Connection con = utilidades.Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idInmueble);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("nombre");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener nombre de arrendatario: " + e.getMessage());
        }
        return "No enlazado";
    }
    
    
}
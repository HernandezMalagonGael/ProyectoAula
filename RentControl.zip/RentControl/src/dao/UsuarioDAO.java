package dao;
 
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Arrendador;
import modelo.Arrendatario;
import modelo.Usuario;
import utilidades.Conexion;
 
public class UsuarioDAO {
 
    // Create
    public boolean registrarUsuario(Usuario usuario) {
        String sql = "INSERT INTO musuario (id_tipo_usuario, nombre, correo, fecha_nacimiento, contrasena, activo) VALUES (?, ?, ?, ?, ?, ?)";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, usuario.getId_tipo_usuario());
            ps.setString(2, usuario.getNombre());
            ps.setString(3, usuario.getCorreo());
            ps.setDate(4, Date.valueOf(usuario.getFecha_nacimiento()));
            ps.setString(5, usuario.getContrasena());
            ps.setBoolean(6, usuario.isActivo());
 
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            return false;
        }
    }
 
    // Read
    public List<Usuario> consultarUsuarios() {
        List<Usuario> listaUsuarios = new ArrayList<>();
        String sql = "SELECT * FROM musuario";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
 
            while (rs.next()) {
                Usuario usuario = null;
                int tipo = rs.getInt("id_tipo_usuario");
 
                if (tipo == 2) {
                    usuario = new Arrendador();
                } else if (tipo == 3) {
                    usuario = new Arrendatario();
                }
 
                if (usuario != null) {
                    usuario.setId_usuario(rs.getInt("id_usuario"));
                    usuario.setId_tipo_usuario(tipo);
                    usuario.setNombre(rs.getString("nombre"));
                    usuario.setCorreo(rs.getString("correo"));
                    usuario.setFecha_nacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
                    usuario.setContrasena(rs.getString("contrasena"));
                    usuario.setActivo(rs.getBoolean("activo"));
 
                    if (rs.getTimestamp("fecha_registro") != null) {
                        usuario.setFecha_registro(rs.getTimestamp("fecha_registro").toLocalDateTime());
                    }
 
                    listaUsuarios.add(usuario);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar usuarios: " + e.getMessage());
        }
        return listaUsuarios;
    }
 
    // Busqueda por id
    public Usuario buscarUsuarioPorId(int idUsuario) {
        String sql = "SELECT * FROM musuario WHERE id_usuario = ?";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, idUsuario);
 
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = null;
                    int tipo = rs.getInt("id_tipo_usuario");
 
                    if (tipo == 2) {
                        usuario = new Arrendador();
                    } else if (tipo == 3) {
                        usuario = new Arrendatario();
                    }
 
                    if (usuario != null) {
                        usuario.setId_usuario(rs.getInt("id_usuario"));
                        usuario.setId_tipo_usuario(tipo);
                        usuario.setNombre(rs.getString("nombre"));
                        usuario.setCorreo(rs.getString("correo"));
                        usuario.setFecha_nacimiento(rs.getDate("fecha_nacimiento").toLocalDate());
                        usuario.setContrasena(rs.getString("contrasena"));
                        usuario.setActivo(rs.getBoolean("activo"));
 
                        if (rs.getTimestamp("fecha_registro") != null) {
                            usuario.setFecha_registro(rs.getTimestamp("fecha_registro").toLocalDateTime());
                        }
                    }
                    return usuario;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar usuario por ID: " + e.getMessage());
        }
        return null;
    }
 
    // Update
    public boolean actualizarUsuario(Usuario usuario) {
        String sql = "UPDATE musuario SET nombre = ?, correo = ?, contrasena = ?, fecha_nacimiento = ? WHERE id_usuario = ?";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getCorreo());
            ps.setString(3, usuario.getContrasena());
            ps.setDate(4, Date.valueOf(usuario.getFecha_nacimiento()));
            ps.setInt(5, usuario.getId_usuario());
 
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario: " + e.getMessage());
            return false;
        }
    }
 
    // Delete
    public boolean eliminarUsuario(int idUsuario) {
        String sql = "UPDATE musuario SET activo = 0 WHERE id_usuario = ?";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
 
            ps.setInt(1, idUsuario);
 
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario: " + e.getMessage());
            return false;
        }
    }
    
    
    public Usuario login(String correo, String contrasena) {
    String sql = "SELECT * FROM musuario WHERE nombre = ? AND contrasena = ? AND activo = 1";
    try (Connection con = Conexion.getConexion();
         PreparedStatement ps = con.prepareStatement(sql)) {
        ps.setString(1, correo);
        ps.setString(2, contrasena);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            int tipo = rs.getInt("id_tipo_usuario");
            Usuario u = (tipo == 2) ? new Arrendador() : new Arrendatario();
            u.setId_usuario(rs.getInt("id_usuario"));
            u.setId_tipo_usuario(tipo);
            u.setNombre(rs.getString("nombre"));
            u.setCorreo(rs.getString("correo"));
            return u;
        }
    } catch (java.sql.SQLException e) {
        System.err.println("Error en login: " + e.getMessage());
    }
    return null;
    }
    
}

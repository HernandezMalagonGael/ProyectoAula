package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modelo.Pago;
import utilidades.Conexion;

public class PagoDAO {

    // Create
    public boolean registrarPago(Pago pago) {
        String sqlEpago = "INSERT INTO epago (id_usuario, id_inmueble, estado_pago) VALUES (?, ?, ?)";
        String sqlDpago = "INSERT INTO dpago (id_pago, monto, fecha, periodo_tiempo, comprobante) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexion.getConexion()) {
            con.setAutoCommit(false);

            try (PreparedStatement psEpago = con.prepareStatement(sqlEpago, Statement.RETURN_GENERATED_KEYS)) {

                psEpago.setInt(1, pago.getId_usuario());
                psEpago.setInt(2, pago.getId_inmueble());
                psEpago.setString(3, pago.getEstado_pago());
                psEpago.executeUpdate();

                try (ResultSet keys = psEpago.getGeneratedKeys()) {
                    if (keys.next()) {
                        int idPagoGenerado = keys.getInt(1);
                        pago.setId_pago(idPagoGenerado);

                        try (PreparedStatement psDpago = con.prepareStatement(sqlDpago)) {
                            psDpago.setInt(1, idPagoGenerado);
                            psDpago.setDouble(2, pago.getMonto());
                            psDpago.setDate(3, Date.valueOf(pago.getFecha()));
                            psDpago.setString(4, pago.getPeriodo_tiempo());
                            psDpago.setString(5, pago.getComprobante());
                            psDpago.executeUpdate();
                        }

                        con.commit();
                        return true;
                    }
                }
            } catch (SQLException e) {
                con.rollback();
                System.err.println("Error al registrar pago, se revirtió la transacción: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Error de conexión al registrar pago: " + e.getMessage());
        }
        return false;
    }

    // Read
    public List<Pago> consultarPagos() {
        List<Pago> listaPagos = new ArrayList<>();
        String sql = "SELECT e.id_pago, e.id_usuario, e.id_inmueble, e.estado_pago, e.fecha_creacion, "
                   + "d.monto, d.fecha, d.periodo_tiempo, d.comprobante, d.fecha_registro "
                   + "FROM epago e "
                   + "INNER JOIN dpago d ON e.id_pago = d.id_pago";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                listaPagos.add(mapearPago(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar pagos: " + e.getMessage());
        }
        return listaPagos;
    }

    // Busqueda por id
    public Pago buscarPagoPorId(int idPago) {
        String sql = "SELECT e.id_pago, e.id_usuario, e.id_inmueble, e.estado_pago, e.fecha_creacion, "
                   + "d.monto, d.fecha, d.periodo_tiempo, d.comprobante, d.fecha_registro "
                   + "FROM epago e "
                   + "INNER JOIN dpago d ON e.id_pago = d.id_pago "
                   + "WHERE e.id_pago = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idPago);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearPago(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar pago por ID: " + e.getMessage());
        }
        return null;
    }

    // Update
    public boolean actualizarPago(Pago pago) {
        String sqlDpago = "UPDATE dpago SET monto = ?, fecha = ?, periodo_tiempo = ?, comprobante = ? WHERE id_pago = ?";
        String sqlEpago = "UPDATE epago SET estado_pago = ? WHERE id_pago = ?";

        try (Connection con = Conexion.getConexion()) {
            con.setAutoCommit(false);

            try (PreparedStatement psDpago = con.prepareStatement(sqlDpago);
                 PreparedStatement psEpago = con.prepareStatement(sqlEpago)) {

                psDpago.setDouble(1, pago.getMonto());
                psDpago.setDate(2, Date.valueOf(pago.getFecha()));
                psDpago.setString(3, pago.getPeriodo_tiempo());
                psDpago.setString(4, pago.getComprobante());
                psDpago.setInt(5, pago.getId_pago());
                psDpago.executeUpdate();

                psEpago.setString(1, pago.getEstado_pago());
                psEpago.setInt(2, pago.getId_pago());
                psEpago.executeUpdate();

                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                System.err.println("Error al actualizar pago, se revirtió la transacción: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar pago: " + e.getMessage());
        }
        return false;
    }

    // Delete
    public boolean eliminarPago(int idPago) {
        String sqlDpago = "DELETE FROM dpago WHERE id_pago = ?";
        String sqlEpago = "DELETE FROM epago WHERE id_pago = ?";

        try (Connection con = Conexion.getConexion()) {
            con.setAutoCommit(false);

            try (PreparedStatement psDpago = con.prepareStatement(sqlDpago);
                 PreparedStatement psEpago = con.prepareStatement(sqlEpago)) {

                psDpago.setInt(1, idPago);
                psDpago.executeUpdate();

                psEpago.setInt(1, idPago);
                psEpago.executeUpdate();

                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                System.err.println("Error al eliminar pago, se revirtió la transacción: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar pago: " + e.getMessage());
        }
        return false;
    }

    
    // Consultar pagos de un inmueble específico (JOIN epago + dpago)
    public List<Pago> consultarPagosPorInmueble(int idInmueble) {
        List<Pago> lista = new ArrayList<>();
        String sql = "SELECT e.id_pago, e.id_usuario, e.id_inmueble, e.estado_pago, "
                   + "e.fecha_creacion, d.monto, d.fecha, d.periodo_tiempo, "
                   + "d.comprobante, d.fecha_registro "
                   + "FROM epago e "
                   + "INNER JOIN dpago d ON e.id_pago = d.id_pago "
                   + "WHERE e.id_inmueble = ? "
                   + "ORDER BY e.fecha_creacion DESC";
 
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idInmueble);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearPago(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar pagos por inmueble: " + e.getMessage());
        }
        return lista;
    }
    
    
    // Método auxiliar para no repetir el mapeo en consultar y buscar
    private Pago mapearPago(ResultSet rs) throws SQLException {
        Pago pago = new Pago();

        pago.setId_pago(rs.getInt("id_pago"));
        pago.setId_usuario(rs.getInt("id_usuario"));
        pago.setId_inmueble(rs.getInt("id_inmueble"));
        pago.setEstado_pago(rs.getString("estado_pago"));

        if (rs.getTimestamp("fecha_creacion") != null) {
            pago.setFecha_creacion(rs.getTimestamp("fecha_creacion").toLocalDateTime());
        }

        pago.setMonto(rs.getDouble("monto"));
        pago.setFecha(rs.getDate("fecha").toLocalDate());
        pago.setPeriodo_tiempo(rs.getString("periodo_tiempo"));
        pago.setComprobante(rs.getString("comprobante"));

        if (rs.getTimestamp("fecha_registro") != null) {
            pago.setFecha_registro(rs.getTimestamp("fecha_registro").toLocalDateTime());
        }

        return pago;
    }
}
package controlador;

import dao.ReporteDAO;
import modelo.Reporte;

import java.util.ArrayList;
import java.util.List;

public class ReporteControlador {

    private List<Reporte> arregloReportes = new ArrayList<>();

    private final ReporteDAO reporteDAO;

    public ReporteControlador() {
        this.reporteDAO = new ReporteDAO();
        cargarDatos();
    }

    // --- SINCRONIZACION CON BD ---
    private void cargarDatos() {
        arregloReportes = reporteDAO.consultarReportes();
    }

    // --- METODO REGISTRAR ---
    public boolean registrarReporte(int idInmueble, int idUsuario, int idLugar,
                                    int idCategoria, String descripcion, String imagenMantenimiento) {

        Reporte nuevoReporte = new Reporte();

        nuevoReporte.setId_inmueble(idInmueble);
        nuevoReporte.setId_usuario(idUsuario);
        nuevoReporte.setId_lugar(idLugar);
        nuevoReporte.setId_categoria_problema(idCategoria);
        nuevoReporte.setDescripcion(descripcion);
        nuevoReporte.setEstado_mantenimiento("pendiente");
        nuevoReporte.setImagen_mantenimiento(imagenMantenimiento);

        arregloReportes.add(nuevoReporte);
        return reporteDAO.registrarReporte(nuevoReporte);
    }

    // --- METODOS PUENTE ---
    public List<Reporte> consultarReportes() {
        return reporteDAO.consultarReportes();
    }
    
    public List<Reporte> consultarReportesPorUsuario(int idUsuario) {
    return reporteDAO.consultarReportesPorUsuario(idUsuario);
    }

    public List<Reporte> consultarReportesPorInmueble(int idInmueble) {
        return reporteDAO.consultarReportesPorInmueble(idInmueble);
    }

    public Reporte buscarReportePorId(int idReporte) {
        return reporteDAO.buscarReportePorId(idReporte);
    }

    public boolean actualizarReporte(Reporte reporte) {
        return reporteDAO.actualizarReporte(reporte);
    }

    public boolean eliminarReporte(int idReporte) {
        return reporteDAO.eliminarReporte(idReporte);
    }

    // --- METODO DE IMPRESION ---
    public void imprimirReportesRegistrados() {
        arregloReportes = reporteDAO.consultarReportes();
        System.out.println("\n--- LISTA DE REPORTES DE MANTENIMIENTO ---");

        if (arregloReportes.isEmpty()) {
            System.out.println("No hay reportes registrados.");
            return;
        }

        for (Reporte r : arregloReportes) {
            System.out.println("-------------------------------------------------");
            System.out.println("ID Reporte   : " + r.getId_reporte_mantenimiento());
            System.out.println("ID Inmueble  : " + r.getId_inmueble());
            System.out.println("ID Usuario   : " + r.getId_usuario());
            System.out.println("ID Lugar     : " + r.getId_lugar());
            System.out.println("ID Categoria : " + r.getId_categoria_problema());
            System.out.println("Descripcion  : " + r.getDescripcion());
            System.out.println("Estado       : " + r.getEstado_mantenimiento());
            System.out.println("Imagen       : " + (r.getImagen_mantenimiento() != null ? r.getImagen_mantenimiento() : "No disponible"));
            System.out.println("Fecha Reporte: " + (r.getFecha_reporte() != null ? r.getFecha_reporte() : "No disponible"));
            System.out.println("Actualizado  : " + (r.getFecha_actualizacion() != null ? r.getFecha_actualizacion() : "No disponible"));
        }
        System.out.println("-------------------------------------------------");
    }
}
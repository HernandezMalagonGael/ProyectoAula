package controlador;

import dao.PagoDAO;
import modelo.Pago;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PagoControlador {

    private List<Pago> arregloPagos = new ArrayList<>();

    private final PagoDAO pagoDAO;

    public PagoControlador() {
        this.pagoDAO = new PagoDAO();
        cargarDatos();
    }

    // --- SINCRONIZACION CON BD ---
    private void cargarDatos() {
        arregloPagos = pagoDAO.consultarPagos();
    }

    // --- METODO REGISTRAR ---
    public boolean registrarPago(int idUsuario, int idInmueble, double monto,
                                 LocalDate fecha, String periodoTiempo, String comprobante) {

        Pago nuevoPago = new Pago();

        nuevoPago.setId_usuario(idUsuario);
        nuevoPago.setId_inmueble(idInmueble);
        nuevoPago.setEstado_pago("pagado");
        nuevoPago.setMonto(monto);
        nuevoPago.setFecha(fecha);
        nuevoPago.setPeriodo_tiempo(periodoTiempo);
        nuevoPago.setComprobante(comprobante);

        arregloPagos.add(nuevoPago);
        return pagoDAO.registrarPago(nuevoPago);
    }

    // --- METDOS PUENTE ---
    public List<Pago> consultarPagos() {
        return pagoDAO.consultarPagos();
    }

    public Pago buscarPagoPorId(int idPago) {
        return pagoDAO.buscarPagoPorId(idPago);
    }

    public boolean actualizarPago(Pago pago) {
        return pagoDAO.actualizarPago(pago);
    }

    public boolean eliminarPago(int idPago) {
        return pagoDAO.eliminarPago(idPago);
    }
    
    // Método puente: pagos filtrados por inmueble
    public java.util.List<Pago> consultarPagosPorInmueble(int idInmueble) {
        return pagoDAO.consultarPagosPorInmueble(idInmueble);
    }

    // --- METODO DE IMPRESION ---
    public void imprimirPagosRegistrados() {
        arregloPagos = pagoDAO.consultarPagos();
        System.out.println("\n--- LISTA DE PAGOS REGISTRADOS ---");

        if (arregloPagos.isEmpty()) {
            System.out.println("No hay pagos registrados.");
            return;
        }

        for (Pago p : arregloPagos) {
            System.out.println("-------------------------------------------------");
            System.out.println("ID Pago      : " + p.getId_pago());
            System.out.println("ID Inmueble  : " + p.getId_inmueble());
            System.out.println("ID Usuario   : " + p.getId_usuario());
            System.out.println("Monto        : $" + p.getMonto());
            System.out.println("Fecha Pago   : " + p.getFecha());
            System.out.println("Periodo      : " + p.getPeriodo_tiempo());
            System.out.println("Estado       : " + p.getEstado_pago());
            System.out.println("Comprobante  : " + (p.getComprobante() != null ? p.getComprobante() : "No disponible"));
            System.out.println("Creado       : " + (p.getFecha_creacion() != null ? p.getFecha_creacion() : "No disponible"));
            
        }
        System.out.println("-------------------------------------------------");
    }
}
package controlador;

import dao.UsuarioDAO;
import modelo.Arrendador;
import modelo.Arrendatario;
import modelo.Usuario;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UsuarioControlador {

    private List<Usuario> arregloUsuarios = new ArrayList<>();

    private final UsuarioDAO usuarioDAO;

    public UsuarioControlador() {
        this.usuarioDAO = new UsuarioDAO();
        cargarDatos();
    }

    // --- SINCRONIZACION CON BD ---
    private void cargarDatos() {
        arregloUsuarios = usuarioDAO.consultarUsuarios();
    }

    // --- METODO REGISTRAR ---
    public boolean registrarUsuario(String nombre, String correo, String contrasena, LocalDate fechaNacimiento, int tipoUsuario) {
        Usuario nuevoUsuario;

        if (tipoUsuario == 3) {
            nuevoUsuario = new Arrendatario();
            nuevoUsuario.setId_tipo_usuario(3);
        } else {
            nuevoUsuario = new Arrendador();
            nuevoUsuario.setId_tipo_usuario(2);
        }

        nuevoUsuario.setNombre(nombre);
        nuevoUsuario.setCorreo(correo);
        nuevoUsuario.setContrasena(contrasena);
        nuevoUsuario.setFecha_nacimiento(fechaNacimiento);
        nuevoUsuario.setActivo(true);
        
        arregloUsuarios.add(nuevoUsuario);
        
        return usuarioDAO.registrarUsuario(nuevoUsuario);
    }

    // --- METODOS PUENTE ---
    public List<Usuario> consultarUsuarios() {
        return usuarioDAO.consultarUsuarios();
    }

    public Usuario buscarUsuarioPorId(int idUsuario) {
        return usuarioDAO.buscarUsuarioPorId(idUsuario);
    }

    public boolean actualizarUsuario(Usuario usuario) {
        return usuarioDAO.actualizarUsuario(usuario);
    }

    public boolean eliminarUsuario(int idUsuario) {
        return usuarioDAO.eliminarUsuario(idUsuario);
    }
    
    public void cambiarEstadoActivo(int idUsuario, int estado) {
    // Aquí llamas a tu DAO para ejecutar el UPDATE musuario SET activo = ? WHERE id_usuario = ?
    }

    // --- METODO DE IMPRESION ---
    public void imprimirUsuariosRegistrados() {
        arregloUsuarios = usuarioDAO.consultarUsuarios();
        System.out.println("\n--- LISTA DE USUARIOS REGISTRADOS ---");

        if (arregloUsuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }

        for (Usuario u : arregloUsuarios) {
            String tipoTexto = "";
            if (u.getId_tipo_usuario() == 2) {
                tipoTexto = "Arrendador";
            } else if (u.getId_tipo_usuario() == 3) {
                tipoTexto = "Arrendatario";
            } else {
                continue;
            }

            System.out.println("-------------------------------------------------");
            System.out.println("ID Usuario: " + u.getId_usuario());
            System.out.println("Rol       : " + tipoTexto);
            System.out.println("Nombre    : " + u.getNombre());
            System.out.println("Correo    : " + u.getCorreo());
            System.out.println("Nacimiento: " + u.getFecha_nacimiento());
            System.out.println("Contrasena: " + u.getContrasena());
            System.out.println("Estado    : " + (u.isActivo() ? "Activo" : "Inactivo"));
            System.out.println("Registro  : " + (u.getFecha_registro() != null ? u.getFecha_registro() : "No disponible"));
        }
        System.out.println("-------------------------------------------------");
    }
}
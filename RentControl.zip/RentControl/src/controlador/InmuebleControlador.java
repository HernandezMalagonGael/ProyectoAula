package controlador;

import dao.InmuebleDAO;
import modelo.Inmueble;

import java.util.ArrayList;
import java.util.List;

public class InmuebleControlador {

    private List<Inmueble> arregloInmuebles = new ArrayList<>();

    private final InmuebleDAO inmuebleDAO;

    public InmuebleControlador() {
        this.inmuebleDAO = new InmuebleDAO();
        cargarDatos();
    }

    // --- SINCRONIZACION CON BD ---
    private void cargarDatos() {
        arregloInmuebles = inmuebleDAO.consultarInmuebles();
    }

    // --- GENERADOR DE CODIGO ---
    private String generarCodigoVinculacion() {
        int codigo = (int)(Math.random() * 900000) + 100000;
        return String.valueOf(codigo);
    }

    // --- METODO REGISTRAR ---
    public boolean registrarInmueble(int idUsuario, String calle, String numero, String colonia,
                                     String codigoPostal, String ciudad, String estado,
                                     double costoRenta, String imagenInmueble) {

        Inmueble nuevoInmueble = new Inmueble();

        nuevoInmueble.setId_usuario(idUsuario);
        nuevoInmueble.setCalle(calle);
        nuevoInmueble.setNumero(numero);
        nuevoInmueble.setColonia(colonia);
        nuevoInmueble.setCodigo_postal(codigoPostal);
        nuevoInmueble.setCiudad(ciudad);
        nuevoInmueble.setEstado(estado);
        nuevoInmueble.setCosto_renta(costoRenta);
        nuevoInmueble.setCodigo_vinculacion(generarCodigoVinculacion());
        nuevoInmueble.setEstado_inmueble("disponible");
        nuevoInmueble.setImagen_inmueble(imagenInmueble);

        arregloInmuebles.add(nuevoInmueble);
        return inmuebleDAO.registrarInmueble(nuevoInmueble);
    }
    
    
    
    

    
    // --- METODOS PUENTE ---
    public List<Inmueble> consultarInmuebles() {
        return inmuebleDAO.consultarInmuebles();
    }

    public Inmueble buscarInmueblePorId(int idInmueble) {
        return inmuebleDAO.buscarInmueblePorId(idInmueble);
    }

    public boolean actualizarInmueble(Inmueble inmueble) {
    boolean exito = inmuebleDAO.actualizarInmueble(inmueble);
    if (exito) {
        cargarDatos();
    }
    return exito;
}

    public boolean eliminarInmueble(int idInmueble) {
        return inmuebleDAO.eliminarInmueble(idInmueble);
    }
    
    public List<Inmueble> consultarInmueblesPorUsuario(int idUsuario) {
        return inmuebleDAO.consultarInmueblesPorUsuario(idUsuario);
    }
 
    public List<Inmueble> consultarInmueblesEnlazados(int idUsuario) {
        return inmuebleDAO.consultarInmueblesEnlazados(idUsuario);
    }
 
    public int contarInmueblesPorUsuario(int idUsuario) {
        return inmuebleDAO.contarInmueblesPorUsuario(idUsuario);
    }
    
    // --- MÉTODO PUENTE PARA BUSCAR POR CÓDIGO (para navegar a Vista tras enlace) ---
    public Inmueble buscarPorCodigoVinculacion(String codigo) {
        return inmuebleDAO.buscarPorCodigoVinculacion(codigo);
    }

        // --- MÉTODO PUENTE PARA EL PROCESO DE ENLACE ---
    public boolean enlazarInmueble(int idUsuarioArrendatario, String codigoVinculacion) {
        if (codigoVinculacion == null || codigoVinculacion.isBlank()) {
            return false;
        }
        return inmuebleDAO.enlazarInmueblePorCodigo(idUsuarioArrendatario, codigoVinculacion);
    }
    
    // --- MÉTODO PUENTE PARA OBTENER EL INQUILINO ASOCIADO ---
    public String obtenerNombreInquilino(int idInmueble) {
        return inmuebleDAO.obtenerNombreArrendatarioVinculado(idInmueble);
    }

    
    // --- METODO DE IMPRESION ---
    public void imprimirInmueblesRegistrados() {
        arregloInmuebles = inmuebleDAO.consultarInmuebles();
        System.out.println("\n--- LISTA DE INMUEBLES REGISTRADOS ---");

        if (arregloInmuebles.isEmpty()) {
            System.out.println("No hay inmuebles registrados.");
            return;
        }

        for (Inmueble i : arregloInmuebles) {
            System.out.println("-------------------------------------------------");
            System.out.println("ID Inmueble   : " + i.getId_inmueble());
            System.out.println("ID Propietario: " + i.getId_usuario());
            System.out.println("Direccion     : " + i.getCalle() + " #" + i.getNumero()
                    + ", " + i.getColonia() + ", CP " + i.getCodigo_postal());
            System.out.println("Ciudad/Estado : " + i.getCiudad() + ", " + i.getEstado());
            System.out.println("Costo Renta   : $" + i.getCosto_renta());
            System.out.println("Cod. Vinc.    : " + i.getCodigo_vinculacion());
            System.out.println("Estado        : " + i.getEstado_inmueble());
            System.out.println("Imagen        : " + i.getImagen_inmueble());
            System.out.println("Registro      : " + (i.getFecha_registro() != null ? i.getFecha_registro() : "No disponible"));
        }
        System.out.println("-------------------------------------------------");
    }
}
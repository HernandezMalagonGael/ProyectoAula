package modelo;

import java.time.LocalDate;
import java.time.LocalDateTime;

public abstract class Usuario {
    
    protected int id_usuario;
    protected int id_tipo_usuario; 
    protected String nombre;
    protected String correo;
    protected LocalDate fecha_nacimiento;
    protected String contrasena;
    protected boolean activo;
    protected LocalDateTime fecha_registro;

    public Usuario() {
    }

    public Usuario(int id_usuario, int id_tipo_usuario, String nombre, String correo, LocalDate fecha_nacimiento, String contrasena, boolean activo, LocalDateTime fecha_registro) {
        this.id_usuario = id_usuario;
        this.id_tipo_usuario = id_tipo_usuario;
        this.nombre = nombre;
        this.correo = correo;
        this.fecha_nacimiento = fecha_nacimiento;
        this.contrasena = contrasena;
        this.activo = activo;
        this.fecha_registro = fecha_registro;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_tipo_usuario() {
        return id_tipo_usuario;
    }

    public void setId_tipo_usuario(int id_tipo_usuario) {
        this.id_tipo_usuario = id_tipo_usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public LocalDate getFecha_nacimiento() {
        return fecha_nacimiento;
    }

    public void setFecha_nacimiento(LocalDate fecha_nacimiento) {
        this.fecha_nacimiento = fecha_nacimiento;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public LocalDateTime getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(LocalDateTime fecha_registro) {
        this.fecha_registro = fecha_registro;
    }
    
    

    
    
    
}

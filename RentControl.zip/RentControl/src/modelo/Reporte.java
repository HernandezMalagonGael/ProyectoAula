package modelo;

import java.time.LocalDateTime;

public class Reporte {
    
    private int id_reporte_mantenimiento;
    private int id_inmueble;
    private int id_usuario;
    private LocalDateTime fecha_reporte;
    private int id_lugar;
    private int id_categoria_problema;
    private String descripcion;
    private String estado_mantenimiento; 
    private String imagen_mantenimiento;
    private LocalDateTime fecha_actualizacion;

    public Reporte() {
    }

    public Reporte(int id_reporte_mantenimiento, int id_inmueble, int id_usuario, LocalDateTime fecha_reporte, int id_lugar, int id_categoria_problema, String descripcion, String estado_mantenimiento, String imagen_mantenimiento, LocalDateTime fecha_actualizacion) {
        this.id_reporte_mantenimiento = id_reporte_mantenimiento;
        this.id_inmueble = id_inmueble;
        this.id_usuario = id_usuario;
        this.fecha_reporte = fecha_reporte;
        this.id_lugar = id_lugar;
        this.id_categoria_problema = id_categoria_problema;
        this.descripcion = descripcion;
        this.estado_mantenimiento = estado_mantenimiento;
        this.imagen_mantenimiento = imagen_mantenimiento;
        this.fecha_actualizacion = fecha_actualizacion;
    }

    public int getId_reporte_mantenimiento() {
        return id_reporte_mantenimiento;
    }

    public void setId_reporte_mantenimiento(int id_reporte_mantenimiento) {
        this.id_reporte_mantenimiento = id_reporte_mantenimiento;
    }

    public int getId_inmueble() {
        return id_inmueble;
    }

    public void setId_inmueble(int id_inmueble) {
        this.id_inmueble = id_inmueble;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public LocalDateTime getFecha_reporte() {
        return fecha_reporte;
    }

    public void setFecha_reporte(LocalDateTime fecha_reporte) {
        this.fecha_reporte = fecha_reporte;
    }

    public int getId_lugar() {
        return id_lugar;
    }

    public void setId_lugar(int id_lugar) {
        this.id_lugar = id_lugar;
    }

    public int getId_categoria_problema() {
        return id_categoria_problema;
    }

    public void setId_categoria_problema(int id_categoria_problema) {
        this.id_categoria_problema = id_categoria_problema;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado_mantenimiento() {
        return estado_mantenimiento;
    }

    public void setEstado_mantenimiento(String estado_mantenimiento) {
        this.estado_mantenimiento = estado_mantenimiento;
    }

    public String getImagen_mantenimiento() {
        return imagen_mantenimiento;
    }

    public void setImagen_mantenimiento(String imagen_mantenimiento) {
        this.imagen_mantenimiento = imagen_mantenimiento;
    }

    public LocalDateTime getFecha_actualizacion() {
        return fecha_actualizacion;
    }

    public void setFecha_actualizacion(LocalDateTime fecha_actualizacion) {
        this.fecha_actualizacion = fecha_actualizacion;
    }

    
    
    
    
    
}

package modelo;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Arrendatario extends Usuario {

    public Arrendatario() {
        super();
        this.id_tipo_usuario = 3;
    }

    public Arrendatario(int id_usuario, String nombre, String correo, LocalDate fecha_nacimiento, String contrasena, boolean activo, LocalDateTime fecha_registro) {
        super(id_usuario, 3, nombre, correo, fecha_nacimiento, contrasena, activo, fecha_registro);
    }
}

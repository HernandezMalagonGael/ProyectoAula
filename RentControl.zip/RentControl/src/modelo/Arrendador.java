package modelo;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Arrendador extends Usuario {

    public Arrendador() {
        super();
        this.id_tipo_usuario = 2;
    }

    public Arrendador(int id_usuario, String nombre, String correo, LocalDate fecha_nacimiento, String contrasena, boolean activo, LocalDateTime fecha_registro) {
        super(id_usuario, 2, nombre, correo, fecha_nacimiento, contrasena, activo, fecha_registro);
    }
}

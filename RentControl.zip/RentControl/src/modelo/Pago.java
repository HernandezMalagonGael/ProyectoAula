package modelo;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Pago {

    // epago
    private int id_pago;
    private int id_usuario;
    private int id_inmueble;
    private String estado_pago; 
    private LocalDateTime fecha_creacion;

    // dpago
    private double monto;
    private LocalDate fecha;
    private String periodo_tiempo;
    private String comprobante;
    private LocalDateTime fecha_registro;

    public Pago() {
    }

    public Pago(int id_pago, int id_usuario, int id_inmueble, String estado_pago,
                LocalDateTime fecha_creacion, double monto, LocalDate fecha,
                String periodo_tiempo, String comprobante, LocalDateTime fecha_registro) {
        this.id_pago = id_pago;
        this.id_usuario = id_usuario;
        this.id_inmueble = id_inmueble;
        this.estado_pago = estado_pago;
        this.fecha_creacion = fecha_creacion;
        this.monto = monto;
        this.fecha = fecha;
        this.periodo_tiempo = periodo_tiempo;
        this.comprobante = comprobante;
        this.fecha_registro = fecha_registro;
    }

    public int getId_pago() {
        return id_pago;
    }

    public void setId_pago(int id_pago) {
        this.id_pago = id_pago;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_inmueble() {
        return id_inmueble;
    }

    public void setId_inmueble(int id_inmueble) {
        this.id_inmueble = id_inmueble;
    }

    public String getEstado_pago() {
        return estado_pago;
    }

    public void setEstado_pago(String estado_pago) {
        this.estado_pago = estado_pago;
    }

    public LocalDateTime getFecha_creacion() {
        return fecha_creacion;
    }

    public void setFecha_creacion(LocalDateTime fecha_creacion) {
        this.fecha_creacion = fecha_creacion;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getPeriodo_tiempo() {
        return periodo_tiempo;
    }

    public void setPeriodo_tiempo(String periodo_tiempo) {
        this.periodo_tiempo = periodo_tiempo;
    }

    public String getComprobante() {
        return comprobante;
    }

    public void setComprobante(String comprobante) {
        this.comprobante = comprobante;
    }

    public LocalDateTime getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(LocalDateTime fecha_registro) {
        this.fecha_registro = fecha_registro;
    }

    
}
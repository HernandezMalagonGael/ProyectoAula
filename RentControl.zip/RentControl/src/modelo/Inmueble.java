package modelo;

import java.time.LocalDateTime;

public class Inmueble {

    private int id_inmueble;
    private int id_usuario;
    private String calle;
    private String numero;
    private String colonia;
    private String codigo_postal;
    private String ciudad;
    private String estado;
    private double costo_renta;
    private String codigo_vinculacion;
    private String estado_inmueble;
    private String imagen_inmueble;
    private LocalDateTime fecha_registro;

    public Inmueble() {
    }

    public Inmueble(int id_inmueble, int id_usuario, String calle, String numero, String colonia,
                    String codigo_postal, String ciudad, String estado, double costo_renta,
                    String codigo_vinculacion, String estado_inmueble, String imagen_inmueble,
                    LocalDateTime fecha_registro) {
        this.id_inmueble = id_inmueble;
        this.id_usuario = id_usuario;
        this.calle = calle;
        this.numero = numero;
        this.colonia = colonia;
        this.codigo_postal = codigo_postal;
        this.ciudad = ciudad;
        this.estado = estado;
        this.costo_renta = costo_renta;
        this.codigo_vinculacion = codigo_vinculacion;
        this.estado_inmueble = estado_inmueble;
        this.imagen_inmueble = imagen_inmueble;
        this.fecha_registro = fecha_registro;
    }

    public int getId_inmueble() {
        return id_inmueble;
    }

    public void setId_inmueble(int id_inmueble) {
        this.id_inmueble = id_inmueble;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public String getCodigo_postal() {
        return codigo_postal;
    }

    public void setCodigo_postal(String codigo_postal) {
        this.codigo_postal = codigo_postal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getCosto_renta() {
        return costo_renta;
    }

    public void setCosto_renta(double costo_renta) {
        this.costo_renta = costo_renta;
    }

    public String getCodigo_vinculacion() {
        return codigo_vinculacion;
    }

    public void setCodigo_vinculacion(String codigo_vinculacion) {
        this.codigo_vinculacion = codigo_vinculacion;
    }

    public String getEstado_inmueble() {
        return estado_inmueble;
    }

    public void setEstado_inmueble(String estado_inmueble) {
        this.estado_inmueble = estado_inmueble;
    }

    public String getImagen_inmueble() {
        return imagen_inmueble;
    }

    public void setImagen_inmueble(String imagen_inmueble) {
        this.imagen_inmueble = imagen_inmueble;
    }

    public LocalDateTime getFecha_registro() {
        return fecha_registro;
    }

    public void setFecha_registro(LocalDateTime fecha_registro) {
        this.fecha_registro = fecha_registro;
    }
}
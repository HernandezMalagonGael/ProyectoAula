package principalcrud;

import controlador.UsuarioControlador;
import controlador.InmuebleControlador;
import controlador.PagoControlador;
import controlador.ReporteControlador;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * Cruz Fuentes Mónica
 * Cruz Terrero Cristo Marlon
 * García Gonzales Luis David
 * Hernández Malagón Gael
 * Vacio Pérez Andrea
 * 
 * HYGEONIX-EQUIPO 6
 * 
 */

public class PrincipalCRUD {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        UsuarioControlador usuarioControlador = new UsuarioControlador();
        InmuebleControlador inmuebleControlador = new InmuebleControlador();
        PagoControlador pagoControlador = new PagoControlador();
        ReporteControlador reporteControlador = new ReporteControlador();

        int opcionPrincipal = -1;

        while (opcionPrincipal != 0) {
            System.out.println("\n--------- PRUEBAS CRUD RENTCONTROL ----------");
            System.out.println("1.- CRUD para Usuarios");
            System.out.println("2.- CRUD para Inmuebles");
            System.out.println("3.- CRUD para Pagos");
            System.out.println("4.- CRUD para Reportes de Mantenimiento");
            System.out.println("0.- Salir del sistema");
            System.out.print("Elige tu opcion: ");

            try {
                opcionPrincipal = teclado.nextInt();
                teclado.nextLine();

                switch (opcionPrincipal) {
                    case 1:
                        MenuUsuarioCRUD.mostrar(teclado, usuarioControlador);
                        break;
                    case 2:
                        MenuInmueblesCRUD.mostrar(teclado, inmuebleControlador);
                        break;
                    case 3:
                        MenuPagoCRUD.mostrar(teclado, pagoControlador);
                        break;
                    case 4:
                        MenuReporteCRUD.mostrar(teclado, reporteControlador);
                        break;
                    case 0:
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("Opcion invalida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error, ingresa un numero valido.");
                teclado.nextLine();
            }
        }
    }
}
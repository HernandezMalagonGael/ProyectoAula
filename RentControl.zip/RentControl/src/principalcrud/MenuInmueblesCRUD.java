package principalcrud;

import controlador.InmuebleControlador;
import modelo.Inmueble;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuInmueblesCRUD {

    public static void mostrar(Scanner teclado, InmuebleControlador inmuebleControlador) {
        int opcion = -1;
        while (opcion != 0) {
            System.out.println("\n-- SUBMENU: INMUEBLES --");
            System.out.println("1. Agregar Inmueble");
            System.out.println("2. Modificar Inmueble");
            System.out.println("3. Consultar todos los Inmuebles");
            System.out.println("4. Buscar Inmueble por ID");
            System.out.println("5. Eliminar Inmueble (Baja logica)");
            System.out.println("0. Volver al Menu Principal");
            System.out.print("Elige una opcion: ");

            try {
                opcion = teclado.nextInt();
                teclado.nextLine();

                switch (opcion) {
                    case 1:
                        System.out.println("\n--- NUEVO INMUEBLE ---");

                        int idPropietario = 0;
                        do {
                            try {
                                System.out.print("ID del propietario (arrendador): ");
                                idPropietario = teclado.nextInt();
                                teclado.nextLine();
                                if (idPropietario <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idPropietario = 0;
                            }
                        } while (idPropietario <= 0);

                        String calle = "";
                        do {
                            System.out.print("Calle: ");
                            calle = teclado.nextLine().trim();
                            if (calle.isEmpty() || calle.length() > 150) {
                                System.out.println("Calle invalida (max 150 caracteres).");
                            }
                        } while (calle.isEmpty() || calle.length() > 150);

                        String numero = "";
                        do {
                            System.out.print("Numero: ");
                            numero = teclado.nextLine().trim();
                            if (numero.isEmpty() || numero.length() > 20) {
                                System.out.println("Numero invalido (max 20 caracteres).");
                            }
                        } while (numero.isEmpty() || numero.length() > 20);

                        String colonia = "";
                        do {
                            System.out.print("Colonia: ");
                            colonia = teclado.nextLine().trim();
                            if (colonia.isEmpty() || colonia.length() > 100) {
                                System.out.println("Colonia invalida (max 100 caracteres).");
                            }
                        } while (colonia.isEmpty() || colonia.length() > 100);

                        String codigoPostal = "";
                        do {
                            System.out.print("Codigo postal (solo 5 digitos): ");
                            codigoPostal = teclado.nextLine().trim();
                            if (!codigoPostal.matches("^[0-9]{5}$")) {
                                System.out.println("Codigo postal invalido (solo 5 digitos).");
                            }
                        } while (!codigoPostal.matches("^[0-9]{5}$"));

                        String ciudad = "";
                        do {
                            System.out.print("Ciudad: ");
                            ciudad = teclado.nextLine().trim();
                            if (ciudad.isEmpty() || ciudad.length() > 100) {
                                System.out.println("Ciudad invalida (max 100 caracteres).");
                            }
                        } while (ciudad.isEmpty() || ciudad.length() > 100);

                        String estado = "";
                        do {
                            System.out.print("Estado: ");
                            estado = teclado.nextLine().trim();
                            if (estado.isEmpty() || estado.length() > 100) {
                                System.out.println("Estado invalido (max 100 caracteres).");
                            }
                        } while (estado.isEmpty() || estado.length() > 100);

                        double costoRenta = -1;
                        do {
                            try {
                                System.out.print("Costo de renta: ");
                                costoRenta = teclado.nextDouble();
                                teclado.nextLine();
                                if (costoRenta <= 0) {
                                    System.out.println("El costo debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                costoRenta = -1;
                            }
                        } while (costoRenta <= 0);

                        System.out.print("Ruta o URL de la imagen (opcional, Enter para omitir): ");
                        String imagen = teclado.nextLine().trim();
                        if (imagen.isEmpty()) {
                            imagen = null;
                        }

                        if (inmuebleControlador.registrarInmueble(idPropietario, calle, numero, colonia,
                                codigoPostal, ciudad, estado, costoRenta, imagen)) {
                            System.out.println("\nInmueble agregado exitosamente.");
                        } else {
                            System.out.println("\nError al agregar inmueble (verifica que el ID del propietario exista).");
                        }
                        break;

                    case 2:
                        System.out.println("\n--- MODIFICAR INMUEBLE ---");

                        int idModificar = 0;
                        do {
                            try {
                                System.out.print("ID del inmueble a modificar: ");
                                idModificar = teclado.nextInt();
                                teclado.nextLine();
                                if (idModificar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idModificar = 0;
                            }
                        } while (idModificar <= 0);

                        Inmueble inmuebleAModificar = inmuebleControlador.buscarInmueblePorId(idModificar);
                        if (inmuebleAModificar == null) {
                            System.out.println("No existe ningun inmueble con el ID: " + idModificar);
                            break;
                        }

                        String nuevaCalle = "";
                        do {
                            System.out.print("Nueva calle: ");
                            nuevaCalle = teclado.nextLine().trim();
                            if (nuevaCalle.isEmpty() || nuevaCalle.length() > 150) {
                                System.out.println("Calle invalida (max 150 caracteres).");
                            }
                        } while (nuevaCalle.isEmpty() || nuevaCalle.length() > 150);

                        String nuevoNumero = "";
                        do {
                            System.out.print("Nuevo numero: ");
                            nuevoNumero = teclado.nextLine().trim();
                            if (nuevoNumero.isEmpty() || nuevoNumero.length() > 20) {
                                System.out.println("Numero invalido (max 20 caracteres).");
                            }
                        } while (nuevoNumero.isEmpty() || nuevoNumero.length() > 20);

                        String nuevaColonia = "";
                        do {
                            System.out.print("Nueva colonia: ");
                            nuevaColonia = teclado.nextLine().trim();
                            if (nuevaColonia.isEmpty() || nuevaColonia.length() > 100) {
                                System.out.println("Colonia invalida (max 100 caracteres).");
                            }
                        } while (nuevaColonia.isEmpty() || nuevaColonia.length() > 100);

                        String nuevoCodigoPostal = "";
                        do {
                            System.out.print("Nuevo codigo postal (solo 5 digitos): ");
                            nuevoCodigoPostal = teclado.nextLine().trim();
                            if (!nuevoCodigoPostal.matches("^[0-9]{5}$")) {
                                System.out.println("Codigo postal invalido (solo 5 digitos).");
                            }
                        } while (!nuevoCodigoPostal.matches("^[0-9]{5}$"));

                        String nuevaCiudad = "";
                        do {
                            System.out.print("Nueva ciudad: ");
                            nuevaCiudad = teclado.nextLine().trim();
                            if (nuevaCiudad.isEmpty() || nuevaCiudad.length() > 100) {
                                System.out.println("Ciudad invalida (max 100 caracteres).");
                            }
                        } while (nuevaCiudad.isEmpty() || nuevaCiudad.length() > 100);

                        String nuevoEstado = "";
                        do {
                            System.out.print("Nuevo estado: ");
                            nuevoEstado = teclado.nextLine().trim();
                            if (nuevoEstado.isEmpty() || nuevoEstado.length() > 100) {
                                System.out.println("Estado invalido (max 100 caracteres).");
                            }
                        } while (nuevoEstado.isEmpty() || nuevoEstado.length() > 100);

                        double nuevoCosto = -1;
                        do {
                            try {
                                System.out.print("Nuevo costo de renta: ");
                                nuevoCosto = teclado.nextDouble();
                                teclado.nextLine();
                                if (nuevoCosto <= 0) {
                                    System.out.println("El costo debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                nuevoCosto = -1;
                            }
                        } while (nuevoCosto <= 0);

                        System.out.print("Nueva imagen (Enter para conservar la actual): ");
                        String nuevaImagen = teclado.nextLine().trim();
                        if (nuevaImagen.isEmpty()) {
                            nuevaImagen = inmuebleAModificar.getImagen_inmueble();
                        }

                        inmuebleAModificar.setCalle(nuevaCalle);
                        inmuebleAModificar.setNumero(nuevoNumero);
                        inmuebleAModificar.setColonia(nuevaColonia);
                        inmuebleAModificar.setCodigo_postal(nuevoCodigoPostal);
                        inmuebleAModificar.setCiudad(nuevaCiudad);
                        inmuebleAModificar.setEstado(nuevoEstado);
                        inmuebleAModificar.setCosto_renta(nuevoCosto);
                        inmuebleAModificar.setImagen_inmueble(nuevaImagen);

                        if (inmuebleControlador.actualizarInmueble(inmuebleAModificar)) {
                            System.out.println("\nInmueble modificado correctamente.");
                        } else {
                            System.out.println("\nNo se pudo modificar el inmueble.");
                        }
                        break;

                    case 3:
                        inmuebleControlador.imprimirInmueblesRegistrados();
                        break;

                    case 4:
                        System.out.println("\n--- BUSCAR INMUEBLE POR ID ---");

                        int idBuscar = 0;
                        do {
                            try {
                                System.out.print("Ingresa el ID del inmueble: ");
                                idBuscar = teclado.nextInt();
                                teclado.nextLine();
                                if (idBuscar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idBuscar = 0;
                            }
                        } while (idBuscar <= 0);

                        Inmueble inmuebleEncontrado = inmuebleControlador.buscarInmueblePorId(idBuscar);

                        if (inmuebleEncontrado == null) {
                            System.out.println("No se encontro ningun inmueble con el ID: " + idBuscar);
                        } else {
                            System.out.println("-------------------------------------------------");
                            System.out.println("ID Inmueble   : " + inmuebleEncontrado.getId_inmueble());
                            System.out.println("ID Propietario: " + inmuebleEncontrado.getId_usuario());
                            System.out.println("Direccion     : " + inmuebleEncontrado.getCalle() + " #" + inmuebleEncontrado.getNumero()
                                    + ", " + inmuebleEncontrado.getColonia() + ", CP " + inmuebleEncontrado.getCodigo_postal());
                            System.out.println("Ciudad/Estado : " + inmuebleEncontrado.getCiudad() + ", " + inmuebleEncontrado.getEstado());
                            System.out.println("Costo Renta   : $" + inmuebleEncontrado.getCosto_renta());
                            System.out.println("Cod. Vinc.    : " + inmuebleEncontrado.getCodigo_vinculacion());
                            System.out.println("Estado        : " + inmuebleEncontrado.getEstado_inmueble());
                            System.out.println("Imagen        : " + inmuebleEncontrado.getImagen_inmueble());
                            System.out.println("Registro      : " + (inmuebleEncontrado.getFecha_registro() != null ? inmuebleEncontrado.getFecha_registro() : "No disponible"));
                            System.out.println("-------------------------------------------------");
                        }
                        break;

                    case 5:
                        System.out.print("ID del inmueble a eliminar (Baja logica): ");
                        int idEliminar = teclado.nextInt();
                        teclado.nextLine();

                        if (inmuebleControlador.eliminarInmueble(idEliminar)) {
                            System.out.println("Inmueble marcado como inactivo correctamente.");
                        } else {
                            System.out.println("Error al eliminar. Verifica el ID.");
                        }
                        break;

                    case 0:
                        System.out.println("Regresando al menu principal...");
                        break;

                    default:
                        System.out.println("Opcion invalida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error, ingresa un numero valido.");
                teclado.nextLine();
            }
        }
    }
}
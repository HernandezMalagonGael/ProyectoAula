package principalcrud;

import controlador.ReporteControlador;
import modelo.Reporte;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuReporteCRUD {

    public static void mostrar(Scanner teclado, ReporteControlador reporteControlador) {
        int opcion = -1;
        while (opcion != 0) {
            System.out.println("\n-- SUBMENU: REPORTES DE MANTENIMIENTO --");
            System.out.println("1. Registrar Reporte");
            System.out.println("2. Modificar Reporte");
            System.out.println("3. Consultar todos los Reportes");
            System.out.println("4. Buscar Reporte por ID");
            System.out.println("5. Eliminar Reporte");
            System.out.println("0. Volver al Menu Principal");
            System.out.print("Elige una opcion: ");

            try {
                opcion = teclado.nextInt();
                teclado.nextLine();

                switch (opcion) {
                    case 1:
                        System.out.println("\n--- REGISTRAR REPORTE ---");

                        // ID del inmueble
                        int idInmueble = 0;
                        do {
                            try {
                                System.out.print("ID del inmueble: ");
                                idInmueble = teclado.nextInt();
                                teclado.nextLine();
                                if (idInmueble <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idInmueble = 0;
                            }
                        } while (idInmueble <= 0);

                        // ID del arrendatario
                        int idUsuario = 0;
                        do {
                            try {
                                System.out.print("ID del arrendatario: ");
                                idUsuario = teclado.nextInt();
                                teclado.nextLine();
                                if (idUsuario <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idUsuario = 0;
                            }
                        } while (idUsuario <= 0);

                        // lugar
                        System.out.println("\nLugares disponibles:");
                        System.out.println("  1.- Baño");
                        System.out.println("  2.- Cocina");
                        System.out.println("  3.- Habitaciones");
                        System.out.println("  4.- Sala/Comedor");
                        System.out.println("  5.- Área de lavado");
                        System.out.println("  6.- Área común (escaleras, pasillos, entrada)");
                        System.out.println("  7.- Fachada/Exterior");

                        int idLugar = 0;
                        do {
                            try {
                                System.out.print("Selecciona el lugar (1-7): ");
                                idLugar = teclado.nextInt();
                                teclado.nextLine();
                                if (idLugar < 1 || idLugar > 7) {
                                    System.out.println("Opcion no valida.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idLugar = 0;
                            }
                        } while (idLugar < 1 || idLugar > 7);

                        // categoria
                        System.out.println("\nCategorias para ese lugar:");
                        imprimirCategoriasPorLugar(idLugar);

                        int[] rangos = {5, 5, 5, 5, 4, 4, 4};
                        int[] inicios = {1, 6, 11, 16, 21, 25, 29};
                        int inicio = inicios[idLugar - 1];
                        int fin = inicio + rangos[idLugar - 1] - 1;

                        int idCategoria = 0;
                        do {
                            try {
                                System.out.print("Selecciona la categoria (" + inicio + "-" + fin + "): ");
                                idCategoria = teclado.nextInt();
                                teclado.nextLine();
                                if (idCategoria < inicio || idCategoria > fin) {
                                    System.out.println("Opcion no valida para ese lugar.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idCategoria = 0;
                            }
                        } while (idCategoria < inicio || idCategoria > fin);

                        // descripcion
                        String descripcion = "";
                        do {
                            System.out.print("Descripcion del problema: ");
                            descripcion = teclado.nextLine().trim();
                            if (descripcion.isEmpty()) {
                                System.out.println("La descripcion no puede estar vacia.");
                            }
                        } while (descripcion.isEmpty());

                        // imagen
                        System.out.print("Ruta o URL de la imagen (opcional, Enter para omitir): ");
                        String imagen = teclado.nextLine().trim();
                        if (imagen.isEmpty()) {
                            imagen = null;
                        }

                        if (reporteControlador.registrarReporte(idInmueble, idUsuario, idLugar,
                                idCategoria, descripcion, imagen)) {
                            System.out.println("\nReporte registrado exitosamente.");
                        } else {
                            System.out.println("\nError al registrar el reporte. Verifica los IDs.");
                        }
                        break;

                    case 2:
                        System.out.println("\n--- MODIFICAR REPORTE ---");

                        int idModificar = 0;
                        do {
                            try {
                                System.out.print("ID del reporte a modificar: ");
                                idModificar = teclado.nextInt();
                                teclado.nextLine();
                                if (idModificar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idModificar = 0;
                            }
                        } while (idModificar <= 0);

                        Reporte reporteAModificar = reporteControlador.buscarReportePorId(idModificar);
                        if (reporteAModificar == null) {
                            System.out.println("No existe ningun reporte con el ID: " + idModificar);
                            break;
                        }

                        // nuevo lugar
                        System.out.println("\nLugares disponibles:");
                        System.out.println("  1.- Sanitario");
                        System.out.println("  2.- Cocina");
                        System.out.println("  3.- Habitaciones");
                        System.out.println("  4.- Sala/Comedor");
                        System.out.println("  5.- Area de lavado");
                        System.out.println("  6.- Area comun (escaleras, pasillos, entrada)");
                        System.out.println("  7.- Fachada/Exterior");

                        int nuevoLugar = 0;
                        do {
                            try {
                                System.out.print("Nuevo lugar (1-7): ");
                                nuevoLugar = teclado.nextInt();
                                teclado.nextLine();
                                if (nuevoLugar < 1 || nuevoLugar > 7) {
                                    System.out.println("Opcion no valida.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                nuevoLugar = 0;
                            }
                        } while (nuevoLugar < 1 || nuevoLugar > 7);

                        // nueva categoria
                        System.out.println("\nCategorias para ese lugar:");
                        imprimirCategoriasPorLugar(nuevoLugar);

                        int[] rangosM = {5, 5, 5, 5, 4, 4, 4};
                        int[] iniciosM = {1, 6, 11, 16, 21, 25, 29};
                        int inicioM = iniciosM[nuevoLugar - 1];
                        int finM = inicioM + rangosM[nuevoLugar - 1] - 1;

                        int nuevaCategoria = 0;
                        do {
                            try {
                                System.out.print("Nueva categoria (" + inicioM + "-" + finM + "): ");
                                nuevaCategoria = teclado.nextInt();
                                teclado.nextLine();
                                if (nuevaCategoria < inicioM || nuevaCategoria > finM) {
                                    System.out.println("Opcion no valida para ese lugar.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                nuevaCategoria = 0;
                            }
                        } while (nuevaCategoria < inicioM || nuevaCategoria > finM);

                        // nueva descripcion
                        String nuevaDescripcion = "";
                        do {
                            System.out.print("Nueva descripcion: ");
                            nuevaDescripcion = teclado.nextLine().trim();
                            if (nuevaDescripcion.isEmpty()) {
                                System.out.println("La descripcion no puede estar vacia.");
                            }
                        } while (nuevaDescripcion.isEmpty());

                        // nueva imagen
                        System.out.print("Nueva imagen (Enter para conservar la actual): ");
                        String nuevaImagen = teclado.nextLine().trim();
                        if (nuevaImagen.isEmpty()) {
                            nuevaImagen = reporteAModificar.getImagen_mantenimiento();
                        }

                        // nuevo estado
                        int opcionEstado = 0;
                        do {
                            try {
                                System.out.println("Nuevo estado:");
                                System.out.println("  1.- pendiente");
                                System.out.println("  2.- en proceso");
                                System.out.println("  3.- completado");
                                System.out.println("  4.- cancelado");
                                System.out.print("Opcion: ");
                                opcionEstado = teclado.nextInt();
                                teclado.nextLine();
                                if (opcionEstado < 1 || opcionEstado > 4) {
                                    System.out.println("Opcion no valida.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                opcionEstado = 0;
                            }
                        } while (opcionEstado < 1 || opcionEstado > 4);

                        String[] estados = {"pendiente", "en_proceso", "completado", "cancelado"};
                        String nuevoEstado = estados[opcionEstado - 1];

                        reporteAModificar.setId_lugar(nuevoLugar);
                        reporteAModificar.setId_categoria_problema(nuevaCategoria);
                        reporteAModificar.setDescripcion(nuevaDescripcion);
                        reporteAModificar.setImagen_mantenimiento(nuevaImagen);
                        reporteAModificar.setEstado_mantenimiento(nuevoEstado);

                        if (reporteControlador.actualizarReporte(reporteAModificar)) {
                            System.out.println("\nReporte modificado correctamente.");
                        } else {
                            System.out.println("\nNo se pudo modificar el reporte.");
                        }
                        break;

                    case 3:
                        reporteControlador.imprimirReportesRegistrados();
                        break;

                    case 4:
                        System.out.println("\n--- BUSCAR REPORTE POR ID ---");

                        int idBuscar = 0;
                        do {
                            try {
                                System.out.print("Ingresa el ID del reporte: ");
                                idBuscar = teclado.nextInt();
                                teclado.nextLine();
                                if (idBuscar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idBuscar = 0;
                            }
                        } while (idBuscar <= 0);

                        Reporte reporteEncontrado = reporteControlador.buscarReportePorId(idBuscar);

                        if (reporteEncontrado == null) {
                            System.out.println("No se encontro ningun reporte con el ID: " + idBuscar);
                        } else {
                            System.out.println("-------------------------------------------------");
                            System.out.println("ID Reporte   : " + reporteEncontrado.getId_reporte_mantenimiento());
                            System.out.println("ID Inmueble  : " + reporteEncontrado.getId_inmueble());
                            System.out.println("ID Usuario   : " + reporteEncontrado.getId_usuario());
                            System.out.println("ID Lugar     : " + reporteEncontrado.getId_lugar());
                            System.out.println("ID Categoria : " + reporteEncontrado.getId_categoria_problema());
                            System.out.println("Descripcion  : " + reporteEncontrado.getDescripcion());
                            System.out.println("Estado       : " + reporteEncontrado.getEstado_mantenimiento());
                            System.out.println("Imagen       : " + (reporteEncontrado.getImagen_mantenimiento() != null ? reporteEncontrado.getImagen_mantenimiento() : "No disponible"));
                            System.out.println("Fecha Reporte: " + (reporteEncontrado.getFecha_reporte() != null ? reporteEncontrado.getFecha_reporte() : "No disponible"));
                            System.out.println("Actualizado  : " + (reporteEncontrado.getFecha_actualizacion() != null ? reporteEncontrado.getFecha_actualizacion() : "No disponible"));
                            System.out.println("-------------------------------------------------");
                        }
                        break;

                    case 5:
                        System.out.print("ID del reporte a eliminar: ");
                        int idEliminar = teclado.nextInt();
                        teclado.nextLine();

                        if (reporteControlador.eliminarReporte(idEliminar)) {
                            System.out.println("Reporte eliminado correctamente.");
                        } else {
                            System.out.println("Error al eliminar. Verifica el ID.");
                        }
                        break;

                    case 0:
                        System.out.println("Regresando al menu principal...");
                        break;

                    default:
                        System.out.println("Opcion invalida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error, ingresa un numero valido.");
                teclado.nextLine();
            }
        }
    }

    // para que al mostrar las categorias se vea bonito
    private static void imprimirCategoriasPorLugar(int idLugar) {
        switch (idLugar) {
            case 1: // Baño
                System.out.println("  1.- Plomeria/agua");
                System.out.println("  2.- Humedad / Filtraciones");
                System.out.println("  3.- Electrico");
                System.out.println("  4.- Sanitarios");
                System.out.println("  5.- Acabados");
                break;
            case 2: // Cocina
                System.out.println("  6.- Plomeria / Agua");
                System.out.println("  7.- Gas");
                System.out.println("  8.- Electrico");
                System.out.println("  9.- Ventilación");
                System.out.println("  10.- Acabados");
                break;
            case 3: // Habitaciones
                System.out.println("  11.- Electrico");
                System.out.println("  12.- Humedad / Filtraciones");
                System.out.println("  13.- Ventanas / Puertas");
                System.out.println("  14.- Acabados");
                System.out.println("  15.- Ventilacion / Clima");
                break;
            case 4: // Sala/Comedor
                System.out.println("  16.- Electrico");
                System.out.println("  17.- Humedad / Filtraciones");
                System.out.println("  18.- Ventanas / Puertas");
                System.out.println("  19.- Acabados");
                System.out.println("  20.- Aislamiento");
                break;
            case 5: // Área de lavado
                System.out.println("  21.- Plomeria / Agua");
                System.out.println("  22.- Electrico");
                System.out.println("  23.- Humedad");
                System.out.println("  24.- Instalaciones");
                break;
            case 6: // Área común
                System.out.println("  25.- Iluminacion");
                System.out.println("  26.- Estructura");
                System.out.println("  27.- Seguridad");
                System.out.println("  28.- Limpieza / Plagas");
                break;
            case 7: // Fachada/Exterior
                System.out.println("  29.- Estructura");
                System.out.println("  30.- Humedad");
                System.out.println("  31.- Puertas / Accesos");
                System.out.println("  32.- Pintura / Acabados");
                break;
        }
    }
}
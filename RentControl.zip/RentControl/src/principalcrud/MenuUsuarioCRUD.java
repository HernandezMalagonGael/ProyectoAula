package principalcrud;

import controlador.UsuarioControlador;
import modelo.Usuario;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuUsuarioCRUD {

    public static void mostrar(Scanner teclado, UsuarioControlador usuarioControlador) {
        int opcion = -1;
        while (opcion != 0) {
            System.out.println("\n-- SUBMENU: USUARIOS --");
            System.out.println("1. Agregar Usuario");
            System.out.println("2. Modificar Usuario");
            System.out.println("3. Consultar todos los Usuarios");
            System.out.println("4. Buscar Usuario por ID");
            System.out.println("5. Eliminar Usuario (Baja logica)");
            System.out.println("0. Volver al Menu Principal");
            System.out.print("Elige una opcion: ");

            try {
                opcion = teclado.nextInt();
                teclado.nextLine();

                switch (opcion) {
                    case 1:
                        System.out.println("\n--- NUEVO USUARIO ---");

                        String nombre = "";
                        do {
                            try {
                                System.out.print("Escribe el nombre (Solo letras): ");
                                nombre = teclado.nextLine().trim();
                                if (nombre.isEmpty() || nombre.length() > 100 || !nombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$")) {
                                    System.out.println("Nombre invalido. Usa solo letras (max 100 caracteres).");
                                }
                            } catch (Exception e) {
                                System.out.println("Error al leer el nombre.");
                                nombre = "";
                            }
                        } while (nombre.isEmpty() || nombre.length() > 100 || !nombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$"));

                        String correo = "";
                        do {
                            try {
                                System.out.print("Escribe el correo: ");
                                correo = teclado.nextLine().trim();
                                if (correo.isEmpty() || correo.length() > 150 || !correo.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                                    System.out.println("Correo invalido.");
                                }
                            } catch (Exception e) {
                                System.out.println("Error al leer el correo.");
                                correo = "";
                            }
                        } while (correo.isEmpty() || correo.length() > 150 || !correo.matches("^[A-Za-z0-9+_.-]+@(.+)$"));

                        String pass = "";
                        do {
                            try {
                                System.out.print("Escribe la contrasena (Min 8, max 12 caracteres): ");
                                pass = teclado.nextLine().trim();
                                if (pass.length() < 8 || pass.length() > 12) {
                                    System.out.println("La contrasena debe tener al menos 8 y maximo 12 caracteres.");
                                }
                            } catch (Exception e) {
                                System.out.println("Error al leer la contrasena.");
                                pass = "";
                            }
                        } while (pass.length() < 8 || pass.length() > 12);

                        LocalDate fechaNacimiento = null;
                        boolean fechaValida = false;
                        do {
                            try {
                                System.out.print("Fecha de nacimiento (YYYY-MM-DD): ");
                                String fechaStr = teclado.nextLine().trim();
                                fechaNacimiento = LocalDate.parse(fechaStr);
                                if (fechaNacimiento.isAfter(LocalDate.now().minusYears(18))) {
                                    System.out.println("Debes ser mayor de 18 years.");
                                    fechaValida = false;
                                } else {
                                    fechaValida = true;
                                }
                            } catch (Exception e) {
                                System.out.println("Formato incorrecto. Usa YYYY-MM-DD.");
                                fechaValida = false;
                            }
                        } while (!fechaValida);

                        int tipoUsuario = 0;
                        do {
                            try {
                                System.out.println("\nTipo de usuario:");
                                System.out.println("  2.- Arrendador");
                                System.out.println("  3.- Arrendatario");
                                System.out.print("Opcion (2 o 3): ");
                                tipoUsuario = teclado.nextInt();
                                teclado.nextLine();
                                if (tipoUsuario != 2 && tipoUsuario != 3) {
                                    System.out.println("Opcion no valida.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero.");
                                teclado.nextLine();
                                tipoUsuario = 0;
                            }
                        } while (tipoUsuario != 2 && tipoUsuario != 3);

                        if (usuarioControlador.registrarUsuario(nombre, correo, pass, fechaNacimiento, tipoUsuario)) {
                            System.out.println("\nUsuario agregado exitosamente.");
                        } else {
                            System.out.println("\nError al agregar usuario (el correo podria estar duplicado).");
                        }
                        break;

                    case 2:
                        System.out.println("\n--- MODIFICAR USUARIO ---");

                        int idModificar = 0;
                        do {
                            try {
                                System.out.print("ID del usuario a modificar: ");
                                idModificar = teclado.nextInt();
                                teclado.nextLine();
                                if (idModificar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idModificar = 0;
                            }
                        } while (idModificar <= 0);

                        Usuario userAModificar = usuarioControlador.buscarUsuarioPorId(idModificar);
                        if (userAModificar == null) {
                            System.out.println("No existe ningun usuario con el ID: " + idModificar);
                            break;
                        }

                        String nuevoNombre = "";
                        do {
                            try {
                                System.out.print("Nuevo nombre (Solo letras, max 100): ");
                                nuevoNombre = teclado.nextLine().trim();
                                if (nuevoNombre.isEmpty() || nuevoNombre.length() > 100 || !nuevoNombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$")) {
                                    System.out.println("Nombre invalido. Usa solo letras (max 100).");
                                }
                            } catch (Exception e) {
                                System.out.println("Error al leer el nombre.");
                                nuevoNombre = "";
                            }
                        } while (nuevoNombre.isEmpty() || nuevoNombre.length() > 100 || !nuevoNombre.matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$"));

                        String nuevoCorreo = "";
                        do {
                            try {
                                System.out.print("Nuevo correo: ");
                                nuevoCorreo = teclado.nextLine().trim();
                                if (nuevoCorreo.isEmpty() || nuevoCorreo.length() > 150 || !nuevoCorreo.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                                    System.out.println("Correo invalido.");
                                }
                            } catch (Exception e) {
                                System.out.println("Error al leer el correo.");
                                nuevoCorreo = "";
                            }
                        } while (nuevoCorreo.isEmpty() || nuevoCorreo.length() > 150 || !nuevoCorreo.matches("^[A-Za-z0-9+_.-]+@(.+)$"));

                        String nuevaPass = "";
                        do {
                            try {
                                System.out.print("Nueva contrasena (Min 6 caracteres): ");
                                nuevaPass = teclado.nextLine().trim();
                                if (nuevaPass.length() < 6 || nuevaPass.length() > 255) {
                                    System.out.println("La contrasena debe tener al menos 6 caracteres.");
                                }
                            } catch (Exception e) {
                                System.out.println("Error al leer la contrasena.");
                                nuevaPass = "";
                            }
                        } while (nuevaPass.length() < 6 || nuevaPass.length() > 255);

                        LocalDate nuevaFecha = null;
                        boolean nuevaFechaValida = false;
                        do {
                            try {
                                System.out.print("Nueva fecha de nacimiento (YYYY-MM-DD): ");
                                String fechaStr = teclado.nextLine().trim();
                                nuevaFecha = LocalDate.parse(fechaStr);
                                if (nuevaFecha.isAfter(LocalDate.now().minusYears(18))) {
                                    System.out.println("Debes ser mayor de 18 anos.");
                                    nuevaFechaValida = false;
                                } else {
                                    nuevaFechaValida = true;
                                }
                            } catch (Exception e) {
                                System.out.println("Formato incorrecto. Usa YYYY-MM-DD.");
                                nuevaFechaValida = false;
                            }
                        } while (!nuevaFechaValida);

                        userAModificar.setNombre(nuevoNombre);
                        userAModificar.setCorreo(nuevoCorreo);
                        userAModificar.setContrasena(nuevaPass);
                        userAModificar.setFecha_nacimiento(nuevaFecha);

                        if (usuarioControlador.actualizarUsuario(userAModificar)) {
                            System.out.println("\nUsuario modificado correctamente.");
                        } else {
                            System.out.println("\nNo se pudo modificar. Verifica el ID.");
                        }
                        break;

                    case 3:
                        usuarioControlador.imprimirUsuariosRegistrados();
                        break;

                    case 4:
                        System.out.println("\n--- BUSCAR USUARIO POR ID ---");

                        int idBuscar = 0;
                        do {
                            try {
                                System.out.print("Ingresa el ID del usuario: ");
                                idBuscar = teclado.nextInt();
                                teclado.nextLine();
                                if (idBuscar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idBuscar = 0;
                            }
                        } while (idBuscar <= 0);

                        Usuario usuarioEncontrado = usuarioControlador.buscarUsuarioPorId(idBuscar);

                        if (usuarioEncontrado == null) {
                            System.out.println("No se encontro ningun usuario con el ID: " + idBuscar);
                        } else {
                            String tipoEncontrado = usuarioEncontrado.getId_tipo_usuario() == 2 ? "Arrendador" : "Arrendatario";
                            System.out.println("-------------------------------------------------");
                            System.out.println("ID Usuario: " + usuarioEncontrado.getId_usuario());
                            System.out.println("Rol       : " + tipoEncontrado);
                            System.out.println("Nombre    : " + usuarioEncontrado.getNombre());
                            System.out.println("Correo    : " + usuarioEncontrado.getCorreo());
                            System.out.println("Nacimiento: " + usuarioEncontrado.getFecha_nacimiento());
                            System.out.println("Contrasena: " + usuarioEncontrado.getContrasena());
                            System.out.println("Estado    : " + (usuarioEncontrado.isActivo() ? "Activo" : "Inactivo"));
                            System.out.println("Registro  : " + (usuarioEncontrado.getFecha_registro() != null ? usuarioEncontrado.getFecha_registro() : "No disponible"));
                            System.out.println("-------------------------------------------------");
                        }
                        break;

                    case 5:
                        System.out.print("ID del usuario a eliminar (Baja logica): ");
                        int idEliminar = teclado.nextInt();
                        teclado.nextLine();

                        if (usuarioControlador.eliminarUsuario(idEliminar)) {
                            System.out.println("Usuario desactivado correctamente.");
                        } else {
                            System.out.println("Error al eliminar. Verifica el ID.");
                        }
                        break;

                    case 0:
                        System.out.println("Regresando al menu principal...");
                        break;

                    default:
                        System.out.println("Opcion invalida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error, ingresa un numero valido.");
                teclado.nextLine();
            }
        }
    }
}

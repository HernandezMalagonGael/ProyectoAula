package principalcrud;

import controlador.PagoControlador;
import modelo.Pago;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuPagoCRUD {

    public static void mostrar(Scanner teclado, PagoControlador pagoControlador) {
        int opcion = -1;
        while (opcion != 0) {
            System.out.println("\n-- SUBMENU: PAGOS --");
            System.out.println("1. Registrar Pago");
            System.out.println("2. Modificar Pago");
            System.out.println("3. Consultar todos los Pagos");
            System.out.println("4. Buscar Pago por ID");
            System.out.println("5. Eliminar Pago");
            System.out.println("0. Volver al Menu Principal");
            System.out.print("Elige una opcion: ");

            try {
                opcion = teclado.nextInt();
                teclado.nextLine();

                switch (opcion) {
                    case 1:
                        System.out.println("\n--- REGISTRAR PAGO ---");

                        // id usuario
                        int idUsuario = 0;
                        do {
                            try {
                                System.out.print("ID del arrendador: ");
                                idUsuario = teclado.nextInt();
                                teclado.nextLine();
                                if (idUsuario <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idUsuario = 0;
                            }
                        } while (idUsuario <= 0);

                        // id inmueble 
                        int idInmueble = 0;
                        do {
                            try {
                                System.out.print("ID del inmueble: ");
                                idInmueble = teclado.nextInt();
                                teclado.nextLine();
                                if (idInmueble <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idInmueble = 0;
                            }
                        } while (idInmueble <= 0);

                        // monto
                        double monto = -1;
                        do {
                            try {
                                System.out.print("Monto pagado: ");
                                monto = teclado.nextDouble();
                                teclado.nextLine();
                                if (monto <= 0) {
                                    System.out.println("El monto debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                monto = -1;
                            }
                        } while (monto <= 0);

                        // fecha del pago
                        LocalDate fecha = null;
                        boolean fechaValida = false;
                        do {
                            try {
                                System.out.print("Fecha del pago (YYYY-MM-DD): ");
                                String fechaStr = teclado.nextLine().trim();
                                fecha = LocalDate.parse(fechaStr);
                                fechaValida = true;
                            } catch (Exception e) {
                                System.out.println("Formato incorrecto. Usa YYYY-MM-DD.");
                                fechaValida = false;
                            }
                        } while (!fechaValida);

                        // periodo
                        String periodo = "";
                        do {
                            System.out.print("Periodo (ej: Mayo 2026): ");
                            periodo = teclado.nextLine().trim();
                            if (periodo.isEmpty() || periodo.length() > 50) {
                                System.out.println("Periodo invalido (max 50 caracteres).");
                            }
                        } while (periodo.isEmpty() || periodo.length() > 50);

                        // comprobante
                        System.out.print("Ruta o URL del comprobante (opcional, Enter para omitir): ");
                        String comprobante = teclado.nextLine().trim();
                        if (comprobante.isEmpty()) {
                            comprobante = null;
                        }

                        if (pagoControlador.registrarPago(idUsuario, idInmueble, monto, fecha, periodo, comprobante)) {
                            System.out.println("\nPago registrado exitosamente.");
                        } else {
                            System.out.println("\nError al registrar el pago. Verifica los IDs.");
                        }
                        break;

                    case 2:
                        System.out.println("\n--- MODIFICAR PAGO ---");

                        int idModificar = 0;
                        do {
                            try {
                                System.out.print("ID del pago a modificar: ");
                                idModificar = teclado.nextInt();
                                teclado.nextLine();
                                if (idModificar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idModificar = 0;
                            }
                        } while (idModificar <= 0);

                        // confirmar que existe
                        Pago pagoAModificar = pagoControlador.buscarPagoPorId(idModificar);
                        if (pagoAModificar == null) {
                            System.out.println("No existe ningun pago con el ID: " + idModificar);
                            break;
                        }

                        // nuevo monto
                        double nuevoMonto = -1;
                        do {
                            try {
                                System.out.print("Nuevo monto: ");
                                nuevoMonto = teclado.nextDouble();
                                teclado.nextLine();
                                if (nuevoMonto <= 0) {
                                    System.out.println("El monto debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                nuevoMonto = -1;
                            }
                        } while (nuevoMonto <= 0);

                        // nueva fecha
                        LocalDate nuevaFecha = null;
                        boolean nuevaFechaValida = false;
                        do {
                            try {
                                System.out.print("Nueva fecha del pago (YYYY-MM-DD): ");
                                String fechaStr = teclado.nextLine().trim();
                                nuevaFecha = LocalDate.parse(fechaStr);
                                nuevaFechaValida = true;
                            } catch (Exception e) {
                                System.out.println("Formato incorrecto. Usa YYYY-MM-DD.");
                                nuevaFechaValida = false;
                            }
                        } while (!nuevaFechaValida);

                        // nuevo periodo
                        String nuevoPeriodo = "";
                        do {
                            System.out.print("Nuevo periodo (ej: Junio 2026): ");
                            nuevoPeriodo = teclado.nextLine().trim();
                            if (nuevoPeriodo.isEmpty() || nuevoPeriodo.length() > 50) {
                                System.out.println("Periodo invalido (max 50 caracteres).");
                            }
                        } while (nuevoPeriodo.isEmpty() || nuevoPeriodo.length() > 50);

                        // nuevo comprobante
                        System.out.print("Nueva ruta o URL del comprobante (Enter para omitir): ");
                        String nuevoComprobante = teclado.nextLine().trim();
                        if (nuevoComprobante.isEmpty()) {
                            nuevoComprobante = pagoAModificar.getComprobante();
                        }

                        pagoAModificar.setMonto(nuevoMonto);
                        pagoAModificar.setFecha(nuevaFecha);
                        pagoAModificar.setPeriodo_tiempo(nuevoPeriodo);
                        pagoAModificar.setComprobante(nuevoComprobante);
                        

                        if (pagoControlador.actualizarPago(pagoAModificar)) {
                            System.out.println("\nPago modificado correctamente.");
                        } else {
                            System.out.println("\nNo se pudo modificar el pago.");
                        }
                        break;

                    case 3:
                        pagoControlador.imprimirPagosRegistrados();
                        break;

                    case 4:
                        System.out.println("\n--- BUSCAR PAGO POR ID ---");

                        int idBuscar = 0;
                        do {
                            try {
                                System.out.print("Ingresa el ID del pago: ");
                                idBuscar = teclado.nextInt();
                                teclado.nextLine();
                                if (idBuscar <= 0) {
                                    System.out.println("El ID debe ser mayor a 0.");
                                }
                            } catch (Exception e) {
                                System.out.println("Debes ingresar un numero valido.");
                                teclado.nextLine();
                                idBuscar = 0;
                            }
                        } while (idBuscar <= 0);

                        Pago pagoEncontrado = pagoControlador.buscarPagoPorId(idBuscar);

                        if (pagoEncontrado == null) {
                            System.out.println("No se encontro ningun pago con el ID: " + idBuscar);
                        } else {
                            System.out.println("-------------------------------------------------");
                            System.out.println("ID Pago      : " + pagoEncontrado.getId_pago());
                            System.out.println("ID Inmueble  : " + pagoEncontrado.getId_inmueble());
                            System.out.println("ID Usuario   : " + pagoEncontrado.getId_usuario());
                            System.out.println("Monto        : $" + pagoEncontrado.getMonto());
                            System.out.println("Fecha Pago   : " + pagoEncontrado.getFecha());
                            System.out.println("Periodo      : " + pagoEncontrado.getPeriodo_tiempo());
                            System.out.println("Estado       : " + pagoEncontrado.getEstado_pago());
                            System.out.println("Comprobante  : " + (pagoEncontrado.getComprobante() != null ? pagoEncontrado.getComprobante() : "No disponible"));
                            System.out.println("Creado       : " + (pagoEncontrado.getFecha_creacion() != null ? pagoEncontrado.getFecha_creacion() : "No disponible"));
                            System.out.println("-------------------------------------------------");
                        }
                        break;

                    case 5:
                        System.out.print("ID del pago a eliminar: ");
                        int idEliminar = teclado.nextInt();
                        teclado.nextLine();

                        if (pagoControlador.eliminarPago(idEliminar)) {
                            System.out.println("Pago eliminado correctamente.");
                        } else {
                            System.out.println("Error al eliminar. Verifica el ID.");
                        }
                        break;

                    case 0:
                        System.out.println("Regresando al menu principal...");
                        break;

                    default:
                        System.out.println("Opcion invalida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Error, ingresa un numero valido.");
                teclado.nextLine();
            }
        }
    }
}
